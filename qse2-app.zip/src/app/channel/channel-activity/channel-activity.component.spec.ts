import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelActivityComponent } from './channel-activity.component';

describe('ChannelActivityComponent', () => {
  let component: ChannelActivityComponent;
  let fixture: ComponentFixture<ChannelActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
