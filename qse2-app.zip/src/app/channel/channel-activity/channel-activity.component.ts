import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channel-activity',
  templateUrl: './channel-activity.component.html',
  styleUrls: ['./channel-activity.component.css']
})
export class ChannelActivityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
