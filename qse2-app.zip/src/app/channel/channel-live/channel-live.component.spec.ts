import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelLiveComponent } from './channel-live.component';

describe('ChannelLiveComponent', () => {
  let component: ChannelLiveComponent;
  let fixture: ComponentFixture<ChannelLiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelLiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelLiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
