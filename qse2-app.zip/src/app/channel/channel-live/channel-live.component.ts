import { Component, OnInit } from '@angular/core';
import { ChannelListService } from '../channel-list/channel-list.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';

export interface ChannelLive{
  Schedule:string;
  data: Data[]
}
export interface Data{
  type:string;
  name:string;
  data:Data[]
}
@Component({
  selector: 'app-channel-live',
  templateUrl: './channel-live.component.html',
  styleUrls: ['./channel-live.component.css']
})
export class ChannelLiveComponent implements OnInit {

  view = "http://id.qubit.asia:8081//1587986621053-Apink.mp4"
  // view = "http://localhost:8081//1587737534053-BTS - The Truth Untold (전하지 못한 진심) (feat. Steve Aoki) (Color Coded.mp4"
  
  selectedChannel = []

  todayDate = Date()

  constructor(
    private channelListService: ChannelListService
  ) { }

  ngOnInit(): void {
    // this.selectedChannel = JSON.parse(this.channelListService.SelectedDetails)
    // console.log(this.selectedChannel)

    // for(var i = 0; i < this.selectedChannel[0].live.length; i++){
    //   this.selectedChannel[0].live[i].contentsChild = new NestedTreeControl<Data>(node => node.data)
    //   this.selectedChannel[0].live[i].contentsList = new MatTreeNestedDataSource<ChannelLive>()
    //   this.selectedChannel[0].live[i].contentsList.data = this.selectedChannel[0].live[i].data

    //   this.selectedChannel[0].live[i].hasChild = (_: number, node: ChannelLive) => !!node.data && node.data.length > 0;
    // }
  }

}
