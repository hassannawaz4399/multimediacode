import { TestBed } from '@angular/core/testing';

import { ChannelListService } from './channel-list.service';

describe('ChannelListService', () => {
  let service: ChannelListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChannelListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
