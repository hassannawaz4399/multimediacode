import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { LayoutService } from 'src/app/layout/layout.service';
import { ChannelListService } from './channel-list.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { ModalsChannelAddComponent } from 'src/app/modals/channel/modals-channel-add/modals-channel-add.component';
import { Devices } from 'src/app/monitoring/device-list/device-list.component';
import { ModalsChannelDeleteComponent } from 'src/app/modals/channel/modals-channel-delete/modals-channel-delete.component';
import { ModalsChannelEditComponent } from 'src/app/modals/channel/modals-channel-edit/modals-channel-edit.component';
import { Subscription } from 'rxjs';
import { ChannelService } from 'src/app/services/channel/channel.service';
import { formatDate } from '@angular/common';
import { MatSort } from '@angular/material/sort';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';

export interface Channel {
  channel_name: string;
  description: string;
  total_linked_branch: number;
  total_linked_location: number;
  total_linked_device: number;
  inserted_at: string;
  updated_at: string;
  schedule_now: string;
  schedule_next: string;
  playlist_now: string;
  playlist_next: string;
  idle: boolean;
  status: boolean;
  created_by: string;
  linked_device: Branch[]
  live: [];
  is_selected: boolean;
}

export interface Branch {
  branch_id: string;
  branch_name: string;
  branch_info: Location[]
}

export interface Location {
  location_key: string,
  location_name: string,
  floor: string;
  devices: Device[];
}

export interface Device {
  device_id: string;
  device_name: string;
  online: boolean
}

@Component({
  selector: 'app-channel-list',
  templateUrl: './channel-list.component.html',
  styleUrls: ['./channel-list.component.css']
})

export class ChannelListComponent implements OnInit, OnDestroy {

  channelListDisplayColumn: string[] = ['action', 'channel_name', 'device', 'created', 'modified'] // , 'now', 'next'

  channelList: MatTableDataSource<Channel>;

  rightSideNavWidth;
  masterSelected: boolean;
  currentSelectedContent: Array<Channel> = [];

  subscription : Subscription[] = []

  checkedRow: any;

  lengthSelected = 0;
  runningtotal = 0;
  norunningtotal = 0;
  nameSelected = "";

  created:Date[] = []
  modified:Date[] = []

  @ViewChild('sidenavright') sidenavright;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(
    private deviceListService: DeviceListService,
    private channelListService: ChannelListService,
    private layoutService: LayoutService,
    private channelService:ChannelService,

    public dialog: MatDialog,
  ) {
    this.subscription.push( layoutService.rightToggle.subscribe(data => {
      this.toggleRightNav();
    }))

    this.subscription.push( layoutService.rightWidth.subscribe(data => {
      this.rightSideNavWidth = data;
    }))

    this.subscription.push( channelListService.refreshTable.subscribe(Refresh => {
      this.getChannelTable()
    }))

    this.subscription.push( channelListService.unchecked.subscribe(data => {
      console.log(data);
      if (data === 'allClose') {
        this.masterSelected = false;
        for (let i = 0; i < this.channelList.data.length; i++) {
          this.channelList.data[i].is_selected = false;
        }

        this.selectMasterEvent()
      }
    }))

    this.subscription.push( channelListService.deleteSelected.subscribe(deletedata => {
      // let done = false
      // let data = this.channelList.data

      // while(!done){
      //   done = true
      //   for(var i=0; i<data.length; i++){
      //     if(data[i].is_selected){
      //       done = false
      //       data.splice(i,1)
      //       break;
      //     }
      //   }
      // }

      // this.channelList.data = data
      // this.table.renderRows();

      // this.masterSelected = false
      // this.channelListService.setChannelTotal(this.channelList.data.length)
      this.openDialogDeleteChannel("Delete", {})
      // this.selectMasterEvent()
    }))

    this.subscription.push( channelListService.addChannel.subscribe(Add => {
      this.openDialogAddChannel('Add', {})
    }))

    this.subscription.push( channelListService.editChannel.subscribe(Edit => {
      this.openDialogEditChannel('Edit', {})
    }))
  }

  ngOnInit(): void {
    // this.deviceListService.setMonitoringStatus(false)

    this.channelList = new MatTableDataSource<Channel>([])

    this.getChannelTable()
    
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at channel-list")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  toggleRightNav() {
    this.sidenavright.toggle();
  }

  sidenavMode() {
    return this.layoutService.getSidenavMode();
  }

  openSchedule(channel) {
    this.deviceListService.setMonitoringStatus(false)
    this.channelListService.setCurrentChannel({channel_name:channel.channel_name, channel_id:channel.channel_id})
    this.channelListService.setScheduleState(true)
  }

  rightNavStatus(status) {
    if (status === 1) {
      this.sidenavright.open();
    } else {
      this.sidenavright.close();
    }
  }

  selectMasterEvent() {
    console.log("Select All : " + this.masterSelected);
    if (this.masterSelected) {
      for (const item of this.channelList.data) {
        item.is_selected = this.masterSelected;
        this.selectListContentEvent(item);
      }
    } else {
      for (const item of this.channelList.data) {
        item.is_selected = this.masterSelected;
        this.selectListContentEvent(item);
      }
    }
  }

  selectListContentEvent(content) {
    if (content.is_selected) {
      if (this.currentSelectedContent.length === 0) {
        this.currentSelectedContent.push(content);
      } else {
        const check = this.currentSelectedContent.find(
          (item) => item.channel_name === content.channel_name
        );
        if (check === undefined) {
          this.currentSelectedContent.push(content);
        }
      }
    } else {
      this.currentSelectedContent = this.currentSelectedContent.filter(
        (item) => item.channel_name !== content.channel_name
      );
    }

    console.log("select", this.currentSelectedContent)

    this.channelListService.setSelectedDetails(JSON.stringify(this.currentSelectedContent))

    this.rightNavStatus(this.currentSelectedContent.length);
  }

  getChannelTable(){
    this.channelList.data = []
    this.modified = []
    this.created = []
    this.currentSelectedContent = []
    this.runningtotal = 0;
    this.norunningtotal = 0;
    this.channelListService.setSelectedDetails(JSON.stringify(this.currentSelectedContent))

    this.subscription.push( this.channelService.getChannelListData().subscribe((ChannelList) => {
      console.log("this.channelService.getChannelListData()", ChannelList)
      const dataList = ChannelList.data

      for (const item of dataList) {
        item.is_selected = false

        if (item.idle){
          this.norunningtotal++
        }
        else{
          this.runningtotal++
        }
        this.modified.push(new Date(formatDate(item.updated_at, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC'))
        this.created.push(new Date(formatDate(item.inserted_at, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC'))
      }

      this.channelList = new MatTableDataSource<Channel>(dataList)
      
      this.channelList.paginator = this.paginator
      this.channelList.sort = this.sort
      console.log("refresh playlist", this.channelList)
      
    }))
  }

  openDialogAddChannel(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      obj.action = action
      const dialogRef = this.dialog.open(ModalsChannelAddComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      this.subscription.push( dialogRef.afterClosed().subscribe(result => {
        if (result.event === 'Add') {
          this.getChannelTable()
          // this.addDataTable(result.data);
        }
      }))
    }
  }

  openDialogDeleteChannel(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      // obj.action = action
      const dialogRef = this.dialog.open(ModalsChannelDeleteComponent, {
        data: { data: JSON.stringify(this.currentSelectedContent), action: action },
        width: '50%',
        height: '80.1%'
      });

      this.subscription.push( dialogRef.afterClosed().subscribe(result => {
        console.log(result)
        if (result.event === 'Delete') {
          // this.deleteDataTable(result.data);
          this.getChannelTable()
        }
      }))
    }
  }

  openDialogEditChannel(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      // obj.action = action
      const dialogRef = this.dialog.open(ModalsChannelEditComponent, {
        data: { data: JSON.stringify(this.currentSelectedContent), action: action },
        width: '50%',
        height: '80.1%'
      });

      this.subscription.push( dialogRef.afterClosed().subscribe(result => {
        if (result.event === 'Edit') {
          this.getChannelTable()
        }
      }))
    }
  }

  addDataTable(rowObj) {
    console.log("addTable", rowObj)
    let data = this.channelList.data

    data.push({
      channel_name: rowObj.channel_name,
      description: rowObj.description,
      total_linked_branch: rowObj.total_linked_branch,
      total_linked_location: rowObj.total_linked_location,
      total_linked_device: rowObj.total_linked_device,
      inserted_at: "4/2/2020",
      updated_at: "4/2/2020",
      schedule_now: '',
      schedule_next: '',
      playlist_now: '',
      playlist_next: '',
      idle: true,
      status: false,
      created_by: "Qubit",
      linked_device: rowObj.linked_device,
      live: [],
      is_selected: false
    })

    this.channelList.data = data
    this.table.renderRows()
  }

  deleteDataTable(rowObj) {
    console.log("Delete")
    let done = false
    let data = this.channelList.data

    while (!done) {
      done = true
      for (var i = 0; i < data.length; i++) {
        if (data[i].is_selected) {
          done = false
          data.splice(i, 1)
          break;
        }
      }
    }

    this.channelList.data = data
    this.table.renderRows();

    this.masterSelected = false

    this.selectMasterEvent()

    this.currentSelectedContent = []
    this.channelListService.setSelectedDetails(JSON.stringify(this.currentSelectedContent))
    this.sidenavright.close();
  }
}
