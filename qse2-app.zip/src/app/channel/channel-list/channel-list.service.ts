import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChannelListService {

  SelectedDetails
  currentchannel

  @Output() refreshTable: EventEmitter<any> = new EventEmitter();
  @Output() scheduleState: EventEmitter<any> = new EventEmitter();
  @Output() currentChannel: EventEmitter<any> = new EventEmitter();
  @Output() selectedDetails: EventEmitter<any> = new EventEmitter();
  @Output() unchecked: EventEmitter<any> = new EventEmitter();
  @Output() deleteSelected: EventEmitter<any> = new EventEmitter();
  @Output() addChannel: EventEmitter<any> = new EventEmitter();
  @Output() editChannel: EventEmitter<any> = new EventEmitter();

  constructor(
    private http: HttpClient,
  ) { }

  getChannelListData(): any {
    return this.http.get('assets/json/channel-list-data.json');
  }

  refreshChannel(){
    this.refreshTable.emit('refresh')
  }

  setScheduleState(state){
    this.scheduleState.emit(state);
  }

  setCurrentChannel(channel){
    this.currentchannel = channel
    this.currentChannel.emit(channel);
  }

  getCurrentChannel(){
    return this.currentchannel
  }

  setSelectedDetails(selected) {
    this.SelectedDetails = selected
    this.selectedDetails.emit(selected)
  }

  getSelectedDetails() {
    return this.SelectedDetails
  }

  setCheckedbox(checked) {
    this.unchecked.emit(checked)
  }

  setDeleteSelected() {
    this.deleteSelected.emit('delete')
  }

  setAddChannel() {
    this.addChannel.emit('add')
  }

  setEditChannel() {
    this.editChannel.emit('edit')
  }
}
