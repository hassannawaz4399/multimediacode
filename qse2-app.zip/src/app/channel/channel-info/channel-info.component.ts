import { Component, OnInit } from '@angular/core';
import { ChannelListService } from '../channel-list/channel-list.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { ChannelService } from 'src/app/services/channel/channel.service';
import { formatDate } from '@angular/common';
import { Subscription } from 'rxjs';
import { PhxSocketService } from 'src/app/services/socket/phx-socket.service';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';

export interface Channel {
  channel_name: string;
  description: string;
  total_linked_branch: number;
  total_linked_location: number;
  total_linked_device: number;
  inserted_at: string;
  updated_at: string;
  schedule_now: string;
  schedule_next: string;
  playlist_now: string;
  playlist_next: string;
  idle: boolean;
  status: boolean;
  created_by: string;
  linked_device: Branch[]
  live: [];
  is_selected: boolean;
}

export interface Branch {
  branch_id: string;
  branch_name: string;
  branch_info: Location[]
}

export interface Location {
  location_key: string,
  location_name: string,
  floor: string;
  devices: Device[];
}

export interface Device {
  device_id: string;
  device_name: string;
  online: boolean
}

@Component({
  selector: 'app-channel-info',
  templateUrl: './channel-info.component.html',
  styleUrls: ['./channel-info.component.css']
})
export class ChannelInfoComponent implements OnInit {

  subscription: Subscription[] = []

  channelList: Channel

  created: Date
  modified: Date

  constructor(
    private deviceListService: DeviceListService,
    private websocket: PhxSocketService,
    private channelListService: ChannelListService,
    private channelService: ChannelService
  ) {
    
    websocket.online.subscribe(resp => {
      if (this.channelList != undefined) {
        for (const branch of this.channelList.linked_device) {
          if (branch.branch_id == resp.branch_id) {
            for (const location of branch.branch_info) {
              for (const device of location.devices) {
                if (device.device_id == resp.device_id) {
                  device.online = resp.status
                }
              }
            }
          }
        }
      }
    })
    
  }

  ngOnInit(): void {
    let temp = JSON.parse(this.channelListService.SelectedDetails)

    this.subscription.push(this.channelService.getOneChannel(temp[0].channel_name).subscribe((ChannelList) => {
      console.log(' this.channelService.getOneChannel()', ChannelList)
      if (ChannelList.data.result == 'success') {
        this.channelList = ChannelList.data.data

        this.modified = new Date(formatDate(this.channelList.updated_at, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC')
        this.created = new Date(formatDate(this.channelList.inserted_at, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC')

        if (this.channelList != undefined) {
          for (const branch of this.channelList.linked_device) {
            for (const location of branch.branch_info) {
              for (const device of location.devices) {
                device.online = this.deviceListService.getDeviceStatus(branch.branch_id, device.device_id)
              }
            }
          }
        }
        console.log(this.channelList)
      }
    }))
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.

    console.log("unsubscribe all subscription at channel-info")
    for (const item of this.subscription) {
      item.unsubscribe()
    }
  }

  editLinkedDevice() {
    this.channelListService.setEditChannel()
  }
}
