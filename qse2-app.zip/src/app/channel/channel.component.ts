import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChannelListService } from './channel-list/channel-list.service';
import { LayoutService } from '../layout/layout.service';
import { Subscription } from 'rxjs';
import { DeviceListService } from '../monitoring/device-list/device-list.service';

@Component({
  selector: 'app-channel',
  templateUrl: './channel.component.html',
  styleUrls: ['./channel.component.css']
})
export class ChannelComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  channeltotal = 0;
  runningtotal = 0;
  norunningtotal = 0;

  schedulestate = false
  lengthSelected = 0

  constructor(
    private layoutService: LayoutService,
    private channelListService: ChannelListService,
    deviceListService: DeviceListService,
  ) {
    
    deviceListService.setSelectedBranch(null)

    this.subscription.push( channelListService.scheduleState.subscribe(state => {
      this.schedulestate = state
    }))

    this.subscription.push( channelListService.selectedDetails.subscribe(details => {
      let jsonData = JSON.parse(details);
      this.lengthSelected = jsonData.length
      
      console.log("json",jsonData)
    }))
  }

  ngOnInit(): void {
    this.layoutService.toggleLeft(true);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at channel")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  togglerightNav(){
    this.layoutService.toggleRight();
  }

  deleteplaylist(){
    this.channelListService.setDeleteSelected()
  }

  closerightNav(){
    this.channelListService.setCheckedbox("allClose")
  }

  addChannel(){
    this.channelListService.setAddChannel()
  }

  refreshChannelTable(){
    this.channelListService.refreshChannel()
  }
}
