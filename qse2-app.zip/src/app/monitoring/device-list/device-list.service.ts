import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DeviceListService {

  branchstate = true
  pathdevice = ''
  currentdevice
  monitoringstatus
  SelectedDetails
  SelectedBranch = null
  device_status = []

  @Output() refreshBranchTable: EventEmitter<any> = new EventEmitter();
  @Output() refreshLocationTable: EventEmitter<any> = new EventEmitter();
  @Output() branchState: EventEmitter<any> = new EventEmitter();
  @Output() pathDevice: EventEmitter<any> = new EventEmitter();
  @Output() scheduleState: EventEmitter<any> = new EventEmitter();
  @Output() deviceTotal: EventEmitter<any> = new EventEmitter();
  @Output() currentDevice: EventEmitter<any> = new EventEmitter();
  @Output() unchecked: EventEmitter<any> = new EventEmitter();
  @Output() monitoringStatus: EventEmitter<any> = new EventEmitter();
  @Output() selectedDetails: EventEmitter<any> = new EventEmitter();
  @Output() selectedBranch: EventEmitter<any> = new EventEmitter();
  
  constructor(
    private http: HttpClient,
  ) { }

  getDeviceListData(): any {
    return this.http.get('assets/json/device-list-data.json');
  }

  getBranchListData(): any {
    return this.http.get('assets/json/branch-list-data.json');
  }

  getLocationListData(): any {
    return this.http.get('assets/json/location-list-data.json');
  }

  SetDeviceTotal(total){
    this.deviceTotal.emit(total);
  }

  setBranchState(state){
    this.branchState.emit(state);
    this.branchstate = state
  }

  getBranchState(){
    return this.branchstate
  }

  setPathDevice(path){
    this.pathDevice.emit(path);
    this.pathdevice = path
  }

  getPathDevice(){
    return this.pathdevice
  }

  setScheduleState(state){
    this.scheduleState.emit(state);
  }

  setCurrentDevice(device){
    this.currentdevice = device
    this.currentDevice.emit(device);
  }

  getCurrentDevice(){
    return this.currentdevice
  }

  setMonitoringStatus(status){
    this.monitoringstatus = status
    this.monitoringStatus.emit(status);
  }

  getMonitoringStatus(){
    return this.monitoringstatus
  }

  setSelectedBranch(selected){
    this.SelectedBranch = selected
    this.selectedBranch.emit(selected)
  }

  getSelectedBranch() {
    return JSON.parse(this.SelectedBranch)
  }

  setSelectedDetails(selected) {
    this.SelectedDetails = selected
    this.selectedDetails.emit(selected)
  }

  getSelectedDetails() {
    return JSON.parse(this.SelectedDetails)
  }

  refreshBranch() {
    this.refreshBranchTable.emit('branch')
  }

  refreshLocation() {
    this.refreshLocationTable.emit('location')
  }

  setDeviceStatus(devicestatus){
    console.log("devicestatus", devicestatus)
    this.device_status = devicestatus
  }

  modifyDeviceStatus(device){
    // checking which device then modify the status
    for(const list of this.device_status){
      if(list.branch_id == device.branch_id && list.device_id == device.device_id){
        list.online = device.status
        console.log("modify",device.device_id)
      }
    }
  }

  getDeviceStatus(branch_id, device_id){
    const device = (this.device_status.find((item) => item.branch_id === branch_id && item.device_id === device_id));
    console.log("device", device)
    return device.online
  }

  setCheckedbox(checked) {
    this.unchecked.emit(checked)
  }
}
