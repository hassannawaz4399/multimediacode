import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DeviceListService } from './device-list.service';
import { MatTableDataSource } from '@angular/material/table';
import { LayoutService } from 'src/app/layout/layout.service';
import { MatPaginator } from '@angular/material/paginator';
import { BranchService } from 'src/app/services/monitoring/branch.service';
import { PhxSocketService } from 'src/app/services/socket/phx-socket.service';
import { Subscription } from 'rxjs';

export interface Branches{
  branch_id: string,
  branch_ip: string,
  connected: boolean,
  branch_name:string,
  total_device: number,
  device_online: number,
  device_offline: number,
  branch_info: Locations[],
}

export interface Locations{
  location_id:string,
  location_name:string,
  floor:string,
  is_selected_location:boolean,
  devices:Devices,
}

export interface Devices{
  device_id:string,
  device_name:string,
  online:boolean,
  panel:boolean,
  device_ip:string,
  model:string,
  serial_number:string,
  playlist_name:string,
  layout_name:string,
  schedule_name:string,
  channel_name:string,
  app_version:string,
  firmware_version:string,
  is_selected_device:boolean,
}

@Component({
  selector: 'app-device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['./device-list.component.css']
})
export class DeviceListComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  navmode = 'side'
  rightSideNavWidth;

  branchesListDisplayColumn: string[] = ['branch_name', 'branch_ip', 'total_device', 'device_online', 'device_offline']
  locationsListDisplayColumn: string[] = ['location_action', 'location_name', 'device_action', 'device_name', 'device_ip', 'model', 'schedule', 'now', 'softwareVer'] 

  originalLocationList
  branchesList: MatTableDataSource<Branches>;
  locationsList: MatTableDataSource<Locations>;

  branchstate: boolean = true
  branchTotal: number = 0
  allDeviceTotal: number = 0
  connectedTotal: number = 0
  disconnectedTotal: number = 0
  deviceTotal: number = 0
  onlineTotal: number = 0
  offlineTotal: number = 0
  panelOnTotal: number = 0
  panelOffTotal: number = 0

  path: string = ''

  spans = [];

  masterSelected: boolean;
  checkedRow: any;
  lengthSelected = 0;

  selectedbranch:any = {}

  currentSelectedContent: Array<Locations> = [];

  @ViewChild('sidenavright') sidenavright;
  @ViewChild('branchPaginator') branchPaginator: MatPaginator

  @ViewChild('locationPaginator') locationPaginator: MatPaginator

  constructor(
    private branchService: BranchService,
    private deviceListService: DeviceListService,
    private layoutService: LayoutService,
    private websocket: PhxSocketService,
  ) {

    this.subscription.push( layoutService.rightToggle.subscribe(data => {
      this.toggleRightNav();
    }))

    this.subscription.push( deviceListService.unchecked.subscribe(data => {
      console.log(data);
      if (data === 'allClose') {
        this.refreshlocationtable()
      }
    }))

    this.subscription.push( layoutService.rightWidth.subscribe(data => {
      // this.rightSideNavWidth = data;
    }))

    this.subscription.push( deviceListService.refreshBranchTable.subscribe(branch =>{
      this.goToBranchList()
    }))

    this.subscription.push( deviceListService.refreshLocationTable.subscribe(location => {
      this.refreshlocationtable()
    }))

    this.subscription.push( websocket.panel.subscribe(resp => {
      if (!this.branchstate){
        if(this.selectedbranch.branch_id == resp.branch_id){
          for(const location of this.locationsList.data){
            if(location.devices.device_id == resp.device_id){
              location.devices.panel = resp.status
            }
          }
        }
      }
      else{
        this.getbranchlist()
      }
    }))

    this.subscription.push( websocket.online.subscribe(resp => {
      if (!this.branchstate){
        if(this.selectedbranch.branch_id == resp.branch_id){
          for(const location of this.locationsList.data){
            if(location.devices.device_id == resp.device_id){
              location.devices.online = resp.status
            }
          }
        }
      }
      else{
        this.getbranchlist()
      }
    }))

    this.subscription.push( websocket.scheduleNow.subscribe(resp => {
      if (!this.branchstate){
        if(this.selectedbranch.branch_id == resp.branch_id){
          for(const location of this.locationsList.data){
            if(location.devices.device_id == resp.device_id){
              location.devices.channel_name = resp.channel_name
              location.devices.playlist_name = resp.playlist_name
              location.devices.layout_name = resp.playlist_template
              location.devices.schedule_name = resp.schedule_name
            }
          }
        }
      }
      else{
        this.getbranchlist()
      }
    }))
  }

  ngOnInit(): void {
    this.deviceListService.setPathDevice(this.path)

    let tempselected = this.deviceListService.getSelectedBranch()
    
    if(tempselected == null){
      this.getbranchlist()
    }
    else{
      this.selectedbranch = this.deviceListService.getSelectedBranch()
      this.refreshlocationtable()
    }

    console.log("branchstate", this.branchstate)
    setTimeout(() => {
      this.deviceListService.setBranchState(this.branchstate)
    });

    if (window.innerWidth <= 900) {
      this.rightSideNavWidth = 'calc(100vw - 57px)';
    } else {
      this.rightSideNavWidth = '20vw';
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at device-list")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  getbranchlist(){
    this.allDeviceTotal = 0;

    this.branchService.getBranchListData().subscribe((AllDeviceList) =>{
      console.log("this.branchService.getBranchListData()", AllDeviceList)
      if(AllDeviceList.data.result === 'success'){
        const dataList = AllDeviceList.data.data

        for (const item of dataList) {
          item.is_selected = false

          this.allDeviceTotal += item.total_device
        }
        this.deviceListService.SetDeviceTotal(this.allDeviceTotal)

        this.branchesList = new MatTableDataSource<Branches>(dataList)
        this.branchesList.paginator = this.branchPaginator

        console.log("branches", this.branchesList)
        this.calculateBranchDetails()

        this.branchstate = true

        this.locationsList = new MatTableDataSource<Locations>()

        this.sentDeviceStatus(AllDeviceList.data.data)
      }
      else{
        console.log("ERROR : this.branchService.getBranchListData()")
      }
    })
  }
  
  sentDeviceStatus(allbranches){
    let saveBranch = []
    
    for (const branch of allbranches){
      const temp = branch.branch_info.reduce((current, next) => {
        next.devices.forEach(element => {
          current.push({
            branch_id:branch.branch_id,
            device_id: element.device_id,
            online:element.device_id
          })
        });
        return current
      }, [])

      for(const list of temp){
        saveBranch.push(list)
      }
    }

    console.log("all device status", saveBranch)
    this.deviceListService.setDeviceStatus(saveBranch)
  }

  reset() {
    this.branchTotal = 0
    this.connectedTotal = 0
    this.disconnectedTotal = 0
    this.deviceTotal = 0
    this.onlineTotal = 0
    this.offlineTotal = 0
    this.panelOnTotal = 0
    this.panelOffTotal = 0
  }

  calculateBranchDetails() {
    this.reset()
    this.branchTotal = this.branchesList.data.length

    for (var a = 0; a < this.branchesList.data.length; a++) {

      if (this.branchesList.data[a].connected) {
        this.connectedTotal++
      }
      else {
        this.disconnectedTotal++
      }

      this.deviceTotal += this.branchesList.data[a].total_device
      this.onlineTotal += this.branchesList.data[a].device_online
      this.offlineTotal += this.branchesList.data[a].device_offline
    }
  }

  toggleRightNav() {
    this.sidenavright.toggle();
  }

  sidenavMode() {
    return this.layoutService.getSidenavMode();
  }

  openBranch(choose) {
    this.selectedbranch = {branch_id:choose.branch_id, branch_name:choose.branch_name, branch_info:choose.branch_info}
    this.path = choose.branch_name
    this.deviceListService.setPathDevice(this.path)
    console.log("dbClick", choose.branch_name)

    this.originalLocationList = choose.branch_info

    this.getLocationTableList()
    this.deviceListService.setSelectedBranch(JSON.stringify(choose))
  }

  getLocationTableList(){

    for(var i = 0; i < this.originalLocationList.length; i++){
      this.originalLocationList[i].is_selected_location = false
      for(var j = 0; j < this.originalLocationList[i].devices.length; j++){
        this.originalLocationList[i].devices[j].is_selected_device = false
      } 
    }

    this.locationsList.data = []
    this.locationsList = new MatTableDataSource<Locations>(this.getLocationList())
    
    this.cacheSpan('location_name', d => d.location_name + d.floor);
    this.locationsList.paginator = this.locationPaginator

    this.calculateLocationDetails();
    console.log("locationlist", this.locationsList)

    this.branchstate = false
    this.deviceListService.setBranchState(this.branchstate)

    this.checkedRow = []
    this.lengthSelected = this.checkedRow.length;

    this.checkedRow = JSON.stringify(this.checkedRow);
    this.deviceListService.setSelectedDetails(this.checkedRow)
    this.rightNavStatus(this.lengthSelected)

    if(this.lengthSelected > 0){
      this.rightSideNavWidth = "40vw"
      this.navmode = 'over'
    }
    else if(this.lengthSelected == 0){
      this.rightSideNavWidth = "20vw"
      this.navmode = 'side'
    }
  }

  calculateLocationDetails() {
    this.reset()
    console.log(this.locationsList)
    this.deviceTotal = this.locationsList.data.length
    for (var i = 0; i < this.originalLocationList.length; i++) {
      for (var j = 0; j < this.originalLocationList[i].devices.length; j++) {
        if (this.originalLocationList[i].devices[j].online)
          this.onlineTotal++
        else
          this.offlineTotal++

        if (this.originalLocationList[i].devices[j].panel)
          this.panelOnTotal++
        else
          this.panelOffTotal++
      }
    }
  }

  goToBranchList() {
    this.getbranchlist()
    this.locationsList = new MatTableDataSource<Locations>()
    this.spans = []
    this.selectedbranch={}
    this.path = ""
    this.deviceListService.setPathDevice(this.path)
    this.branchstate = true;
    this.locationsList.data = []
    this.calculateBranchDetails()
    this.deviceListService.setBranchState(this.branchstate)
    this.deviceListService.setSelectedBranch(JSON.stringify({}))

    this.checkedRow = []
    this.lengthSelected = this.checkedRow.length;

    this.checkedRow = JSON.stringify(this.checkedRow);
    this.deviceListService.setSelectedDetails(this.checkedRow)
    this.rightNavStatus(this.lengthSelected)

    if(this.lengthSelected > 0){
      this.rightSideNavWidth = "40vw"
      this.navmode = 'over'
    }
    else if(this.lengthSelected == 0){
      this.rightSideNavWidth = "20vw"
      this.navmode = 'side'
    }
  }

  getLocationList() {
    const temp = this.originalLocationList.reduce((current, next) => {
      next.devices.forEach(element => {
        current.push({
          location_name: next.location_name,
          floor: next.floor,
          is_selected_location: next.is_selected_location,
          devices: element
        })
      });
      return current
    }, [])
    console.log("temp", temp)
    return temp
  }

  cacheSpan(key, accessor) {
    for (let i = 0; i < this.locationsList.data.length;) {
      let currentValue = accessor(this.locationsList.data[i]);
      let count = 1;

      // Iterate through the remaining rows to see how many match
      // the current value as retrieved through the accessor.
      for (let j = i + 1; j < this.locationsList.data.length; j++) {
        if (currentValue != accessor(this.locationsList.data[j])) {
          break;
        }

        count++;
      }

      if (!this.spans[i]) {
        this.spans[i] = {};
      }

      // Store the number of similar values that were found (the span)
      // and skip i to the next unique row.
      this.spans[i][key] = count;
      i += count;
    }
  }

  getRowSpan(col, index) {
    return this.spans[index] && this.spans[index][col];
  }

  openSchedule(device) {
    console.log("Devicename", device)
    this.deviceListService.setMonitoringStatus(true)
    this.deviceListService.setCurrentDevice({branch_id:this.selectedbranch.branch_id, branch_name:this.selectedbranch.branch_name, device_id:device.device_id, device_name:device.device_name})
    this.deviceListService.setScheduleState(true)
  }

  selectMasterEvent(master) {
    console.log("Select All : " + master.location_name);
    if (master.is_selected_location) {
      for (var i = 0; i < this.locationsList.data.length; i++) {
        console.log("Select All : " + master.location_name == this.locationsList.data[i].location_name);
        if(master.location_name == this.locationsList.data[i].location_name){
          this.locationsList.data[i].devices.is_selected_device = this.masterSelected;
          this.selectListContentEvent(this.locationsList.data[i]);
        }
      }
    } else {
      for (const item of this.locationsList.data) {
        if(master.location_name == item.location_name && master.floor == item.floor){
          item.devices.is_selected_device = this.masterSelected;
          this.selectListContentEvent(item);
        }
      }
    }
  }

  selectListContentEvent(content) {
    if (content.is_selected) {
      if (this.currentSelectedContent.length === 0) {
        this.currentSelectedContent.push(content);
      } else {
        const check = this.currentSelectedContent.find(
          (item) => item.devices.device_name === content.devices.device_name
        );
        if (check === undefined) {
          this.currentSelectedContent.push(content);
        }
      }
    } else {
      this.currentSelectedContent = this.currentSelectedContent.filter(
        (item) => item.devices.device_name !== content.devices.device_name
      );
    }

    console.log("select", this.currentSelectedContent)

    // this.channelListService.setSelectedDetails(JSON.stringify(this.currentSelectedContent))

    this.rightNavStatus(this.currentSelectedContent.length);
  }

  //--- TODO: change it like to selectMasterEvent & selectListContentEvent(content)
  checkUncheckAll(master) {
    for(var i = 0; i < this.locationsList.data.length; i++){
      if((master.location_name == this.locationsList.data[i].location_name) && (master.floor == this.locationsList.data[i].floor)){
        this.locationsList.data[i].is_selected_location = master.is_selected_location
        this.locationsList.data[i].devices.is_selected_device = master.is_selected_location
      }
    }
    this.getCheckedItemList();
    
    // for (let i = 0; i < this.branchesList.data.length; i++) {
    //   this.branchesList.data[i].is_selected = this.masterSelected;
    // }
    // this.getCheckedItemList();
  }

  isAllSelected(master) {

    for(var i = 0; i < this.locationsList.data.length; i++){
      master.is_selected_location = true
      if(master.location_name == this.locationsList.data[i].location_name){
        if(!this.locationsList.data[i].devices.is_selected_device){
          master.is_selected_location = false
          for(var j = 0; j < this.locationsList.data.length; j++){
            if(master.location_name == this.locationsList.data[j].location_name){
              this.locationsList.data[j].is_selected_location = false
            }
          }
          break
        }
        else{
          for(var j = 0; j < this.locationsList.data.length; j++){
            if(master.location_name == this.locationsList.data[j].location_name){
              this.locationsList.data[j].is_selected_location = true
            }
          }
        }
      }
    }
    
    this.getCheckedItemList();
    
    // console.log(this.branchesList.data);
    // this.masterSelected = this.branchesList.data.every((item: any) => {
    //   return item.is_selected === true;
    // });
    // this.getCheckedItemList();
  }

  getCheckedItemList() {
    this.checkedRow = [];

    console.log("locationsList",this.locationsList.data);
    
    for(var i = 0; i < this.locationsList.data.length; i++){
      if(this.locationsList.data[i].devices.is_selected_device){
        this.checkedRow.push(this.locationsList.data[i]);
      }
    }

    console.log('checked row : ', this.checkedRow.length);
    this.lengthSelected = this.checkedRow.length;

    this.checkedRow = JSON.stringify(this.checkedRow);
    this.deviceListService.setSelectedDetails(this.checkedRow)
    if(this.lengthSelected > 0){
      this.rightSideNavWidth = "40vw"
      this.navmode = 'over'
    }
    else if(this.lengthSelected == 0){
      this.rightSideNavWidth = "20vw"
      this.navmode = 'side'
    }

    this.rightNavStatus(this.lengthSelected)
  }
  //--

  rightNavStatus(status) {
    if (status > 0) {
      this.sidenavright.open();
    } else {
      this.sidenavright.close();
    }
  }

  refreshlocationtable(){
    this.getbranchlist()
    setTimeout(() => {
      this.openBranch(this.selectedbranch)
    }, 400);
  }
}
