import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-setting-configuration',
  templateUrl: './device-setting-configuration.component.html',
  styleUrls: ['./device-setting-configuration.component.css']
})
export class DeviceSettingConfigurationComponent implements OnInit {
  index = 0

  links =[
    { name: 'INFORMATION' },
    { name: 'WIRED NETWORK' },
    { name: 'WIFI NETWORK' },
    { name: 'SOFT AP' },
    { name: 'FIRMWARE' },
    { name: 'LAUNCER' },
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
