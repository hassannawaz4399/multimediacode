import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-firmware',
  templateUrl: './configuration-firmware.component.html',
  styleUrls: ['./configuration-firmware.component.css']
})
export class ConfigurationFirmwareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
