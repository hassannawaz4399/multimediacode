import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationFirmwareComponent } from './configuration-firmware.component';

describe('ConfigurationFirmwareComponent', () => {
  let component: ConfigurationFirmwareComponent;
  let fixture: ComponentFixture<ConfigurationFirmwareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationFirmwareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationFirmwareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
