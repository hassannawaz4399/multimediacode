import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationWiredNetworkComponent } from './configuration-wired-network.component';

describe('ConfigurationWiredNetworkComponent', () => {
  let component: ConfigurationWiredNetworkComponent;
  let fixture: ComponentFixture<ConfigurationWiredNetworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationWiredNetworkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationWiredNetworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
