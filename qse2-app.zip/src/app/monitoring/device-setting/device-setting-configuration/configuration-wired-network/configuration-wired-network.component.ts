import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-wired-network',
  templateUrl: './configuration-wired-network.component.html',
  styleUrls: ['./configuration-wired-network.component.css']
})
export class ConfigurationWiredNetworkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
