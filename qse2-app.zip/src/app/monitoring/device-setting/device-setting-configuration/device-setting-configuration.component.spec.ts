import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceSettingConfigurationComponent } from './device-setting-configuration.component';

describe('DeviceSettingConfigurationComponent', () => {
  let component: DeviceSettingConfigurationComponent;
  let fixture: ComponentFixture<DeviceSettingConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceSettingConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceSettingConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
