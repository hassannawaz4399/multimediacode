import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationSoftApComponent } from './configuration-soft-ap.component';

describe('ConfigurationSoftApComponent', () => {
  let component: ConfigurationSoftApComponent;
  let fixture: ComponentFixture<ConfigurationSoftApComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationSoftApComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationSoftApComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
