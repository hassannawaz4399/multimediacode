import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-soft-ap',
  templateUrl: './configuration-soft-ap.component.html',
  styleUrls: ['./configuration-soft-ap.component.css']
})
export class ConfigurationSoftApComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
