import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-launcer',
  templateUrl: './configuration-launcer.component.html',
  styleUrls: ['./configuration-launcer.component.css']
})
export class ConfigurationLauncerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
