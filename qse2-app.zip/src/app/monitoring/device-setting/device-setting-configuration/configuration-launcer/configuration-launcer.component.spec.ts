import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationLauncerComponent } from './configuration-launcer.component';

describe('ConfigurationLauncerComponent', () => {
  let component: ConfigurationLauncerComponent;
  let fixture: ComponentFixture<ConfigurationLauncerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationLauncerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationLauncerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
