import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-wifi-network',
  templateUrl: './configuration-wifi-network.component.html',
  styleUrls: ['./configuration-wifi-network.component.css']
})
export class ConfigurationWifiNetworkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
