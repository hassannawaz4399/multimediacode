import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationWifiNetworkComponent } from './configuration-wifi-network.component';

describe('ConfigurationWifiNetworkComponent', () => {
  let component: ConfigurationWifiNetworkComponent;
  let fixture: ComponentFixture<ConfigurationWifiNetworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationWifiNetworkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationWifiNetworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
