import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuration-information',
  templateUrl: './configuration-information.component.html',
  styleUrls: ['./configuration-information.component.css']
})
export class ConfigurationInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
