import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalsInstantMessageScrollTextAddComponent } from 'src/app/modals/monitoring/device-setting/device-setting-instant-message/instant-message-scroll-text/modals-instant-message-scroll-text-add/modals-instant-message-scroll-text-add.component';
import { InstantMessageScrollTextService } from './instant-message-scroll-text.service';

export interface ScrollText{
  text:string,
  font_size:number,
  text_speed:number,
  font_type:string,
  font_colour:string,
  background_colour:string,
  transparency:number,
  text_scroll:string,
  top:number;
  left:number;
  is_selected:boolean,
}

@Component({
  selector: 'app-instant-message-scroll-text',
  templateUrl: './instant-message-scroll-text.component.html',
  styleUrls: ['./instant-message-scroll-text.component.css']
})
export class InstantMessageScrollTextComponent implements OnInit {

  scrollText

  constructor(
    private instantMessageScrollTextService:InstantMessageScrollTextService,
    
    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.instantMessageScrollTextService.getScrollTextList().subscribe((ScrollList) => {
      this.scrollText = ScrollList
    })
  }

  deleteText(index){
    this.scrollText.splice(index, 1)
  }

  openDialogAddText(action, obj){
    if(this.dialog.openDialogs.length === 0){
      obj.action = action
      const dialogRef = this.dialog.open(ModalsInstantMessageScrollTextAddComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result.event)
        if (result.event === 'Add') {
          
          console.log(result.data)
          this.addText(result.data);
        }
      });
    }
  }

  addText(obj){
    obj.is_selected=false
    this.scrollText.push(obj)
    console.log(this.scrollText)
  }
}
