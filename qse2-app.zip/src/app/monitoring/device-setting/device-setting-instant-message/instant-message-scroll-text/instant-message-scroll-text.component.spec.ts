import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantMessageScrollTextComponent } from './instant-message-scroll-text.component';

describe('InstantMessageScrollTextComponent', () => {
  let component: InstantMessageScrollTextComponent;
  let fixture: ComponentFixture<InstantMessageScrollTextComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstantMessageScrollTextComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstantMessageScrollTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
