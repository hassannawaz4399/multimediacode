import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InstantMessageScrollTextService {

  constructor(
    private http: HttpClient,
  ) { }

  getScrollTextList(): any {
    return this.http.get('assets/json/instant-message-scroll-text-list-data.json');
  }
}
