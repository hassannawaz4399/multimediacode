import { TestBed } from '@angular/core/testing';

import { InstantMessageScrollTextService } from './instant-message-scroll-text.service';

describe('InstantMessageScrollTextService', () => {
  let service: InstantMessageScrollTextService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstantMessageScrollTextService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
