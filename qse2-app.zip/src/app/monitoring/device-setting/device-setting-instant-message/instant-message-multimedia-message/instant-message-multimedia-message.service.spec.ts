import { TestBed } from '@angular/core/testing';

import { InstantMessageMultimediaMessageService } from './instant-message-multimedia-message.service';

describe('InstantMessageMultimediaMessageService', () => {
  let service: InstantMessageMultimediaMessageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstantMessageMultimediaMessageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
