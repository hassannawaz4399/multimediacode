import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalsInstantMessageMultimediaMessageAddImageComponent } from 'src/app/modals/monitoring/device-setting/device-setting-instant-message/instant-message-multimedia-message/modals-instant-message-multimedia-message-add-image/modals-instant-message-multimedia-message-add-image.component';
import { InstantMessageMultimediaMessageService } from './instant-message-multimedia-message.service';

export interface image {
  content: {},
  top: number,
  left: number,
  duration: number,
  is_selected: boolean,
}

@Component({
  selector: 'app-instant-message-multimedia-message',
  templateUrl: './instant-message-multimedia-message.component.html',
  styleUrls: ['./instant-message-multimedia-message.component.css']
})
export class InstantMessageMultimediaMessageComponent implements OnInit {

  image

  constructor(
    private instantMessageMultimediaMessageService:InstantMessageMultimediaMessageService,

    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.instantMessageMultimediaMessageService.getImageList().subscribe((Image) => {
      this.image = Image
      console.log("image", this.image[0].content.title)
    })
  }

  deleteImage(index){
    this.image.splice(index, 1)
  }

  openDialogAddImage(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      obj.action = action
      const dialogRef = this.dialog.open(ModalsInstantMessageMultimediaMessageAddImageComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result.event)
        if (result.event === 'Add') {

          console.log(result.data)
          this.addImage(result.data);
        }
      });
    }
  }

  addImage(obj) {
    obj.is_selected = false
    this.image.push(obj)
  }
}
