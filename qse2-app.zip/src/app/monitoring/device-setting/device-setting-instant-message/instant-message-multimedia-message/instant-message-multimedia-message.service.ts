import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InstantMessageMultimediaMessageService {

  constructor(
    private http: HttpClient,
  ) { }

  getImageList(): any {
    return this.http.get('assets/json/instant-message-multimedia-message-image-list-data.json');
  }
}
