import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantMessageMultimediaMessageComponent } from './instant-message-multimedia-message.component';

describe('InstantMessageMultimediaMessageComponent', () => {
  let component: InstantMessageMultimediaMessageComponent;
  let fixture: ComponentFixture<InstantMessageMultimediaMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstantMessageMultimediaMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstantMessageMultimediaMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
