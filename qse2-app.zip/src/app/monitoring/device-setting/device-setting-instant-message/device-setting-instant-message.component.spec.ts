import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceSettingInstantMessageComponent } from './device-setting-instant-message.component';

describe('DeviceSettingInstantMessageComponent', () => {
  let component: DeviceSettingInstantMessageComponent;
  let fixture: ComponentFixture<DeviceSettingInstantMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceSettingInstantMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceSettingInstantMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
