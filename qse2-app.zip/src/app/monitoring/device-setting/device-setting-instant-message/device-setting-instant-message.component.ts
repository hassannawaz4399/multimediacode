import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-setting-instant-message',
  templateUrl: './device-setting-instant-message.component.html',
  styleUrls: ['./device-setting-instant-message.component.css']
})
export class DeviceSettingInstantMessageComponent implements OnInit {

  index = 0

  links =[
    { name: 'SCROLL TEXT' },
    { name: 'ANNOUNCEMENT' },
    { name: 'MULTIMEDIA MESSAGE' },
    { name: 'EMERGENCY' },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
