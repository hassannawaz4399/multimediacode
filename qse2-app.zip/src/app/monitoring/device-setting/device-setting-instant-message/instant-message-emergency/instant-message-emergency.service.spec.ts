import { TestBed } from '@angular/core/testing';

import { InstantMessageEmergencyService } from './instant-message-emergency.service';

describe('InstantMessageEmergencyService', () => {
  let service: InstantMessageEmergencyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstantMessageEmergencyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
