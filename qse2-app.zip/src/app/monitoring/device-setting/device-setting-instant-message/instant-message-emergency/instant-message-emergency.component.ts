import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { InstantMessageEmergencyService } from './instant-message-emergency.service';
import { ModalsInstantMessageEmergencyAddImageComponent } from 'src/app/modals/monitoring/device-setting/device-setting-instant-message/instant-message-emergency/modals-instant-message-emergency-add-image/modals-instant-message-emergency-add-image.component';

export interface image {
  content: {},
  top: number,
  left: number,
  duration: number,
  is_selected: boolean,
}

@Component({
  selector: 'app-instant-message-emergency',
  templateUrl: './instant-message-emergency.component.html',
  styleUrls: ['./instant-message-emergency.component.css']
})
export class InstantMessageEmergencyComponent implements OnInit {

  image

  constructor(
    private instantMessageEmergencyService:InstantMessageEmergencyService,

    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.instantMessageEmergencyService.getImageList().subscribe((Image) => {
      this.image = Image
      console.log("image", this.image[0].content.title)
    })
  }

  deleteImage(index){
    this.image.splice(index, 1)
  }

  openDialogAddImage(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      obj.action = action
      const dialogRef = this.dialog.open(ModalsInstantMessageEmergencyAddImageComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result.event)
        if (result.event === 'Add') {

          console.log(result.data)
          this.addImage(result.data);
        }
      });
    }
  }

  addImage(obj) {
    obj.is_selected = false
    this.image.push(obj)
  }

}
