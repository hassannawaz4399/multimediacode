import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InstantMessageEmergencyService {

  constructor(
    private http: HttpClient,
  ) { }

  getImageList(): any {
    return this.http.get('assets/json/instant-message-emergency-image-list-data.json');
  }
}
