import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantMessageEmergencyComponent } from './instant-message-emergency.component';

describe('InstantMessageEmergencyComponent', () => {
  let component: InstantMessageEmergencyComponent;
  let fixture: ComponentFixture<InstantMessageEmergencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstantMessageEmergencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstantMessageEmergencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
