import { TestBed } from '@angular/core/testing';

import { InstantMessageAnnouncementService } from './instant-message-announcement.service';

describe('InstantMessageAnnouncementService', () => {
  let service: InstantMessageAnnouncementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstantMessageAnnouncementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
