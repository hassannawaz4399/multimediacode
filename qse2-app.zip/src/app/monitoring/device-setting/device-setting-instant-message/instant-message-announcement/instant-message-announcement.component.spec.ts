import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantMessageAnnouncementComponent } from './instant-message-announcement.component';

describe('InstantMessageAnnouncementComponent', () => {
  let component: InstantMessageAnnouncementComponent;
  let fixture: ComponentFixture<InstantMessageAnnouncementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstantMessageAnnouncementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstantMessageAnnouncementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
