import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalsInstantMessageAnnouncementAddTextComponent } from 'src/app/modals/monitoring/device-setting/device-setting-instant-message/instant-message-announcement/modals-instant-message-announcement-add-text/modals-instant-message-announcement-add-text.component';
import { ModalsInstantMessageAnnouncementAddImageComponent } from 'src/app/modals/monitoring/device-setting/device-setting-instant-message/instant-message-announcement/modals-instant-message-announcement-add-image/modals-instant-message-announcement-add-image.component';
import { InstantMessageAnnouncementService } from './instant-message-announcement.service';

export interface ScrollText{
  text:string,
  font_size:number,
  text_speed:number,
  font_type:string,
  font_colour:string,
  background_colour:string,
  transparency:number,
  text_scroll:string,
  top:number;
  left:number;
  is_selected:boolean,
}

export interface image{
  content: {},
  top: number,
  left: number,
  duration: number,
  is_selected:boolean,
}

@Component({
  selector: 'app-instant-message-announcement',
  templateUrl: './instant-message-announcement.component.html',
  styleUrls: ['./instant-message-announcement.component.css']
})
export class InstantMessageAnnouncementComponent implements OnInit {

  scrollText
  image
  
  constructor(
    private instantMessageAnnouncementService:InstantMessageAnnouncementService,
    
    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.instantMessageAnnouncementService.getScrollTextList().subscribe((ScrollList) => {
      this.scrollText = ScrollList
    })

    this.instantMessageAnnouncementService.getImageList().subscribe((Image) => {
      this.image = Image
      console.log("image", this.image[0].content.title)
    })
  }

  deleteText(index){
    this.scrollText.splice(index, 1)
  }

  openDialogAddText(action, obj){
    if(this.dialog.openDialogs.length === 0){
      obj.action = action
      const dialogRef = this.dialog.open(ModalsInstantMessageAnnouncementAddTextComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result.event)
        if (result.event === 'Add') {
          
          console.log(result.data)
          this.addText(result.data);
        }
      });
    }
  }

  addText(obj){
    obj.is_selected=false
    this.scrollText.push(obj)
    console.log(this.scrollText)
  }

  deleteImage(index){
    this.image.splice(index, 1)
  }

  openDialogAddImage(action, obj){
    if(this.dialog.openDialogs.length === 0){
      obj.action = action
      const dialogRef = this.dialog.open(ModalsInstantMessageAnnouncementAddImageComponent, {
        data: obj,
        width: '50%',
        height: '80.1%'
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log(result.event)
        if (result.event === 'Add') {
          
          console.log(result.data)
          this.addImage(result.data);
        }
      });
    }
  }

  addImage(obj){
    obj.is_selected=false
    this.image.push(obj)
  }
}
