import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InstantMessageAnnouncementService {

  constructor(
    private http: HttpClient,
  ) { }

  getScrollTextList(): any {
    return this.http.get('assets/json/instant-message-announcement-text-list-data.json');
  }

  getImageList(): any {
    return this.http.get('assets/json/instant-message-announcement-image-list-data.json');
  }
}
