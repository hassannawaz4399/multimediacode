import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-setting-playlist-schedule',
  templateUrl: './device-setting-playlist-schedule.component.html',
  styleUrls: ['./device-setting-playlist-schedule.component.css']
})
export class DeviceSettingPlaylistScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
