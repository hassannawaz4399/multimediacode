import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceSettingPlaylistScheduleComponent } from './device-setting-playlist-schedule.component';

describe('DeviceSettingPlaylistScheduleComponent', () => {
  let component: DeviceSettingPlaylistScheduleComponent;
  let fixture: ComponentFixture<DeviceSettingPlaylistScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceSettingPlaylistScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceSettingPlaylistScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
