import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-video-wall',
  templateUrl: './control-video-wall.component.html',
  styleUrls: ['./control-video-wall.component.css']
})
export class ControlVideoWallComponent implements OnInit {

  input: string[] = ['HDMI', 'Others']
  selectedInput: string = 'HDMI'

  screenPosition: string[] = ['3 x 2', '16 x 9']
  selectedScreenPosition: string = '3 x 2'


  constructor() { }

  ngOnInit(): void {
  }

}
