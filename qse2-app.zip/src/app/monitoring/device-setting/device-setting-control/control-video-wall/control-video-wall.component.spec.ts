import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlVideoWallComponent } from './control-video-wall.component';

describe('ControlVideoWallComponent', () => {
  let component: ControlVideoWallComponent;
  let fixture: ComponentFixture<ControlVideoWallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlVideoWallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlVideoWallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
