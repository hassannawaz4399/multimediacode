import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceSettingControlComponent } from './device-setting-control.component';

describe('DeviceSettingControlComponent', () => {
  let component: DeviceSettingControlComponent;
  let fixture: ComponentFixture<DeviceSettingControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceSettingControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceSettingControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
