import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { PhxSocketService } from 'src/app/services/socket/phx-socket.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-control-application',
  templateUrl: './control-application.component.html',
  styleUrls: ['./control-application.component.css']
})
export class ControlApplicationComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  selected_device:any [] = []
  selected_branch:any = {}

  constructor(
    private deviceListService: DeviceListService,
    private websocket : PhxSocketService,
  ) {
    this.subscription.push( deviceListService.selectedDetails.subscribe(SelectedDevice => {
      this.selected_device = JSON.parse(SelectedDevice)
    }))

    this.subscription.push( deviceListService.selectedBranch.subscribe(SelectedBranch => {
      this.selected_branch = JSON.parse(SelectedBranch)
    }))
   }

  ngOnInit(): void {
    this.selected_device = this.deviceListService.getSelectedDetails()
    this.selected_branch = this.deviceListService.getSelectedBranch()
    console.log(this.selected_device)
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at control-application")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  restart(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"app",
        action:"restart"
      })
    }
  }

  upgrade(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"app",
        action:"upgrade"
      })
    }
  }

  remove(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"app",
        action:"remove"
      })
    }
  }

  reset(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"app",
        action:"reset"
      })
    }
  }
}
