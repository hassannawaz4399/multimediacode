import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlApplicationComponent } from './control-application.component';

describe('ControlApplicationComponent', () => {
  let component: ControlApplicationComponent;
  let fixture: ComponentFixture<ControlApplicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlApplicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
