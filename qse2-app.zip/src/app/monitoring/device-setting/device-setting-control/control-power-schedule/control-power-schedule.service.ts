import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ControlPowerScheduleService {

  constructor(
    private http: HttpClient,
  ) { }

  getControlPowerSchedulePowerOnListData(): any {
    return this.http.get('assets/json/control-power-schedule-power-on-list-data.json');
  }
  getControlPowerSchedulePowerOffListData(): any {
    return this.http.get('assets/json/control-power-schedule-power-off-list-data.json');
  }
  getControlPowerScheduleRebootListData(): any {
    return this.http.get('assets/json/control-power-schedule-reboot-list-data.json');
  }
}
