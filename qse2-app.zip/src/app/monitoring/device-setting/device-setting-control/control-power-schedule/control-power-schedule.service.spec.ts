import { TestBed } from '@angular/core/testing';

import { ControlPowerScheduleService } from './control-power-schedule.service';

describe('ControlPowerScheduleService', () => {
  let service: ControlPowerScheduleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ControlPowerScheduleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
