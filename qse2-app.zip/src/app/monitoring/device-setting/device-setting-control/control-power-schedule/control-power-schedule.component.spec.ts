import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlPowerScheduleComponent } from './control-power-schedule.component';

describe('ControlPowerScheduleComponent', () => {
  let component: ControlPowerScheduleComponent;
  let fixture: ComponentFixture<ControlPowerScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlPowerScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPowerScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
