import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { ControlPowerScheduleService } from './control-power-schedule.service';

export interface PowerStatus{
  time:string,
  repeat:string[],
  input:string,
  is_selected:boolean,
}

@Component({
  selector: 'app-control-power-schedule',
  templateUrl: './control-power-schedule.component.html',
  styleUrls: ['./control-power-schedule.component.css']
})

export class ControlPowerScheduleComponent implements OnInit {

  input = ['HDMI', 'Other']
  SelectInput = 'HDMI'
  currentStatus = 'powerOn'
  repeatDay = []
  time =''

  powerStatusListDisplayColumn: string[] = ['action', 'time', 'repeat', 'input']

  powerStatusList: MatTableDataSource<PowerStatus>

  
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(
    private controlPowerScheduleService:ControlPowerScheduleService,
  ) { }

  ngOnInit(): void {
    this.controlPowerScheduleService.getControlPowerSchedulePowerOnListData().subscribe((ControlPowerStatus) => {
      this.powerStatusList = new MatTableDataSource<PowerStatus>(ControlPowerStatus)
    })
  }

  statusChange(event){

    if(event == "powerOn"){
      this.controlPowerScheduleService.getControlPowerSchedulePowerOnListData().subscribe((ControlPowerStatus) => {
        this.powerStatusList = new MatTableDataSource<PowerStatus>(ControlPowerStatus)
      })
    }
    else if(event == "powerOff"){
      this.controlPowerScheduleService.getControlPowerSchedulePowerOffListData().subscribe((ControlPowerStatus) => {
        this.powerStatusList = new MatTableDataSource<PowerStatus>(ControlPowerStatus)
      })
    }
    else if(event == "reboot"){
      this.controlPowerScheduleService.getControlPowerScheduleRebootListData().subscribe((ControlPowerStatus) => {
        this.powerStatusList = new MatTableDataSource<PowerStatus>(ControlPowerStatus)
      })
    }
  }

  addToCurrent(){
    let data = this.powerStatusList.data

    data.unshift(
      {
        time:this.time,
        repeat:this.repeatDay,
        input:this.SelectInput,
        is_selected:false
      }
    )

    this.powerStatusList.data = data

    this.table.renderRows();
  }
}
