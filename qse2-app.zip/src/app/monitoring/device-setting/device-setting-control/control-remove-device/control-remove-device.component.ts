import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { BranchService } from 'src/app/services/monitoring/branch.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-control-remove-device',
  templateUrl: './control-remove-device.component.html',
  styleUrls: ['./control-remove-device.component.css']
})
export class ControlRemoveDeviceComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  selected_device:any [] = []
  selected_branch:any = {}

  constructor(
    private deviceListService: DeviceListService,
    private branchService: BranchService
  ) {
    this.subscription.push( deviceListService.selectedDetails.subscribe(SelectedDevice => {
      this.selected_device = JSON.parse(SelectedDevice)
    }))

    this.subscription.push( deviceListService.selectedBranch.subscribe(SelectedBranch => {
      this.selected_branch = JSON.parse(SelectedBranch)
    }))
   }

  ngOnInit(): void {
    this.selected_device = this.deviceListService.getSelectedDetails()
    this.selected_branch = this.deviceListService.getSelectedBranch()
    console.log(this.selected_device)
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at control remove device")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  removedevice(){
    let count = 0

    for(const item of this.selected_device){
      this.branchService.remove_device(item.devices.device_id).subscribe(resp => {
        if(resp.data.result === 'success'){
        }
        else{
          console.log("error: ", item)
        }
        count ++
      })
    }

    if(count == this.selected_device.length){
      this.deviceListService.setCheckedbox("allClose")
    }
  }
}
