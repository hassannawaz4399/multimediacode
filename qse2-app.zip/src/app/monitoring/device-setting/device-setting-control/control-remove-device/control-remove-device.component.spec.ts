import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlRemoveDeviceComponent } from './control-remove-device.component';

describe('ControlRemoveDeviceComponent', () => {
  let component: ControlRemoveDeviceComponent;
  let fixture: ComponentFixture<ControlRemoveDeviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlRemoveDeviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlRemoveDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
