import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlStorageComponent } from './control-storage.component';

describe('ControlStorageComponent', () => {
  let component: ControlStorageComponent;
  let fixture: ComponentFixture<ControlStorageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlStorageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlStorageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
