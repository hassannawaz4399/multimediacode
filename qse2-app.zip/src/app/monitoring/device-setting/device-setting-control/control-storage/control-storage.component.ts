import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-storage',
  templateUrl: './control-storage.component.html',
  styleUrls: ['./control-storage.component.css']
})
export class ControlStorageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
