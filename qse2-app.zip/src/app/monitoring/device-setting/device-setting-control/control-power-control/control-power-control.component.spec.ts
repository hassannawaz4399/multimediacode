import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlPowerControlComponent } from './control-power-control.component';

describe('ControlPowerControlComponent', () => {
  let component: ControlPowerControlComponent;
  let fixture: ComponentFixture<ControlPowerControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlPowerControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPowerControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
