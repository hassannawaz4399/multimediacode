import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { PhxSocketService } from 'src/app/services/socket/phx-socket.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-control-power-control',
  templateUrl: './control-power-control.component.html',
  styleUrls: ['./control-power-control.component.css']
})
export class ControlPowerControlComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  selected_device:any [] = []
  selected_branch:any = {}

  panel_status:string = "Panel On"
  power_status:string = "Power On"

  remote:boolean = true

  powerControl=[
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:true, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:true, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:false, duration: '1 hour 20 minutes'},
    {date:'20/01/2020', time:'10:10 PM', status:true, duration: '1 hour 20 minutes'},
  ]

  constructor(
    private deviceListService: DeviceListService,
    private websocket : PhxSocketService,
  ) {
    this.subscription.push( deviceListService.selectedDetails.subscribe(SelectedDevice => {
      this.selected_device = JSON.parse(SelectedDevice)
    }))

    this.subscription.push( deviceListService.selectedBranch.subscribe(SelectedBranch => {
      this.selected_branch = JSON.parse(SelectedBranch)
    }))

    this.subscription.push( websocket.remote.subscribe(resp => {
      if (resp.branch_id == this.selected_branch.branch_id) {
        if (resp.device_id == this.selected_device[0].devices.device_id) {
          this.remote = resp.status
        }
      }
    }))

    this.subscription.push( websocket.panel.subscribe(resp => {
      if(this.selected_branch.branch_id == resp.branch_id){
        if(this.selected_device[0].devices.device_id == resp.device_id){
          this.selected_device[0].devices.panel = resp.status

          if(this.selected_device[0].devices.panel){
            this.panel_status = "Panel On"
          }else{
            this.panel_status = "Panel Off"
          }
        }
      }
    }))

    this.subscription.push( websocket.online.subscribe(resp => {
      if(this.selected_branch.branch_id == resp.branch_id){
        if(this.selected_device[0].devices.device_id == resp.device_id){
          this.selected_device[0].devices.online = resp.status
        }

        if(this.selected_device[0].devices.online){
          this.power_status = "Power On"
        }else{
          this.power_status = "Power Off"
        }
      }
    }))

   }

  ngOnInit(): void {
    this.selected_device = this.deviceListService.getSelectedDetails()
    this.selected_branch = this.deviceListService.getSelectedBranch()

    if(this.selected_device[0].devices.online){
      this.power_status = "Power On"
    }else{
      this.power_status = "Power Off"
    }

    if(this.selected_device[0].devices.panel){
      this.panel_status = "Panel On"
    }else{
      this.panel_status = "Panel Off"
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at control-power-control")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  on(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"power",
        action:"on"
      })
    }
    console.log("On Branch: ", JSON.stringify(this.selected_branch))
    console.log("On Device: ", JSON.stringify(this.selected_device))
  }

  off(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"power",
        action:"off"
      })
    }
    console.log("Off Branch: ", this.selected_branch)
    console.log("Off Device: ", this.selected_device)
  }

  reboot(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"power",
        action:"reboot"
      })
    }
    console.log("Reboot Branch: ", this.selected_branch)
    console.log("Reboot Device: ", this.selected_device)
  }

  panel_on(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"panel",
        action:"on"
      })
    }
  }

  panel_off(){
    for(const item of this.selected_device){
      this.websocket.send({
        device_id:item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd:"device",
        type:"panel",
        action:"off"
      })
    }
  }

  getStatus() {
    for (const item of this.selected_device) {
      this.websocket.send({
        device_id: item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd: "device",
        type: "remote",
        action: "status"
      })
    }
  }

  toggleremote(event) {
    if(event.checked){
      for (const item of this.selected_device) {
        this.websocket.send({
          device_id: item.devices.device_id,
          Branch_id: this.selected_branch.branch_id,
          cmd: "device",
          type: "remote",
          action: "on"
        })
      }
    }
    else{
      for (const item of this.selected_device) {
        this.websocket.send({
          device_id: item.devices.device_id,
          Branch_id: this.selected_branch.branch_id,
          cmd: "device",
          type: "remote",
          action: "off"
        })
      }
    }
  }
}
