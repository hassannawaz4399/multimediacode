import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlPictureComponent } from './control-picture.component';

describe('ControlPictureComponent', () => {
  let component: ControlPictureComponent;
  let fixture: ComponentFixture<ControlPictureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlPictureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPictureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
