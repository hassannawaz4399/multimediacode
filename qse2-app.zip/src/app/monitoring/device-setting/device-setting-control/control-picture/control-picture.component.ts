import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-picture',
  templateUrl: './control-picture.component.html',
  styleUrls: ['./control-picture.component.css']
})
export class ControlPictureComponent implements OnInit {

  pictureMode = ['Cinema', 'Other']
  SelectPictureMode = 'Cinema'
  
  constructor() { }

  ngOnInit(): void {
  }

}
