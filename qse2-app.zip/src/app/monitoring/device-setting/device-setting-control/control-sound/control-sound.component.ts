import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { PhxSocketService } from 'src/app/services/socket/phx-socket.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-control-sound',
  templateUrl: './control-sound.component.html',
  styleUrls: ['./control-sound.component.css']
})
export class ControlSoundComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  soundMode: string[] = ['Standard', 'Music', 'Movie', 'Clear Voice', 'amplify']
  soundOutput: string[] = ['Standard', 'Music', 'Movie', 'Clear Voice', 'amplify']

  selectSoundMode = 'Standard'
  selectSoundOutput = 'Standard'

  selected_device: any[] = []
  selected_branch: any = {}

  volumeLevel = 0
  balancevalue = 0
  mute = false;

  constructor(
    private deviceListService: DeviceListService,
    private websocket: PhxSocketService,
  ) {
    this.subscription.push( deviceListService.selectedDetails.subscribe(SelectedDevice => {
      this.selected_device = JSON.parse(SelectedDevice)
    }))

    this.subscription.push( deviceListService.selectedBranch.subscribe(SelectedBranch => {
      this.selected_branch = JSON.parse(SelectedBranch)
    }))

    this.subscription.push( websocket.volume.subscribe(resp => {
      if (resp.branch_id == this.selected_branch.branch_id) {
        if (resp.device_id == this.selected_device[0].devices.device_id) {
          if (resp.level == -1) {
            this.mute = true;
            this.volumeLevel = 0
          }
          else {
            this.mute = false
            this.volumeLevel = resp.level
          }
        }
      }
    }))
  }

  ngOnInit(): void {
    this.selected_device = this.deviceListService.getSelectedDetails()
    this.selected_branch = this.deviceListService.getSelectedBranch()
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at control-sound")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }
  
  minusvalue() {
    if (this.volumeLevel != 0) {
      this.volumeLevel--
      for (const item of this.selected_device) {
        this.websocket.send({
          device_id: item.devices.device_id,
          Branch_id: this.selected_branch.branch_id,
          cmd: "device",
          type: "volume",
          action: "down",
          level: this.volumeLevel
        })
      }
    }
  }

  addvalue() {
    if (this.volumeLevel != 100) {
      this.volumeLevel++
      for (const item of this.selected_device) {
        this.websocket.send({
          device_id: item.devices.device_id,
          Branch_id: this.selected_branch.branch_id,
          cmd: "device",
          type: "volume",
          action: "up",
          level: this.volumeLevel
        })
      }
    }
  }

  toggleMute(event) {
    for (const item of this.selected_device) {
      this.websocket.send({
        device_id: item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd: "device",
        type: "volume",
        action: "mute"
      })
    }
  }

  getStatus() {
    for (const item of this.selected_device) {
      this.websocket.send({
        device_id: item.devices.device_id,
        Branch_id: this.selected_branch.branch_id,
        cmd: "device",
        type: "volume",
        action: "status"
      })
    }
  }
}
