import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlSoundComponent } from './control-sound.component';

describe('ControlSoundComponent', () => {
  let component: ControlSoundComponent;
  let fixture: ComponentFixture<ControlSoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlSoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlSoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
