import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-setting-control',
  templateUrl: './device-setting-control.component.html',
  styleUrls: ['./device-setting-control.component.css']
})
export class DeviceSettingControlComponent implements OnInit {

  index = 'POWER CONTROL'

  links =[
    // { name: 'PLAYER VIEW' },
    { name: 'POWER CONTROL' },
    // { name: 'POWER SCHEDULE' },
    { name: 'SOUND' },
    // { name: 'PICTURE' },
    // { name: 'VIDEO WALL' },
    // { name: 'STORAGE' },
    { name: 'APPLICATION' },
    { name: 'REMOVE DEVICE' }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
