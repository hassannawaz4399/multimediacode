import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlPlayerViewComponent } from './control-player-view.component';

describe('ControlPlayerViewComponent', () => {
  let component: ControlPlayerViewComponent;
  let fixture: ComponentFixture<ControlPlayerViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlPlayerViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPlayerViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
