import { TestBed } from '@angular/core/testing';

import { ControlPlayerViewService } from './control-player-view.service';

describe('ControlPlayerViewService', () => {
  let service: ControlPlayerViewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ControlPlayerViewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
