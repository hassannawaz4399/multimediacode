import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ControlPlayerViewService {

  constructor(
    private http: HttpClient,
  ) { }

  getPlayerViewPlaylistScheduleListData(): any {
    return this.http.get('assets/json/player-view-playlist-schedule-list-data.json');
  }
}
