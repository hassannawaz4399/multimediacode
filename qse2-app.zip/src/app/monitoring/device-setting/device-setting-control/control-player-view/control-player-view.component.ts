import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ControlPlayerViewService } from './control-player-view.service';

export interface PlaylistSchedule{
  zone:string;
  previous:string;
  current:string;
  next:string;
}

@Component({
  selector: 'app-control-player-view',
  templateUrl: './control-player-view.component.html',
  styleUrls: ['./control-player-view.component.css']
})
export class ControlPlayerViewComponent implements OnInit {

  view = "http://id.qubit.asia:8081//1587986621053-Apink.mp4"
  // view = "http://localhost:8081//1587737534053-BTS - The Truth Untold (전하지 못한 진심) (feat. Steve Aoki) (Color Coded.mp4"
  
  device: string[] = ['HDMI', 'Others']
  selectedDevice: string = 'HDMI'

  scheduleListDisplayColumn: string[] = ['zone', 'previous', 'current', 'next']

  scheduleList: MatTableDataSource<PlaylistSchedule>

  constructor(
    private controlPlayerViewService:ControlPlayerViewService,
  ) { }

  ngOnInit(): void {
    this.controlPlayerViewService.getPlayerViewPlaylistScheduleListData().subscribe((ControlPlayerView) => {
      this.scheduleList = new MatTableDataSource<PlaylistSchedule>(ControlPlayerView)
    })
  }

}
