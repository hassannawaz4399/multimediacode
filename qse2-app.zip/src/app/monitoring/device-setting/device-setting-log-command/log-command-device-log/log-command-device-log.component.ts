import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { LogCommandDeviceLogService } from './log-command-device-log.service';

export interface DeviceLog{
  time:string,
  event:string,
  triggered_by:string,
}

@Component({
  selector: 'app-log-command-device-log',
  templateUrl: './log-command-device-log.component.html',
  styleUrls: ['./log-command-device-log.component.css']
})
export class LogCommandDeviceLogComponent implements OnInit {

  deviceLogListDisplayColumn: string[] = ['time', 'event', 'triggered_by']

  deviceLogList: MatTableDataSource<DeviceLog>

  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(
    private logCommandDeviceLogService:LogCommandDeviceLogService,
  ) { }

  ngOnInit(): void {
    this.logCommandDeviceLogService.getLogCommandPowerLogListData().subscribe((LogCommandPowerLog) => {
      this.deviceLogList = new MatTableDataSource<DeviceLog>(LogCommandPowerLog)
    })
  }
}
