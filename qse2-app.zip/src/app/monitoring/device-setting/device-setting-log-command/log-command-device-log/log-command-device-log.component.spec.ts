import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogCommandDeviceLogComponent } from './log-command-device-log.component';

describe('LogCommandDeviceLogComponent', () => {
  let component: LogCommandDeviceLogComponent;
  let fixture: ComponentFixture<LogCommandDeviceLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogCommandDeviceLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogCommandDeviceLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
