import { TestBed } from '@angular/core/testing';

import { LogCommandDeviceLogService } from './log-command-device-log.service';

describe('LogCommandDeviceLogService', () => {
  let service: LogCommandDeviceLogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LogCommandDeviceLogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
