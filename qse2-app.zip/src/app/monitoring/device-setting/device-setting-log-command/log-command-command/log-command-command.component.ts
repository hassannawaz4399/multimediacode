import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-command-command',
  templateUrl: './log-command-command.component.html',
  styleUrls: ['./log-command-command.component.css']
})
export class LogCommandCommandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
