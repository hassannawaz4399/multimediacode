import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogCommandCommandComponent } from './log-command-command.component';

describe('LogCommandCommandComponent', () => {
  let component: LogCommandCommandComponent;
  let fixture: ComponentFixture<LogCommandCommandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogCommandCommandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogCommandCommandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
