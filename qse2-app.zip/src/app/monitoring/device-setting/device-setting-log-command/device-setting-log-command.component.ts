import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-setting-log-command',
  templateUrl: './device-setting-log-command.component.html',
  styleUrls: ['./device-setting-log-command.component.css']
})
export class DeviceSettingLogCommandComponent implements OnInit {

  index = 0

  links =[
    { name: 'POWER LOG' },
    { name: 'DEVICE LOG' },
    { name: 'COMMAND' }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
