import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LogCommandPowerLogService {

  constructor(
    private http: HttpClient,
  ) { }

  getLogCommandPowerLogListData(): any {
    return this.http.get('assets/json/log-command-power-log-list-data.json');
  }

}
