import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { LogCommandPowerLogService } from './log-command-power-log.service';

export interface PowerLog{
  time:string,
  event:string,
  triggered_by:string,
}

@Component({
  selector: 'app-log-command-power-log',
  templateUrl: './log-command-power-log.component.html',
  styleUrls: ['./log-command-power-log.component.css']
})
export class LogCommandPowerLogComponent implements OnInit {

  powerLogListDisplayColumn: string[] = ['time', 'event', 'triggered_by']

  powerLogList: MatTableDataSource<PowerLog>

  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(
    private logCommandPowerLogService:LogCommandPowerLogService,
  ) { }

  ngOnInit(): void {
    this.logCommandPowerLogService.getLogCommandPowerLogListData().subscribe((LogCommandPowerLog) => {
      this.powerLogList = new MatTableDataSource<PowerLog>(LogCommandPowerLog)
    })
  }

}
