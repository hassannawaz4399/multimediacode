import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogCommandPowerLogComponent } from './log-command-power-log.component';

describe('LogCommandPowerLogComponent', () => {
  let component: LogCommandPowerLogComponent;
  let fixture: ComponentFixture<LogCommandPowerLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogCommandPowerLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogCommandPowerLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
