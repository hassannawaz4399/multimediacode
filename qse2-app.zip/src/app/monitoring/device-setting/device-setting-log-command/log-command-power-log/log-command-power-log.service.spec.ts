import { TestBed } from '@angular/core/testing';

import { LogCommandPowerLogService } from './log-command-power-log.service';

describe('LogCommandPowerLogService', () => {
  let service: LogCommandPowerLogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LogCommandPowerLogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
