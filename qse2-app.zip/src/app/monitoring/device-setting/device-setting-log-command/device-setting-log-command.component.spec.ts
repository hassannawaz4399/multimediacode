import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceSettingLogCommandComponent } from './device-setting-log-command.component';

describe('DeviceSettingLogCommandComponent', () => {
  let component: DeviceSettingLogCommandComponent;
  let fixture: ComponentFixture<DeviceSettingLogCommandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceSettingLogCommandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceSettingLogCommandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
