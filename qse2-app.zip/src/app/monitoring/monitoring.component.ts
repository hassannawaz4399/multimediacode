import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../layout/layout.service';
import { DeviceListService } from './device-list/device-list.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-monitoring',
  templateUrl: './monitoring.component.html',
  styleUrls: ['./monitoring.component.css']
})
export class MonitoringComponent implements OnInit {

  subscription : Subscription[] = []

  branchstate = null
  schedulestate = false

  path = ''

  lengthSelected = 0

  constructor(
    private layoutService: LayoutService,
    private deviceListService:DeviceListService,
  ) { 
    this.subscription.push( deviceListService.scheduleState.subscribe(state => {
      this.schedulestate = state
    }))

    this.subscription.push( deviceListService.branchState.subscribe(state => {
      this.branchstate = state
    }))

    this.subscription.push( deviceListService.pathDevice.subscribe(pathDevice => {
      this.path = pathDevice
    }))

    this.subscription.push( deviceListService.selectedDetails.subscribe(SelectedDevice => {
      let selected_device = JSON.parse(SelectedDevice)
      this.lengthSelected = selected_device.length
    }))
  }

  ngOnInit(): void {
    this.layoutService.toggleLeft(true);
    
    this.branchstate = this.deviceListService.getBranchState()
    this.path = this.deviceListService.getPathDevice()
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at monitoring")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }
  togglerightNav(){
    this.layoutService.toggleRight();
  }
  
  refreshDeviceTable(){
    if(this.branchstate){
      this.goToBranchList()
    }
    else{
      this.deviceListService.refreshLocation()
    }
  }

  goToBranchList(){
    this.deviceListService.refreshBranch()
  }

  closerightNav(){
    this.deviceListService.setCheckedbox("allClose")
  }
}
