import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {

  testurl = 'http://' + window.location.hostname + ':4005';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  add_schedule(new_schedule: any): Observable<any> {
    const item = { add_new_schedule: new_schedule };
    return this.http.post<any>(this.testurl + '/qse/schedule/add_new_schedule', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  getScheduleChannel(channel_id: any): any {
    return this.http.get(this.testurl + '/qse/schedule/get_schedule_channel/' + channel_id);
  }

  getScheduleDevice(device_id: any): any {
    return this.http.get(this.testurl + '/qse/schedule/get_schedule_device/' + device_id);
  }

  getScheduleInfo(schedule_id: any): any {
    return this.http.get(this.testurl + '/qse/schedule/get_schedule_info/' + schedule_id);
  }

  deleteSchedule(schedule_id: any): Observable<any> {
    const item = { delete_schedule: schedule_id };
    return this.http.post<any>(this.testurl + '/qse/schedule/delete_schedule', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  updateSchedule(latest_schedule: any): Observable<any> {
    const item = { update_schedule: latest_schedule };
    return this.http.post<any>(this.testurl + '/qse/schedule/update_schedule', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  checkRecurring(recurringSchedule: any): Observable<any> {
    const item = { check_recurring: recurringSchedule };
    return this.http.post<any>(this.testurl + '/qse/schedule/check_recurring', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
