import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ContentManagerService {

  cmsUrl = ''
  @Output() updateRow: EventEmitter<any> = new EventEmitter();
  
  // testurl = 'http://localhost:4002/';
  testurl = 'http://' + window.location.hostname + ':4002/';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  //http://id.qubit.asia:4002/content-manager
  //http://localhost:4002/content-manager

  getContentManagerListData(): any {
    return this.http.get(this.testurl + '/qcm/files');
  }

  getCmsInfo(): any {
    return this.http.get(this.testurl + '/qcm/cmsinfo');
  }

  getContentManagerListParentData(id): any {
    return this.http.get(this.testurl + '/qcm/files/id/' + id);
  }

  rename(id, dir: any): Observable<any> {
    const item = { rename: dir };
    return this.http.post<any>(this.testurl + '/qcm/files/rename/id/' + id, JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  delete(id): Observable<any> {
    return this.http.post<any>('/qcm/files/delete/id/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  upload_file(formData) {
    return this.http
      .post(this.testurl + '/qcm/files/file_upload', formData, {
        reportProgress: true,
        observe: "events"
      });
  }

  post_dir(dir: any): Observable<any> {
    const item = { directory: dir };
    return this.http.post<any>(this.testurl + '/qcm/files/add', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  check_dir(dir: any): Observable<any> {
    const item = { check: dir };
    return this.http.post<any>(this.testurl + '/qcm/files/add', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  copy(dir: any): Observable<any> {
    const item = { copy: dir };
    return this.http.post<any>(this.testurl + '/qcm/files/copy', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  move(dir: any): Observable<any> {
    const item = { move: dir };
    return this.http.post<any>(this.testurl + '/qcm/files/move', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }


  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  add_update(data) {
    this.updateRow.emit(data);
  }

  setCmsUrl(data): void {
    this.cmsUrl = data.cms_proto + '://' + data.cms_ip + ':' + data.cms_port + data.cms_path;
  }

  getCmsUrl() {
    return this.cmsUrl;
  }
}
