import { TestBed } from '@angular/core/testing';

import { PlaylistTemplateService } from './playlist-template.service';

describe('PlaylistTemplateService', () => {
  let service: PlaylistTemplateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlaylistTemplateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
