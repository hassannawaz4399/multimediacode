import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlaylistTemplateService {

  // testurl = 'http://localhost:4002/';
  testurl = 'http://' + window.location.hostname + ':4002';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  // http://id.qubit.asia:4002/qcm/templatesinfo

  getTemplatesInfoListData(): any {
    return this.http.get(this.testurl + '/qcm/templatesinfo');
  }

  getOneTemplate(template_name: any): any {
    return this.http.get(this.testurl + '/qcm/templatesinfo/find_template/' + template_name);
  }
}
