import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PlaylistService {

  // testurl = 'http://id.qubit.asia:4005/';
  // testurl = 'http://localhost:4005';
  testurl = 'http://' + window.location.hostname + ':4005';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  getPlaylistListData(): any {
    return this.http.get(this.testurl + '/qse/playlist');
  }

  getAllPlaylistListData(): any {
    return this.http.get(this.testurl + '/qse/playlist/get_all_playlist_info');
  }

  getOnePlaylist(playlist_name: any): any {
    return this.http.get(this.testurl + '/qse/playlist/get_one_playlist/' + playlist_name);
  }

  checkPlaylistName(playlist_name: any): Observable<any> {
    const item = { check_name: playlist_name };
    return this.http.post<any>(this.testurl + '/qse/playlist/check_playlist_name', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  delete_playlist(playlist_name: any): Observable<any> {
    const item = { delete_playlist: playlist_name };
    return this.http.post<any>(this.testurl + '/qse/playlist/delete_playlist', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  update_playlist(update_playlists: any): Observable<any> {
    const item = { update_playlist: update_playlists };
    return this.http.post<any>(this.testurl + '/qse/playlist/update_playlist', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  add_playlist(new_playlist: any): Observable<any> {
    const item = { add_new_playlist: new_playlist };
    return this.http.post<any>(this.testurl + '/qse/playlist/add_new_playlist', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  duplicate(duplicateplaylist: any): Observable<any> {
    const item = { duplicate_playlist: duplicateplaylist };
    return this.http.post<any>(this.testurl + '/qse/playlist/duplicate_playlist', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

}
