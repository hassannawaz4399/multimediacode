import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ChannelService {

  // testurl = 'http://id.qubit.asia:4005/';
  // testurl = 'http://localhost:4005';
  testurl = 'http://' + window.location.hostname + ':4005';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  getChannelListData(): any {
    return this.http.get(this.testurl + '/qse/channel');
  }

  getOneChannel(channel_name: any): any {
    return this.http.get(this.testurl + '/qse/channel/get_one_channel/' + channel_name);
  }

  getlinkedDevice(): any {
    return this.http.get(this.testurl + '/qse/channel/get_linked_devices');
  }

  checkChannelName(channel_name: any): Observable<any> {
    const item = { check_name: channel_name };
    return this.http.post<any>(this.testurl + '/qse/channel/check_channel_name', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  add_channel(new_channel: any): Observable<any> {
    const item = { add_new_channel: new_channel };
    return this.http.post<any>(this.testurl + '/qse/channel/add_new_channel', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  update_channel(updatechannel: any): Observable<any> {
    const item = { update_channel: updatechannel };
    return this.http.post<any>(this.testurl + '/qse/channel/update_channel', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  delete_channel(channel_name: any): Observable<any> {
    const item = { delete_channel: channel_name };
    return this.http.post<any>(this.testurl + '/qse/channel/delete_channel', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
