import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ContentManagerOldService {

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  @Output() updateRow: EventEmitter<any> = new EventEmitter();

  constructor(
    private http: HttpClient
  ) { }

  //http://id.qubit.asia:4000/content-manager

  getContentManagerListData(): any {
    return this.http.get('http://id.qubit.asia:4002/qcm/files');
  }

  getContentManagerListParentData(id): any {
    return this.http.get('http://id.qubit.asia:4002/qcm/files/id/' + id);
  }

  rename(id, dir: any): Observable<any> {
    const item = { rename: dir };
    return this.http.post<any>('http://id.qubit.asia:4002/qcm/files/rename/id/' + id, JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  delete(id): Observable<any> {
    return this.http.post<any>('http://id.qubit.asia:4002/qcm/files/delete/id/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  upload_file(formData) {
    return this.http
      .post('http://id.qubit.asia:4002/qcm/files/file_upload', formData, {
        reportProgress: true,
        observe: "events"
      });
  }

  post_dir(dir: any): Observable<any> {
    const item = { directory: dir };
    return this.http.post<any>('http://id.qubit.asia:4002/qcm/files/add', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  add_update(data) {
    this.updateRow.emit(data);
  }
}
