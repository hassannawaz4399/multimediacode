import { TestBed } from '@angular/core/testing';

import { ContentManagerOldService } from './content-manager-old.service';

describe('ContentManagerOldService', () => {
  let service: ContentManagerOldService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContentManagerOldService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
