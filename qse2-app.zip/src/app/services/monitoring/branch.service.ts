import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BranchService {

  testurl = 'http://' + window.location.hostname + ':4005';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient
  ) { }

  getBranchListData(): any {
    return this.http.get(this.testurl + '/qse/branch');
  }

  getUnapproveDevice(): any {
    return this.http.get(this.testurl + '/qse/branch/unapprove_device');
  }

  approveDevice(new_approve_device: any): Observable<any> {
    const item = { approve_device: new_approve_device };
    return this.http.post<any>(this.testurl + '/qse/branch/set_approve_device', JSON.stringify(item), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  remove_device(device_id: any): Observable<any> {
    return this.http.post<any>(this.testurl + '/qse/branch/remove_device/'+ device_id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
