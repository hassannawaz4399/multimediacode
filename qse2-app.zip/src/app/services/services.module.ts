import { NgModule } from '@angular/core';

// content-manager
import { ContentManagerService } from './content/content-manager.service';

// playlist-template
import { PlaylistTemplateService } from './playlist/playlist-template.service';

// playlist
import { PlaylistService } from './playlist/playlist.service';

// channel
import { ChannelService } from './channel/channel.service';

// schedule
import { ScheduleService } from './schedule/schedule.service';
import { BranchService } from './monitoring/branch.service';

import { PhxSocketService } from './socket/phx-socket.service';

@NgModule({
  providers:[
    //content-manager Service
    ContentManagerService,

    // playlist-template Service
    PlaylistTemplateService,

    // playlist Service
    PlaylistService,

    // channel service
    ChannelService,

    // schedule service
    ScheduleService,

    // monitoring branch service
    BranchService,

    PhxSocketService
  ]
})
export class ServicesModule { }
