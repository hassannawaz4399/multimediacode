import { TestBed } from '@angular/core/testing';

import { PhxSocketService } from './phx-socket.service';

describe('PhxSocketService', () => {
  let service: PhxSocketService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PhxSocketService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
