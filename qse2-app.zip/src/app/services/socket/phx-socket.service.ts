import { Injectable, Output, EventEmitter } from "@angular/core";
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';

declare const Phoenix: any;

@Injectable({
  providedIn: "root",
})
export class PhxSocketService {
  socket: any;
  channel: any;
  url = "ws://" + window.location.hostname + ":4005";

  @Output() volume: EventEmitter<any> = new EventEmitter();
  @Output() panel: EventEmitter<any> = new EventEmitter();
  @Output() online: EventEmitter<any> = new EventEmitter();
  @Output() remote: EventEmitter<any> = new EventEmitter();
  @Output() totalDevice: EventEmitter<any> = new EventEmitter();
  @Output() scheduleNow: EventEmitter<any> = new EventEmitter();

  constructor(private deviceListService: DeviceListService) {
    this.socket = new Phoenix.Socket(this.url + "/socket", {
      logger: (kind, msg, data) => {
        console.log(`${kind}: ${msg}`, data);
      },
      transport: WebSocket,
    });

    this.socket.connect({ params: { user_id: "admin" } });
    this.channel = this.socket.channel("admin:lobby", {});

    this.channel
      .join()
      .receive("ok", (resp) => {
        console.log("Joined successfully", resp);
        // get total device
        this.send({
          cmd:"device",
          type:"total_device"
        });
      })
      .receive("error", (resp) => {
        console.log("Unable to join", resp);
      });

    this.channel.on("device_resp", (payload) => {
      console.log(payload);
      this.received(payload.body);
    });
  }

  received(msg: any) {
    switch (msg.cmd) {
      case "device":
        switch (msg.type) {
          case "volume":
            this.volume.emit(msg);
            break;
          case "panel":
            this.panel.emit(msg);
            break;
          case "online":
            this.online.emit(msg);
            this.deviceListService.modifyDeviceStatus(msg)
            break;
          case "schedule_now":
            this.scheduleNow.emit(msg);
            break;
          case 'remote':
              this.remote.emit(msg)
            break;
          case 'total_device':
              this.totalDevice.emit(msg)
            break
        }
        break;
      default:
        console.log(msg.cmd);
        break;
    }
  }

  send(msg) {
    this.channel.push("admin", { body: msg });
  }
}
