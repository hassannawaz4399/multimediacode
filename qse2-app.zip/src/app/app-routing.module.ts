import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { ChannelComponent } from './channel/channel.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { ReportComponent } from './report/report.component';
import { UnapprovedComponent } from './unapproved/unapproved.component';
import { SignageDeviceComponent } from './playlist/signage-device/signage-device.component';

const routes: Routes = [
  { path: '', redirectTo: 'screens', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'monitoring', component: MonitoringComponent },
  { path: 'channel', component: ChannelComponent },
  { path: 'screens', component: PlaylistComponent },
  { path: 'device', component: SignageDeviceComponent },
  { path: 'playlist/edit/:playlist_name/:template_name', component: PlaylistComponent },
  { path: 'report', component: ReportComponent },
  { path: 'unapproved', component: UnapprovedComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
