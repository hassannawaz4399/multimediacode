import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../layout/layout.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

  constructor(
    private layoutService:LayoutService,
  ) { }

  ngOnInit(): void {
    this.layoutService.toggleLeft(true);
  }

}
