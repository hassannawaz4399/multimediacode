import { PhxSocketService } from './../services/socket/phx-socket.service';
import { Component, OnInit, ViewChild, HostListener, OnDestroy } from '@angular/core';
import { LayoutService } from './layout.service';
import { Subscription } from 'rxjs';
import { ContentManagerService } from '../services/content/content-manager.service';
import { UnapprovedListService } from '../unapproved/unapproved-list/unapproved-list.service';
import { BranchService } from '../services/monitoring/branch.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit, OnDestroy {

  links = [
    { path: 'dashboard', name: 'DASHBOARD' },
    { path: 'screens', name: 'SCREESNS' },
    { path: 'monitoring', name: 'MONITORING' },
    { path: 'channel', name: 'CHANNEL' },
    { path: 'playlist', name: 'PLAYLIST' },

  ];

  SideNavMode: string;
  LeftNavWidth: string;
  rightNavWidth: string;
  showIconSideNav: boolean;

  subscription: Subscription[] = []

  totalUnapproved: number = 0
  totalDevice: number = 0

  @ViewChild("sidenavleft") sidenavleft;

  @HostListener("window:resize", ["$event"]) onResizeEvent(event) {
    this.onloadWindowSetup(event.target.innerWidth);
  }

  constructor(
    private branchService: BranchService,
    private layoutService: LayoutService,
    private contentManagerService: ContentManagerService,
    private websocket: PhxSocketService,
    private unapprovedListService: UnapprovedListService,
  ) {
    this.subscription.push(this.layoutService.leftToggle.subscribe(data => {
      this.sidenavleft.toggle(data);
    }))

    this.subscription.push(unapprovedListService.totalUnapproved.subscribe(TotalUnapproved => {
      this.totalUnapproved = TotalUnapproved
    }))

    this.subscription.push(websocket.totalDevice.subscribe(TotalDevice => {
      this.totalDevice = TotalDevice.total
    }))
  }

  ngOnInit(): void {
    this.LeftNavWidth = "17vw";
    this.showIconSideNav = false;

    this.onloadWindowSetup(window.innerWidth);

    this.subscription.push(this.contentManagerService.getCmsInfo().subscribe(data => {
      console.log('received this.contentManagerService.getCmsInfo() : ', data);
      this.contentManagerService.setCmsUrl(data.data);
      console.log("this.contentManagerService.getCmsUrl() : " + this.contentManagerService.getCmsUrl());
    }))

    this.subscription.push(this.branchService.getUnapproveDevice().subscribe(UnapprovedDevice => {
      console.log("getUnapproveDevice()", UnapprovedDevice)
      if (UnapprovedDevice.data.result === 'success') {
        const dataList = UnapprovedDevice.data.data
        this.totalUnapproved = dataList.length
      }
      else {
        console.log("ERROR: getUnapproveDevice()")
      }
    }))
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.

    console.log("unsubscribe all subscription at layout")
    for (const item of this.subscription) {
      item.unsubscribe()
    }
  }

  public onloadWindowSetup(width): void {

    if (width <= 900) {
      this.SideNavMode = "over";
      this.rightNavWidth = "calc(100vw - 57px)"; // TODO: If width is small the right Nav should be 100%

      if (!this.showIconSideNav) {
        this.toggleLeftNav();
      }

      this.layoutService.setSideNavMode(this.SideNavMode);
      this.layoutService.setrightsidenav(this.rightNavWidth);
    }
    else {
      this.SideNavMode = "side";
      this.rightNavWidth = "20vw";

      this.layoutService.setSideNavMode(this.SideNavMode);
      this.layoutService.setrightsidenav(this.rightNavWidth);
    }
    this.layoutService.loginPageSidenav(width);
  }

  toggleLeftNav() {
    //this.sidenavleft.toggle();

    if (this.SideNavMode === "over" && this.LeftNavWidth === "57px") {
      this.LeftNavWidth = "57px"; //Note: Change to return
    }
    else {
      this.showIconSideNav = !this.showIconSideNav;

      if (this.showIconSideNav) {
        this.LeftNavWidth = "57px";
      }
      else {
        this.LeftNavWidth = "17vw";
      }
    }
  }
}
