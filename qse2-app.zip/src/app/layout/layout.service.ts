import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LayoutService {

  sidenavMode: string;

    @Output() sideNavMode: EventEmitter<any> = new EventEmitter();
    @Output() leftToggle: EventEmitter<any> = new EventEmitter();
    @Output() windowWidth: EventEmitter<any> =new EventEmitter();
    @Output() rightToggle: EventEmitter<any> = new EventEmitter();
    @Output() rightWidth: EventEmitter<any> = new EventEmitter();

  constructor() { }

  toggleLeft(data) {
    // console.log('Toggle Left');
    this.leftToggle.emit(data);
  }

  setSideNavMode(sm: string) {
      // console.log('Left Nav Type : ' + sm);
      this.sideNavMode.emit(sm)
      this.sidenavMode = sm;
  }

  getSidenavMode(): string {
      return this.sidenavMode;
  }

  loginPageSidenav(width){
    this.windowWidth.emit(width);
  }

  toggleRight(){
     console.log('Toggle working right');
    this.rightToggle.emit('right');
}

setrightsidenav(width){
    this.rightWidth.emit(width);
}
}
