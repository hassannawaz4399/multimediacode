import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { MaterialsModule } from './materials/materials.module';
import { ServicesModule } from './services/services.module';
import { ModalsModule } from './modals/modals.module';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutComponent } from './layout/layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { ReportComponent } from './report/report.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { DeviceListComponent } from './monitoring/device-list/device-list.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { ScheduleDetailsComponent } from './schedule/schedule-details/schedule-details.component';
import { ScheduleContentPlaylistComponent } from './schedule/schedule-content/schedule-content-playlist/schedule-content-playlist.component';
import { ScheduleContentVideoComponent } from './schedule/schedule-content/schedule-content-video/schedule-content-video.component';
import { ScheduleContentImageComponent } from './schedule/schedule-content/schedule-content-image/schedule-content-image.component';
import { ScheduleContentAppComponent } from './schedule/schedule-content/schedule-content-app/schedule-content-app.component';
import { AddScheduleComponent } from './schedule/add-schedule/add-schedule.component';
import { ScheduleContentChannelNameComponent } from './schedule/schedule-content/schedule-content-channel-name/schedule-content-channel-name.component';
import { ChannelComponent } from './channel/channel.component';
import { ChannelListComponent } from './channel/channel-list/channel-list.component';
import { PlaylistListComponent } from './playlist/playlist-list/playlist-list.component';
import { PlaylistContentVideoComponent } from './playlist/playlist-content/playlist-content-video/playlist-content-video.component';
import { PlaylistContentImageComponent } from './playlist/playlist-content/playlist-content-image/playlist-content-image.component';
import { PlaylistContentAudioComponent } from './playlist/playlist-content/playlist-content-audio/playlist-content-audio.component';
import { PlaylistContentDocumentComponent } from './playlist/playlist-content/playlist-content-document/playlist-content-document.component';
import { PlaylistContentPlaylistComponent } from './playlist/playlist-content/playlist-content-playlist/playlist-content-playlist.component';
import { PlaylistContentAppComponent } from './playlist/playlist-content/playlist-content-app/playlist-content-app.component';
import { VideoFilterListPipe } from './playlist/playlist-content/playlist-content-video/video-filter-list.pipe';
import { PlaylistOptionComponent } from './playlist/playlist-option/playlist-option.component';
import { PlaylistPreviewComponent } from './playlist/playlist-preview/playlist-preview.component';
import { PlaylistInfoComponent } from './playlist/playlist-info/playlist-info.component';
import { PlaylistScheduleComponent } from './playlist/playlist-schedule/playlist-schedule.component';
import { PlaylistActivityComponent } from './playlist/playlist-activity/playlist-activity.component';
import { UnapprovedComponent } from './unapproved/unapproved.component';
import { UnapprovedListComponent } from './unapproved/unapproved-list/unapproved-list.component';
import { UnapprovedDeviceSettingComponent } from './unapproved/unapproved-device-setting/unapproved-device-setting.component';
import { PlaylistFilterListPipe } from './playlist/playlist-content/playlist-content-playlist/playlist-filter-list.pipe';
import { EditScheduleComponent } from './schedule/edit-schedule/edit-schedule.component';
import { DeviceSettingPlaylistScheduleComponent } from './monitoring/device-setting/device-setting-playlist-schedule/device-setting-playlist-schedule.component';
import { DeviceSettingConfigurationComponent } from './monitoring/device-setting/device-setting-configuration/device-setting-configuration.component';
import { DeviceSettingLogCommandComponent } from './monitoring/device-setting/device-setting-log-command/device-setting-log-command.component';
import { DeviceSettingInstantMessageComponent } from './monitoring/device-setting/device-setting-instant-message/device-setting-instant-message.component';
import { DeviceSettingControlComponent } from './monitoring/device-setting/device-setting-control/device-setting-control.component';
import { ControlPlayerViewComponent } from './monitoring/device-setting/device-setting-control/control-player-view/control-player-view.component';
import { ControlPowerControlComponent } from './monitoring/device-setting/device-setting-control/control-power-control/control-power-control.component';
import { ControlPowerScheduleComponent } from './monitoring/device-setting/device-setting-control/control-power-schedule/control-power-schedule.component';
import { ControlSoundComponent } from './monitoring/device-setting/device-setting-control/control-sound/control-sound.component';
import { ControlPictureComponent } from './monitoring/device-setting/device-setting-control/control-picture/control-picture.component';
import { ControlVideoWallComponent } from './monitoring/device-setting/device-setting-control/control-video-wall/control-video-wall.component';
import { ControlStorageComponent } from './monitoring/device-setting/device-setting-control/control-storage/control-storage.component';
import { InstantMessageScrollTextComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-scroll-text/instant-message-scroll-text.component';
import { InstantMessageAnnouncementComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-announcement/instant-message-announcement.component';
import { InstantMessageMultimediaMessageComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-multimedia-message/instant-message-multimedia-message.component';
import { InstantMessageEmergencyComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-emergency/instant-message-emergency.component';
import { LogCommandPowerLogComponent } from './monitoring/device-setting/device-setting-log-command/log-command-power-log/log-command-power-log.component';
import { LogCommandDeviceLogComponent } from './monitoring/device-setting/device-setting-log-command/log-command-device-log/log-command-device-log.component';
import { LogCommandCommandComponent } from './monitoring/device-setting/device-setting-log-command/log-command-command/log-command-command.component';
import { ConfigurationInformationComponent } from './monitoring/device-setting/device-setting-configuration/configuration-information/configuration-information.component';
import { ConfigurationWiredNetworkComponent } from './monitoring/device-setting/device-setting-configuration/configuration-wired-network/configuration-wired-network.component';
import { ConfigurationWifiNetworkComponent } from './monitoring/device-setting/device-setting-configuration/configuration-wifi-network/configuration-wifi-network.component';
import { ConfigurationSoftApComponent } from './monitoring/device-setting/device-setting-configuration/configuration-soft-ap/configuration-soft-ap.component';
import { ConfigurationFirmwareComponent } from './monitoring/device-setting/device-setting-configuration/configuration-firmware/configuration-firmware.component';
import { ConfigurationLauncerComponent } from './monitoring/device-setting/device-setting-configuration/configuration-launcer/configuration-launcer.component';
import { PlaylistAddEditComponent } from './playlist/playlist-add-edit/playlist-add-edit.component';
import { PlaylistConfigurationAddComponent } from './playlist/playlist-configuration-add/playlist-configuration-add.component';
import { PlaylistConfigurationEditComponent } from './playlist/playlist-configuration-edit/playlist-configuration-edit.component';
import { ChannelInfoComponent } from './channel/channel-info/channel-info.component';
import { ChannelLiveComponent } from './channel/channel-live/channel-live.component';
import { ChannelActivityComponent } from './channel/channel-activity/channel-activity.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ControlApplicationComponent } from './monitoring/device-setting/device-setting-control/control-application/control-application.component';
import { ControlRemoveDeviceComponent } from './monitoring/device-setting/device-setting-control/control-remove-device/control-remove-device.component';
import { SignageDeviceComponent } from './playlist/signage-device/signage-device.component';
import { CustomDropzonePreviewComponent } from './playlist/playlist-list/custom-dropzone-preview/custom-dropzone-preview.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
// import { ExportToCsv } from 'export-to-csv';
@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    DashboardComponent,
    PlaylistComponent,
    ReportComponent,
    MonitoringComponent,
    DeviceListComponent,
    ScheduleComponent,
    ScheduleDetailsComponent,
    ScheduleContentPlaylistComponent,
    ScheduleContentVideoComponent,
    ScheduleContentImageComponent,
    ScheduleContentAppComponent,
    AddScheduleComponent,
    ScheduleContentChannelNameComponent,
    ChannelComponent,
    ChannelListComponent,
    PlaylistListComponent,
    PlaylistContentVideoComponent,
    PlaylistContentImageComponent,
    PlaylistContentAudioComponent,
    PlaylistContentDocumentComponent,
    PlaylistContentPlaylistComponent,
    PlaylistContentAppComponent,
    VideoFilterListPipe,
    PlaylistOptionComponent,
    PlaylistPreviewComponent,
    PlaylistInfoComponent,
    PlaylistScheduleComponent,
    PlaylistActivityComponent,
    UnapprovedComponent,
    UnapprovedListComponent,
    UnapprovedDeviceSettingComponent,
    PlaylistFilterListPipe,
    EditScheduleComponent,
    DeviceSettingPlaylistScheduleComponent,
    DeviceSettingConfigurationComponent,
    DeviceSettingLogCommandComponent,
    DeviceSettingInstantMessageComponent,
    DeviceSettingControlComponent,
    ControlPlayerViewComponent,
    ControlPowerControlComponent,
    ControlPowerScheduleComponent,
    ControlSoundComponent,
    ControlPictureComponent,
    ControlVideoWallComponent,
    ControlStorageComponent,
    InstantMessageScrollTextComponent,
    InstantMessageAnnouncementComponent,
    InstantMessageMultimediaMessageComponent,
    InstantMessageEmergencyComponent,
    LogCommandPowerLogComponent,
    LogCommandDeviceLogComponent,
    LogCommandCommandComponent,
    ConfigurationInformationComponent,
    ConfigurationWiredNetworkComponent,
    ConfigurationWifiNetworkComponent,
    ConfigurationSoftApComponent,
    ConfigurationFirmwareComponent,
    ConfigurationLauncerComponent,
    PlaylistAddEditComponent,
    PlaylistConfigurationAddComponent,
    PlaylistConfigurationEditComponent,
    ChannelInfoComponent,
    ChannelLiveComponent,
    ChannelActivityComponent,
    ControlApplicationComponent,
    ControlRemoveDeviceComponent,
    SignageDeviceComponent,
    CustomDropzonePreviewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialsModule,
    ServicesModule,
    ModalsModule,
    BrowserAnimationsModule,
    NgbModule,
    NgxDropzoneModule,
    // ExportToCsv
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
