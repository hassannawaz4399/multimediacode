import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EditScheduleService {

  LockStatus: boolean = true

  @Output() lockStatus: EventEmitter<any> = new EventEmitter();
  
  constructor() { }

  setLockStatus(lock){
    this.lockStatus.emit(lock);
    this.LockStatus = lock
  }

  getLockStatus(){
    return this.LockStatus
  }
}
