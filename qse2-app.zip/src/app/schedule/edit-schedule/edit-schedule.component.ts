import { Component, OnInit, OnDestroy } from '@angular/core';
import { ScheduleDetailsService } from '../schedule-details/schedule-details.service';
import { formatDate } from '@angular/common';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';
import { MatDialog } from '@angular/material/dialog';
import { ModalsScheduleIntervalEstimateTimeComponent } from 'src/app/modals/schedule/modals-schedule-interval-estimate-time/modals-schedule-interval-estimate-time.component';
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { ChannelListService } from 'src/app/channel/channel-list/channel-list.service';
import { Subscription } from 'rxjs';
import { ScheduleService } from 'src/app/services/schedule/schedule.service';
import { ModalsScheduleDeleteComponent } from 'src/app/modals/schedule/modals-schedule-delete/modals-schedule-delete.component';
import { MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBar } from '@angular/material/snack-bar';
import { EditScheduleService } from './edit-schedule.service';

export interface Time {
  hour: number;
  minute: number;
  second: number;
}

@Component({
  selector: 'app-edit-schedule',
  templateUrl: './edit-schedule.component.html',
  styleUrls: ['./edit-schedule.component.css']
})
export class EditScheduleComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  // cmsUrl='http://localhost:8081/'
  // cmsUrl='http://id.qubit.asia:8081/'
  cmsUrl = ''

  pickColor = [
    { name: 'aqua', value: 'aqua' },
    { name: 'blue', value: 'blue' },
    { name: 'purple', value: 'purple' },
    { name: 'brown', value: 'brown' },
    { name: 'red', value: 'red' },
    { name: 'pink', value: 'hotpink' },
    { name: 'green', value: 'green' },
    { name: 'gold', value: 'gold' },
    { name: 'lime', value: 'lime' },
    // { name: 'yellow', value: 'yellow' }
  ]

  pickPriority = [
    {name:"None", value:"none", Color: "black"},
    {name:"Low", value:"low", Color: "yellow"},
    {name:"Medium", value:"medium", Color: "orange"},
    {name:"High", value:"high", Color: "red"}
  ]

  recurrDayList = [
    { value: "SUN", day: "SUN" },
    { value: "MON", day: "MON" },
    { value: "TUE", day: "TUE" },
    { value: "WED", day: "WED" },
    { value: "THU", day: "THU" },
    { value: "FRI", day: "FRI" },
    { value: 'SAT', day: "SAT" }
  ]
  lock = true
  
  horizontalPosition: MatSnackBarHorizontalPosition = "right"
  verticalPosition: MatSnackBarVerticalPosition = "top"

  schedule_id = ''
  backgroundColor = "aqua"
  argument
  name = ''
  startDate = ''
  endDate = ''
  noEndDate = false
  startTime = ''
  endTime = ''
  wholeDay = false
  repeatDay:string[] = []
  allDay = false
  repeatStatus = false
  intervalStatus = false
  time_interval = 5
  repeat_time: Time = { hour: 0, minute: 1, second: 0 }

  startTimePicker: Time = null
  endTimePicker: Time = null

  errorstatus:boolean = false;
  error:string = '';
  
  intervalInfo = []

  selectedcontent = null
  priority = "none"
  selectedduration = { hour: 0, minute: 0, second: 10 }

  minDate: Date;
  maxDate: Date;

  estimateSchedule:any = {
    schedulelist:[],
    daily_duration: {day: 0, hour: 0, minute: 0, second: 0},
    schedule_duration: {day: 0, hour: 0, minute: 0, second: 0}
  }
  repeatlist:any = {}

  constructor(
    private scheduleService: ScheduleService,
    private deviceListService:DeviceListService,
    private channelListService:ChannelListService,
    private contentManagerService:ContentManagerService,
    private scheduleDetailsService:ScheduleDetailsService,
    private editScheduleService:EditScheduleService,

    private snackBar:MatSnackBar,

    public dialog: MatDialog,
  ) {
    this.subscription.push( scheduleDetailsService.selectedContent.subscribe(content => {
      this.selectedcontent = content

      if(this.selectedcontent.type != 'playlist')
      this.selectedcontent.viewpath = this.cmsUrl + '/' + this.selectedcontent.filename
      
      console.log(this.selectedcontent)

      let tempduration = 10000
      if(this.selectedcontent.duration>0){
        tempduration = this.selectedcontent.duration
      }
      this.selectedduration = this.getTimeCalculation(tempduration)

      if(!this.wholeDay && !this.repeatStatus && ! this.intervalStatus && !this.noEndDate){
        let stampStart = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
        
        let stampEnd = new Date(stampStart).getTime() + tempduration

        this.endDate = formatDate(stampEnd, 'yyyy-MM-dd', 'en-US')
        this.endTimePicker = this.getTimeFromString(formatDate(stampEnd, 'HH:mm:ss', 'en-US'))

        this.dateTimeChange()
      }
    }))

    this.subscription.push( scheduleDetailsService.scheduleEdit.subscribe(Edit => {
      if(this.lock)
      this.getScheduleEditDetails()
    }))
   }

  ngOnInit(): void {
    this.cmsUrl = this.contentManagerService.getCmsUrl()
    
    this.reset()

    this.getScheduleEditDetails()
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at edit-schedule")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  getScheduleEditDetails(){

    this.schedule_id = this.scheduleDetailsService.getScheduleEdit()
    console.log("arg", this.schedule_id)

    this.subscription.push(this.scheduleService.getScheduleInfo(this.schedule_id).subscribe(SelectedSchedule =>{
      console.log("getScheduleInfo", SelectedSchedule)
      if(SelectedSchedule.data.result === 'success'){
        this.argument = SelectedSchedule.data.data

        this.name = this.argument.schedule_info.schedule_name
        this.startTime = this.argument.schedule_info.start_time
        this.startDate = this.argument.schedule_info.start_date
        this.endTime = this.argument.schedule_info.end_time
        this.endDate = this.argument.schedule_info.end_date
        this.wholeDay = this.argument.schedule_info.all_day

        this.startTimePicker = this.getTimeFromString(this.startTime)
        this.endTimePicker = this.getTimeFromString(this.endTime)

        this.selectedcontent = this.argument.schedule_info.content_info
        this.selectedcontent.duration = this.argument.schedule_info.content_duration
        if(this.selectedcontent.type != 'playlist')
          this.selectedcontent.viewpath = this.cmsUrl + '/' + this.selectedcontent.filename
      
        this.noEndDate = this.argument.schedule_info.no_end_date
        this.backgroundColor = this.argument.schedule_info.background_color
        this.priority = this.argument.schedule_info.schedule_priority
        this.intervalStatus = this.argument.schedule_info.interval
        this.intervalInfo = this.argument.schedule_info.interval_info
        this.repeat_time = this.getTimeFromString(this.argument.schedule_info.repeat_time)
        this.time_interval = this.argument.schedule_info.time_interval
        this.selectedduration = this.getTimeFromString(this.argument.schedule_info.selected_duration_content)

        this.repeatStatus = this.argument.schedule_info.recurring
        this.repeatDay = this.argument.schedule_info.recurring_days

        this.estimateSchedule.daily_duration = this.getTimeWithDayCalculation(this.argument.schedule_info.daily_duration)
        this.estimateSchedule.schedule_duration = this.getTimeWithDayCalculation(this.argument.schedule_info.schedule_duration)
        if(this.repeatDay.length == 7){
          this.allDay = true
        }

        if(this.wholeDay && this.repeatStatus){
          this.endTimePicker = {hour:0, minute:0, second:0}
        }
        this.dateTimeChange()
        this.calculateEstimateSchedule(false)
      }
      else{
        console.log("error:getscheduleinfo()")
      }
    }))
  }

  unlockToEdit(){
    if(this.deviceListService.getMonitoringStatus()){
      if(this.argument.schedule_type === 'device'){
        this.lock = !this.lock
      }
      else{
        this.snackBar.open('This is channel schedule',"X",{duration: 1000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition
        })
      }
    }
    else{
      this.lock = !this.lock
    }

    this.editScheduleService.setLockStatus(this.lock)
  }

  getTimeCalculation(timestampDifference) {
    timestampDifference = timestampDifference / 1000
    var hours = ~~(timestampDifference / 3600);
    var minuts = ~~((timestampDifference - hours * 3600) / 60);
    var seconds = timestampDifference - hours * 3600 - minuts * 60;
    // console.log("seconds", this.truncate(seconds))
    return { hour: hours, minute: minuts, second: this.truncate(seconds) };

    // check if the hour is greater then 1 than return time with hour else return minutes.
  }

  getTimeWithDayCalculation(timestampDifference) {
    timestampDifference = timestampDifference / 1000
    var days = ~~(timestampDifference / 86400)
    var hours = ~~((timestampDifference - days * 86400) / 3600);
    var minuts = ~~((timestampDifference - days * 86400 - hours * 3600) / 60);
    var seconds = timestampDifference - days * 86400 - hours * 3600 - minuts * 60;
    // console.log("seconds", this.truncate(seconds))
    return { day: days, hour: hours, minute: minuts, second: this.truncate(seconds) };

    // check if the hour is greater then 1 than return time with hour else return minutes.
  }

  truncate(value) {
    if (value < 0) {
      return Math.ceil(value);
    }

    return Math.floor(value);
  }

  getMillisecond(timeduaration) {
    return ((timeduaration.hour * 60 * 60) + (timeduaration.minute * 60) + (timeduaration.second)) * 1000
  }

  getMillisecondWithDay(timeduaration) {
    return ((timeduaration.day * 60 * 60 * 24) + (timeduaration.hour * 60 * 60) + (timeduaration.minute * 60) + (timeduaration.second)) * 1000
  }

  getTimeFromString(strDate) {
    let arr = strDate.split(':');
    return { hour: parseInt(arr[0]), minute: parseInt(arr[1]), second: parseInt(arr[2]) };
  }

  openDialogViewEstimateTime(action, obj) {
    if (this.dialog.openDialogs.length === 0) {
      // obj.action = action
      const dialogRef = this.dialog.open(ModalsScheduleIntervalEstimateTimeComponent, {
        data: { data: obj, action: action },
        width: '50%',
        height: '80.1%'
      });
    }
  }

  wholeDayChange(event){
    console.log(event)
    if(event.checked){
      this.intervalStatus = !event.checked
      this.startTimePicker = { hour: 0, minute: 0, second: 0 }
      this.endTimePicker = { hour: 0, minute: 0, second: 0 }

      let stampStart = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
      let stampEnd = formatDate(this.endDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })

      let schedule_duration = new Date(stampEnd).getTime() - new Date(stampStart).getTime()

      if(schedule_duration == 0){
        let temp = new Date(this.startDate).getTime() + (1000 * 60 * 60 * 24)
        this.endDate = formatDate(temp, 'yyyy-MM-dd', 'en-US')
      }
    }
  }

  checkNoEndDate(event){
    if (event.checked){
      let today = new Date()
      let temp = today.getFullYear() + 1
      let tempend = today.setFullYear(temp)
      this.endDate = formatDate(tempend, 'yyyy-MM-dd', 'en-US')
    }

    this.dateTimeChange()
  }

  dateTimeChange(){
    console.log(this.intervalStatus)
    if(this.intervalStatus){
      this.CalculateMaxTimeInterval()
    }
  }

  allDayToggle(event){
    if (event.checked){
      this.repeatDay = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
      
    }
  }

  checkingAllDay(event){
    if(event.value.length == 7){
      this.allDay = true
    }
    else{
      this.allDay = false
    }
  }

  cancel(){
    this.scheduleDetailsService.setRightNavClose()
    this.scheduleDetailsService.setEditScheduleStatus(false)
    this.editScheduleService.setLockStatus(true)
  }

  checkingEditScheduleInformation() {
    this.intervalInfo = []

    if (!this.repeatStatus) {
      this.repeatDay = []
    }

    if (this.intervalStatus && !this.wholeDay) {
      this.intervalInfo = this.CalculateMaxTimeInterval()
    }
    else {
      this.repeat_time = { hour: 0, minute: 0, second: 0 }
      this.selectedduration = { hour: 0, minute: 0, second: 0 }
      this.time_interval = 0
    }

    this.dateTimeChange()
    this.calculateEstimateSchedule(false)

    setTimeout(() => {
      this.validate()
    },500);
  }

  validate(){
    // may need change to switch
    if (this.name === '') {
      this.snackBar.open('Please enter schedule title', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please enter schedule title")
    }
    else if (this.selectedcontent == null) {
      this.snackBar.open('Please choose schedule content', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please choose schedule content")
    }
    else if (this.repeatStatus && this.repeatDay.length == 0) {
      this.snackBar.open('Please set the repeat day at repeat setting', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please set the repeat day at repeat setting")
    }
    // else if (this.repeatStatus && this.scheduleDuration.day<7){
    //   console.log("Please set the range date and time atleast schedule duration for 7 days")
    // }
    else if (this.intervalStatus && !this.wholeDay && this.intervalInfo.length == 0) {
      this.snackBar.open('Interval setting not valid', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Interval setting not valid")
    }
    else if (this.intervalStatus && !this.wholeDay && this.getMillisecond(this.repeat_time) == 0) {
      this.snackBar.open('Please set the content duration at interval setting', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please set the content duration at interval setting")
    }
    else if (this.intervalStatus && !this.wholeDay && this.getMillisecond(this.selectedduration) == 0) {
      this.snackBar.open('Please set the interval duration at interval setting', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please set the interval duration at interval setting")
    }
    else if (this.getMillisecondWithDay(this.estimateSchedule.schedule_duration) <= 0) {
      this.snackBar.open('Please choose valid range date and time schedule', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("please choose valid range date and time schedule")
    }
    else if (this.getMillisecondWithDay(this.estimateSchedule.daily_duration) <= 0) {
      this.snackBar.open('Please choose valid range time schedule', "X", {
        duration: 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition
      })
      console.log("Please choose valid range time schedule")
    }
    else {
      this.confirmEditSchedule()
    }
  }

  confirmEditSchedule() {
    if(this.wholeDay && this.repeatStatus){
      this.endTimePicker = {hour:23, minute:59, second:59}
    }
    
    let editschedule = {
      schedule_type: this.argument.schedule_type,
      branch_id:this.argument.branch_id,
      branch_name:this.argument.branch_name,
      device_name: this.argument.device_name,
      device_id: this.argument.device_id,
      channel_id:this.argument.channel_id,
      channel_name: this.argument.channel_name,
      schedule_info: {
        schedule_id:this.schedule_id,
        schedule_name: this.name,
        edit_by:'Qubit',
        all_day: this.wholeDay,
        start_date: formatDate(this.startDate, 'yyyy-MM-dd', 'en-US'),
        start_time: (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
        end_date: formatDate(this.endDate, 'yyyy-MM-dd', 'en-US'),
        end_time: (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
        no_end_date: this.noEndDate,
        recurring: this.repeatStatus,
        recurring_days: this.repeatDay,
        interval: this.intervalStatus,
        repeat_time: (this.repeat_time.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.repeat_time.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.repeat_time.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
        time_interval: this.time_interval,
        selected_duration_content:(this.selectedduration.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.selectedduration.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.selectedduration.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }), // user set content duration for interval content duration
        interval_info: this.intervalInfo,
        daily_duration: this.getMillisecondWithDay(this.estimateSchedule.daily_duration),
        schedule_duration: this.getMillisecondWithDay(this.estimateSchedule.schedule_duration),
        schedule_priority: this.priority,
        background_color: this.backgroundColor,
        content_duration: this.selectedcontent.duration, // default duration from qcm
        content_info:{ type: this.selectedcontent.type, filename: this.selectedcontent.filename, title: this.selectedcontent.title}
      }
    }

    console.log("POST EDIT SCHEDULE => ", JSON.stringify(editschedule))
  
    this.subscription.push( this.scheduleService.updateSchedule(editschedule).subscribe(resp => {
      console.log('this.schedule.edit_schedule : ', resp);
      if (resp.data.result === 'success') {
        console.log("complete edit_schedule")
        this.scheduleDetailsService.setEditSchedule({})
        this.scheduleDetailsService.setRightNavClose()
        this.editScheduleService.setLockStatus(true)
      }
      else {
        this.errorstatus = true;
        this.error = resp.data.data
        console.log("error: schedule.edit_schedule");
      }
    }))
  }

  CalculateMaxTimeInterval(){
    let estimateTime = []
    let count = 0

    let schedule_duration = 0
    let intervaldur = this.getMillisecond(this.repeat_time)

    let contentduration = this.getMillisecond(this.selectedduration)
    if(contentduration == 0){
      contentduration = this.selectedcontent.duration

      if(contentduration == 0){
        contentduration = 10000
      }

      this.selectedduration = this.getTimeCalculation(contentduration)
    }
    if(intervaldur == 0){
      intervaldur = 60000
      this.repeat_time = this.getTimeCalculation(intervaldur)
    }

    if (this.startDate === this.endDate || this.repeatStatus) {
      let starttimeschedule = this.getMillisecond(this.startTimePicker)
      let endtimeschedule = this.getMillisecond(this.startTimePicker) + contentduration

      schedule_duration = this.getMillisecond(this.endTimePicker) - this.getMillisecond(this.startTimePicker)
      console.log(schedule_duration)

      if (schedule_duration < contentduration) {
        endtimeschedule = this.getMillisecond(this.endTimePicker)
      }

      // && count < this.time_interval
      while (schedule_duration > 0) {
        
        const tempstrtime = this.getTimeCalculation(starttimeschedule)
        const tempendtime = this.getTimeCalculation(endtimeschedule)
        estimateTime.push({
          start_date: formatDate(this.startDate, 'yyyy-MM-dd', 'en-US'),
          start_time: (tempstrtime.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (tempstrtime.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (tempstrtime.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
          end_date: formatDate(this.endDate, 'yyyy-MM-dd', 'en-US'),
          end_time: (tempendtime.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (tempendtime.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (tempendtime.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
        })

        count++

        schedule_duration = schedule_duration - (contentduration + intervaldur)
        starttimeschedule = endtimeschedule + intervaldur
        endtimeschedule = starttimeschedule + contentduration

        if (schedule_duration < contentduration) {
          endtimeschedule = this.getMillisecond(this.endTimePicker)
        }

      }
    }
    else if (!this.repeatStatus && this.startDate !== this.endDate) {

      let calcdailyway = -1
      let aDay = 1000 * 60 * 60 * 24
      let checkingduration = 0

      let stampStart = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
      let stampEnd = formatDate(this.endDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })

      let starttimeschedule = new Date(stampStart).getTime()
      let endtimeschedule = new Date(stampStart).getTime() + contentduration

      let schedule_duration = new Date(stampEnd).getTime() - new Date(stampStart).getTime()
      console.log(schedule_duration)

      if (schedule_duration < aDay) {
        calcdailyway = 0
      }
      else {
        calcdailyway = 1
        checkingduration = schedule_duration
      }
      if (schedule_duration < contentduration) {
        endtimeschedule = this.getMillisecond(this.endTimePicker)
      }

      // && count < this.time_interval
      while (schedule_duration > 0) {
        
        estimateTime.push({
          start_date: formatDate(starttimeschedule, 'yyyy-MM-dd', 'en-US'),
          start_time: formatDate(starttimeschedule, 'HH:mm:ss', 'en-US'),
          end_date: formatDate(endtimeschedule, 'yyyy-MM-dd', 'en-US'),
          end_time: formatDate(endtimeschedule, 'HH:mm:ss', 'en-US'),
        })

        count++

        schedule_duration = schedule_duration - (contentduration + intervaldur)
        starttimeschedule = endtimeschedule + intervaldur
        endtimeschedule = starttimeschedule + contentduration
        if (schedule_duration < contentduration) {
          endtimeschedule = this.getMillisecond(this.endTimePicker)
        }
      }
    }

    this.time_interval = estimateTime.length
    return estimateTime
  }

  calculateEstimateSchedule(modal){
    this.estimateSchedule = {
      schedulelist:[],
      daily_duration: {day: 0, hour: 0, minute: 0, second: 0},
      schedule_duration: {day: 0, hour: 0, minute: 0, second: 0}
    }
    this.repeatlist = {}

    // no repeat && no interval
    if(!this.repeatStatus && !this.intervalStatus){
      this.estimateSchedule.schedulelist.push({
        start_date: formatDate(this.startDate, 'yyyy-MM-dd', 'en-US'),
        start_time: (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
        end_date: formatDate(this.endDate, 'yyyy-MM-dd', 'en-US'),
        end_time: (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
      })

      let stampStart = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
      let stampEnd = formatDate(this.endDate, 'yyyy-MM-dd', 'en-US') + ' ' + (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })

      let schedule_duration = new Date(stampEnd).getTime() - new Date(stampStart).getTime()

      let daily_duration = 0
      if(formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') === formatDate(this.endDate, 'yyyy-MM-dd', 'en-US')){
        daily_duration = schedule_duration
      }
      else{
        let start = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' 00:00:00'
        let end = formatDate(this.endDate, 'yyyy-MM-dd', 'en-US') + ' 00:00:00'

        if((new Date(end).getTime() - new Date(start).getTime()) == 86400000){
          let firstDayDuration = new Date(end).getTime() - new Date(stampStart).getTime()
          let secondDayDuration = new Date(stampEnd).getTime() - new Date(end).getTime()
          
          if(firstDayDuration > secondDayDuration){
            daily_duration = firstDayDuration
          }
          else{
            daily_duration = secondDayDuration
          }
        }else{
           daily_duration = 86400000
        }
      }

      this.estimateSchedule.schedule_duration = this.getTimeWithDayCalculation(schedule_duration)
      this.estimateSchedule.daily_duration = this.getTimeWithDayCalculation(daily_duration)
      console.log("EstimateSchedule", JSON.stringify(this.estimateSchedule))
      if(modal){
        this.openDialogViewEstimateTime('ViewEstimateTime', JSON.stringify(this.estimateSchedule))
      }
    }
    else if(this.repeatStatus){
      
      let sendThis = {
        start_date: formatDate(this.startDate, 'yyyy-MM-dd', 'en-US'),
        end_date: formatDate(this.endDate, 'yyyy-MM-dd', 'en-US'),
        recurring: this.repeatDay,
      }
      this.subscription.push( this.scheduleService.checkRecurring(sendThis).subscribe(resp => {
        console.log("this.scheduleService.checkRecurring()", resp)
        if(resp.data.result === 'success'){
          this.repeatlist = resp.data.data

          let schedule_duration = 0
          let daily_duration = 0

          for(const item of this.repeatlist.recurring){
            for(const list of item){
              if (!this.intervalStatus && !this.wholeDay) {

                this.estimateSchedule.schedulelist.push({
                  start_date: list.date,
                  start_time: (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
                  end_date: list.date,
                  end_time: (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
                })
                let stampStart = list.date + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
                let stampEnd = list.date + ' ' + (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })

                schedule_duration += (new Date(stampEnd).getTime() - new Date(stampStart).getTime())


              }
              else if (!this.intervalStatus && this.wholeDay) {
                let nextday = new Date(list.date + " 00:00:00").getTime() + 86400000
                console.log("nextday: ", formatDate(nextday, 'yyyy-MM-dd', 'en-US'))
                this.estimateSchedule.schedulelist.push({
                  start_date: list.date,
                  start_time: (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
                  end_date: formatDate(nextday, 'yyyy-MM-dd', 'en-US'),
                  end_time: (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }),
                })
                let stampStart = list.date + ' ' + (this.startTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.startTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })
                let stampEnd = formatDate(nextday, 'yyyy-MM-dd', 'en-US') + ' ' + (this.endTimePicker.hour).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.minute).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false }) + ':' + (this.endTimePicker.second).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false })

                schedule_duration += (new Date(stampEnd).getTime() - new Date(stampStart).getTime())
              }
              else {
                let estimatetime = this.CalculateMaxTimeInterval()
                for (const time of estimatetime) {
                  this.estimateSchedule.schedulelist.push({
                    start_date: list.date,
                    start_time: time.start_time,
                    end_date: list.date,
                    end_time: time.end_time,
                  })
                  let stampStart = list.date + ' ' + time.start_time
                  let stampEnd = list.date + ' ' + time.end_time

                  schedule_duration += (new Date(stampEnd).getTime() - new Date(stampStart).getTime())
                }
              }
            }
          }
          if(this.estimateSchedule.schedulelist.length != 0){
            let tempdate = this.estimateSchedule.schedulelist[0].start_date
            let calculate = true
            let calcCount = 0
            
            while (calculate && calcCount != this.estimateSchedule.schedulelist.length){
              if(tempdate === this.estimateSchedule.schedulelist[calcCount].start_date){
                let start = this.estimateSchedule.schedulelist[calcCount].start_date + ' ' + this.estimateSchedule.schedulelist[calcCount].start_time
                
                if(tempdate === this.estimateSchedule.schedulelist[calcCount].end_date){
                  let end = this.estimateSchedule.schedulelist[calcCount].end_date + ' ' + this.estimateSchedule.schedulelist[calcCount].end_time
                  
                  daily_duration += (new Date(end).getTime() - new Date(start).getTime())

                }else{
                  daily_duration += ((new Date(start).getTime() + 86400000) - new Date(start).getTime())
                }
                calcCount ++
              }
              else{
                calculate = false
              }
            }
          }
          this.estimateSchedule.schedule_duration = this.getTimeWithDayCalculation(schedule_duration)
          this.estimateSchedule.daily_duration = this.getTimeWithDayCalculation(daily_duration)

          console.log("EstimateSchedule", JSON.stringify(this.estimateSchedule))
          if(modal){
            this.openDialogViewEstimateTime('ViewEstimateTime', JSON.stringify(this.estimateSchedule))
          }
        }
        else{
          console.log("error : this.scheduleService.checkRecurring()")
        }
      }))
    }
    else if(this.intervalStatus){
      this.estimateSchedule.schedulelist = this.CalculateMaxTimeInterval()
      let schedule_duration = 0
      let daily_duration = 0
      
      for(const time of this.estimateSchedule.schedulelist){
        let stampStart = time.start_date + ' ' + time.start_time
        let stampEnd = time.end_date + ' ' + time.end_time

        schedule_duration += (new Date(stampEnd).getTime() - new Date(stampStart).getTime())
      }

      if(formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') === formatDate(this.endDate, 'yyyy-MM-dd', 'en-US')){
        daily_duration = schedule_duration
      }
      else{
        let start = formatDate(this.startDate, 'yyyy-MM-dd', 'en-US') + ' 00:00:00'
        let end = formatDate(this.endDate, 'yyyy-MM-dd', 'en-US') + ' 00:00:00'

        console.log(this.estimateSchedule.schedulelist)
        if(this.estimateSchedule.schedulelist.length != 0){
          if((new Date(end).getTime() - new Date(start).getTime()) == 86400000){
          
            let firstDayDuration = 0
            let secondDayDuration = 0
  
            let tempdate = this.estimateSchedule.schedulelist[0].start_date
            let nexttempdate
            let calculateFirst = true
            let calculateSecond = true
            let calcCount = 0
            
            while (calculateFirst && calcCount != this.estimateSchedule.schedulelist.length){
              if(tempdate === this.estimateSchedule.schedulelist[calcCount].start_date){
                let startTemp = this.estimateSchedule.schedulelist[calcCount].start_date + ' ' + this.estimateSchedule.schedulelist[calcCount].start_time
                
                if(tempdate === this.estimateSchedule.schedulelist[calcCount].end_date){
                  let endTemp = this.estimateSchedule.schedulelist[calcCount].end_date + ' ' + this.estimateSchedule.schedulelist[calcCount].end_time
                  
                  firstDayDuration += (new Date(endTemp).getTime() - new Date(startTemp).getTime())
  
                }else{
                  firstDayDuration += ((new Date(startTemp).getTime() + 86400000) - new Date(startTemp).getTime())
                }
                calcCount ++
              }
              else{
                nexttempdate = this.estimateSchedule.schedulelist[calcCount].start_date
                calculateFirst = false
              }
            }
            
            while (calculateSecond && calcCount != this.estimateSchedule.schedulelist.length){
              if(nexttempdate === this.estimateSchedule.schedulelist[calcCount].start_date){
                let startTemp = this.estimateSchedule.schedulelist[calcCount].start_date + ' ' + this.estimateSchedule.schedulelist[calcCount].start_time
                
                if(nexttempdate === this.estimateSchedule.schedulelist[calcCount].end_date){
                  let endTemp = this.estimateSchedule.schedulelist[calcCount].end_date + ' ' + this.estimateSchedule.schedulelist[calcCount].end_time
                  
                  secondDayDuration += (new Date(endTemp).getTime() - new Date(startTemp).getTime())
  
                }else{
                  secondDayDuration += ((new Date(startTemp).getTime() + 86400000) - new Date(startTemp).getTime())
                }
                calcCount ++
              }
              else{
                calculateSecond = false
              }
            }
  
            if(firstDayDuration > secondDayDuration){
              daily_duration = firstDayDuration
            }
            else{
              daily_duration = secondDayDuration
            }
          }else{
            // get tommorow schedule
            let newStart = new Date(start).getTime() + 86400000
  
            let tempdate = this.estimateSchedule.schedulelist[0].start_date
            let calculate = true
            let calcCount = 0
            
            for(var i=0; i<this.estimateSchedule.schedulelist.length; i++){
              let temp = this.estimateSchedule.schedulelist[calcCount].start_date + ' 00:00:00'
  
              if(new Date(temp).getTime() === newStart){
                tempdate = this.estimateSchedule.schedulelist[i].start_date
                calcCount = i
                break;
              }
            }
  
            while (calculate && calcCount != this.estimateSchedule.schedulelist.length){
              if(tempdate === this.estimateSchedule.schedulelist[calcCount].start_date){
                let start = this.estimateSchedule.schedulelist[calcCount].start_date + ' ' + this.estimateSchedule.schedulelist[calcCount].start_time
                
                if(tempdate === this.estimateSchedule.schedulelist[calcCount].end_date){
                  let end = this.estimateSchedule.schedulelist[calcCount].end_date + ' ' + this.estimateSchedule.schedulelist[calcCount].end_time
                  
                  daily_duration += (new Date(end).getTime() - new Date(start).getTime())
  
                }else{
                  daily_duration += ((new Date(start).getTime() + 86400000) - new Date(start).getTime())
                }
                calcCount ++
              }
              else{
                calculate = false
              }
            }
            
          }
        }
      }

      this.estimateSchedule.schedule_duration = this.getTimeWithDayCalculation(schedule_duration)
      this.estimateSchedule.daily_duration = this.getTimeWithDayCalculation(daily_duration)

      console.log("EstimateSchedule", JSON.stringify(this.estimateSchedule))
      if(modal){
        this.openDialogViewEstimateTime('ViewEstimateTime', JSON.stringify(this.estimateSchedule))
      }
    }
  }
  
  selectContent(){
    this.scheduleDetailsService.setSelectedContentStatus(true)
  }
 
  deleteSchedule(){
    if (this.dialog.openDialogs.length === 0){
      const dialogRef = this.dialog.open(ModalsScheduleDeleteComponent, {
        data: { data: {schedule_id:this.schedule_id, schedule_name:this.argument.schedule_info.schedule_name}, action: "Delete" },
        width: '30%',
        height: 'auto'
      });
    }

    // // this.scheduleDetailsService.setDeleteSchedule()
  }

  reset(){
    const currentYear = new Date().getFullYear();
    this.minDate = new Date();
    this.maxDate = new Date(currentYear + 20, 11, 31);
  }
}
