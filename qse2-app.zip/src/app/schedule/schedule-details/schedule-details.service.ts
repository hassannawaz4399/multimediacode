import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ScheduleDetailsService {

  ArgumentSchedule
  ScheduleEdit

  @Output() channelNameList: EventEmitter<any> = new EventEmitter();
  @Output() argumentSchedule: EventEmitter<any> = new EventEmitter();
  @Output() addSchedule: EventEmitter<any> = new EventEmitter();
  @Output() addScheduleStatus: EventEmitter<any> = new EventEmitter();
  @Output() selectedContentStatus: EventEmitter<any> = new EventEmitter();
  @Output() selectedContent: EventEmitter<any> = new EventEmitter();
  @Output() scheduleEdit: EventEmitter<any> = new EventEmitter();
  @Output() editScheduleStatus: EventEmitter<any> = new EventEmitter();
  @Output() editedSchedule: EventEmitter<any> = new EventEmitter();
  @Output() deleteSchedule: EventEmitter<any> = new EventEmitter();
  @Output() addScheduleNow: EventEmitter<any> = new EventEmitter();
  @Output() totalSchedule: EventEmitter<any> = new EventEmitter();
  @Output() rightnavclose: EventEmitter<any> = new EventEmitter();

  constructor() { }

  setChannelNameList(status) {
    this.channelNameList.emit(status);
  }
  
  setArgumentSchedule(arg){
    this.ArgumentSchedule = arg
    this.argumentSchedule.emit(arg)
  }

  getArgumentSchedule(){
    return this.ArgumentSchedule
  }

  setAddSchedule(data){
    this.addSchedule.emit(data)
  }

  setAddScheduleStatus(status){
    this.addScheduleStatus.emit(status)
  }

  setSelectedContentStatus(status){
    this.selectedContentStatus.emit(status)
  }

  setSelectedContent(data){
    this.selectedContent.emit(data)
  }

  setRightNavClose(){
    this.rightnavclose.emit("close")
  }

  setScheduleEdit(edit){
    this.ScheduleEdit = edit
    this.scheduleEdit.emit(edit)
  }

  getScheduleEdit(){
    return this.ScheduleEdit
  }

  setEditScheduleStatus(status){
    this.editScheduleStatus.emit(status)
  }

  setEditSchedule(schedule){
    this.editedSchedule.emit(schedule)
  }

  setDeleteSchedule(){
    this.deleteSchedule.emit('schedule')
  }

  setAddScheduleNow(){
    this.addScheduleNow.emit('addschedulenow')
  }

  setTotalSchedule(total){
    this.totalSchedule.emit(total)
  }
}
