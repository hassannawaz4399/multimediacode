import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { EventInput } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import listPlugin from '@fullcalendar/list';
import timeGrigPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction'; // for dateClick
import { DeviceListService } from 'src/app/monitoring/device-list/device-list.service';
import { LayoutService } from 'src/app/layout/layout.service';
import { ScheduleDetailsService } from './schedule-details.service';
import { MatMenuTrigger } from '@angular/material/menu';
import { ChannelListService } from 'src/app/channel/channel-list/channel-list.service';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';
import { Subscription } from 'rxjs';
import { ScheduleService } from 'src/app/services/schedule/schedule.service';
import { formatDate } from '@angular/common';
import { EditScheduleService } from '../edit-schedule/edit-schedule.service';

@Component({
  selector: 'app-schedule-details',
  templateUrl: './schedule-details.component.html',
  styleUrls: ['./schedule-details.component.css']
})
export class ScheduleDetailsComponent implements OnInit, OnDestroy {

  subscription: Subscription[] = []

  // cmsUrl='http://localhost:8081/'
  // cmsUrl='http://id.qubit.asia:8081/'

  cmsUrl = ''

  pickText = [
    { text: 'black', background: 'aqua' },
    { text: 'white', background: 'blue' },
    { text: 'white', background: 'purple' },
    { text: 'white', background: 'brown' },
    { text: 'white', background: 'red' },
    { text: 'black', background: 'hotpink' },
    { text: 'white', background: 'green' },
    { text: 'black', background: 'gold' },
    { text: 'black', background: 'lime' },
    // { name: 'yellow', value: 'yellow' }
  ]

  rightSideNavWidth;

  device: any = {};
  channel: any = {};
  monitoring: boolean = false

  selectedIndex: number = -1;

  channelName: boolean = false
  addSchedule: boolean = false
  selectedContentStatus: boolean = false

  editSchedule: boolean = false

  calendarVisible: boolean = true;
  calendarPlugins = [dayGridPlugin, timeGrigPlugin, interactionPlugin, listPlugin];
  calendarWeekends: boolean = true;

  // eventpopovertry = function(event, element) {
  //   $(element).tooltip({title: event.tooltip,
  //             container: 'body',
  //             delay: { "show": 500, "hide": 300 }
  //   });
  // }

  contentheight = 690
  calendarEvents: EventInput[] = [
    // { title: 'Event Now', start: new Date() }
  ];

  @ViewChild('calendar') calendarComponent: FullCalendarComponent; // the #calendar in the template
  @ViewChild('sidenavright') sidenavright;
  @ViewChild(MatMenuTrigger) contextMenu: MatMenuTrigger;
  contextMenuPosition = { x: '0px', y: '0px' };

  constructor(
    private editScheduleService:EditScheduleService,
    private scheduleService:ScheduleService,
    private contentManagerService: ContentManagerService,
    private deviceListService: DeviceListService,
    private channelListService: ChannelListService,
    private layoutService: LayoutService,
    private scheduleDetailsService: ScheduleDetailsService,
  ) {
    this.subscription.push(scheduleDetailsService.selectedContentStatus.subscribe(status => {
      this.selectedContentStatus = status
    }))

    this.subscription.push(scheduleDetailsService.addScheduleStatus.subscribe(status => {
      this.addSchedule = status

      if (this.addSchedule) {
        this.editSchedule = false
        this.channelName = false
      }
    }))

    this.subscription.push(scheduleDetailsService.channelNameList.subscribe(status => {
      this.channelName = status

      if (this.channelName) {
        this.editSchedule = false
        this.addSchedule = false
      }
    }))

    this.subscription.push(scheduleDetailsService.deleteSchedule.subscribe(deleteSchedule => {
      let temp = scheduleDetailsService.getScheduleEdit()
      this.calendarEvents.splice(this.selectedIndex, 1)
      temp.event.remove()
      this.editSchedule = false
    }))

    this.subscription.push(scheduleDetailsService.editedSchedule.subscribe(EditedSchedule => {
      console.log("edit", EditedSchedule)

      this.editSchedule = false

      if (!this.monitoring) {
        this.getChannelSchedule()
      }
      else {
        this.getDeviceSchedule()
      }

      console.log(this.calendarEvents)
    }))

    this.subscription.push(scheduleDetailsService.editScheduleStatus.subscribe(EditStatus => {
      this.editSchedule = EditStatus

      if (this.editSchedule) {
        this.channelName = false
        this.addSchedule = false
      }
    }))

    this.subscription.push(deviceListService.currentDevice.subscribe(Device => {
      this.device = Device
      console.log('device', this.device)
    }))

    this.subscription.push(layoutService.rightToggle.subscribe(data => {
      this.toggleRightNav();
    }))

    this.subscription.push(layoutService.rightWidth.subscribe(data => {
      this.rightSideNavWidth = data;
    }))

    this.subscription.push(scheduleDetailsService.addSchedule.subscribe(schedule => {
      console.log(schedule)

      this.addSchedule = false

      if (!this.monitoring) {
        this.getChannelSchedule()
      }
      else {
        this.getDeviceSchedule()
      }

      console.log(this.calendarEvents)
    }))

    this.subscription.push( scheduleDetailsService.addScheduleNow.subscribe(AddNow => {
      let tempDate = new Date()
      let stringDate = formatDate(tempDate, 'yyyy-MM-dd', 'en-US') + 'T' + formatDate(tempDate, 'HH:mm:ss', 'en-US')
      this.handleDateClick({dateStr:stringDate, allDay:false})
    }))

    this.subscription.push( scheduleDetailsService.rightnavclose.subscribe(CloseRightNav => {
      this.sidenavright.close()
    }))
  }

  ngOnInit(): void {
    this.cmsUrl = this.contentManagerService.getCmsUrl()

    this.device = this.deviceListService.getCurrentDevice()
    this.channel = this.channelListService.getCurrentChannel()

    this.monitoring = this.deviceListService.getMonitoringStatus()

    if (!this.monitoring) {
      this.getChannelSchedule()
    }
    else {
      this.getDeviceSchedule()
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.

    console.log("unsubscribe all subscription at schedule-details")
    for (const item of this.subscription) {
      item.unsubscribe()
    }
  }

  getChannelSchedule(){
    this.subscription.push( this.scheduleService.getScheduleChannel(this.channel.channel_id).subscribe((ScheduleList) => {
      console.log("getScheduleChannel", ScheduleList)

      this.calendarEvents = []

      if (ScheduleList.data.result == 'success'){
        for(const item of ScheduleList.data.data){

          if(item.backgroundColor == "aqua" || item.backgroundColor == "hotpink" || item.backgroundColor == "gold" || item.backgroundColor == "lime"){
            this.calendarEvents.push({
              groupId: item.schedule_id,
              title: item.schedule_name,
              start: item.start,
              end: item.end,
              backgroundColor: item.backgroundColor,
              borderColor: item.borderColor,
              textColor: "black",
              allDay: item.allDay,
              extendedProps: item.extendedProps
            })
          }
          else{
            this.calendarEvents.push({
              groupId: item.schedule_id,
              title: item.schedule_name,
              start: item.start,
              end: item.end,
              backgroundColor: item.backgroundColor,
              borderColor: item.borderColor,
              textColor: "white",
              allDay: item.allDay,
              extendedProps: item.extendedProps
            })
          }
          
        }
        this.scheduleDetailsService.setTotalSchedule(ScheduleList.data.data.length)
      }
      else{
        console.log("error: getScheduleChannel()")
      }
      
    }))
  }

  getDeviceSchedule(){
    this.subscription.push( this.scheduleService.getScheduleDevice(this.device.device_id).subscribe((ScheduleList) => {
      console.log("getScheduleDevice", ScheduleList)

      this.calendarEvents = []

      if (ScheduleList.data.result == 'success'){
        for(const item of ScheduleList.data.data){
          this.calendarEvents.push({
            groupId: item.schedule_id,
            title: item.schedule_name,
            start: item.start,
            end: item.end,
            backgroundColor: item.backgroundColor,
            borderColor: item.borderColor,
            textColor: "black",
            allDay: item.allDay,
            extendedProps: item.extendedProps
          })
        }
        this.scheduleDetailsService.setTotalSchedule(ScheduleList.data.data.length)
      }
      else{
        console.log("error: getScheduleDevice()")
      }
      
    }))
  }

  toggleRightNav() {
    this.sidenavright.toggle();
  }

  sidenavMode() {
    return this.layoutService.getSidenavMode();
  }

  rightNavStatus(status) {
    if (status === 1) {
      this.sidenavright.open();
    } else {
      this.sidenavright.close();
    }
  }

  handleDateClick(arg) {
    console.log(this.editScheduleService.getLockStatus())
    if(!this.addSchedule && !this.channelName && this.editScheduleService.getLockStatus()){
      console.log("getallevent", this.calendarComponent.getApi().getEvents())
      console.log(arg)
      this.scheduleDetailsService.setArgumentSchedule(arg)
      this.addSchedule = true
      this.editSchedule = false
      this.channelName = false
      this.sidenavright.open();
    }
  }

  goToDeviceList() {
    this.deviceListService.setScheduleState(false)
  }

  goToChannelList() {
    this.channelListService.setScheduleState(false)
  }

  onContextMenu(item) {
    console.log("item =", item)
    item.jsEvent.preventDefault();
    this.contextMenuPosition.x = item.jsEvent.clientX + 'px';
    this.contextMenuPosition.y = item.jsEvent.clientY + 'px';
    this.contextMenu.menuData = { 'item': item };
    this.contextMenu.menu.focusFirstItem('mouse');

    if (item.event.title != '') {
      this.contextMenu.openMenu();
    }

  }

  onPopover(event, element){
    console.log("Popover",event)
    console.log("Element",element)
    element.popover({title:event.event.title, content:event.event.title, trigger: 'hover',
    placement: 'top',
    container: 'body'})
  }

  eventClick(model) {
    if(!this.addSchedule && !this.channelName){

      if (model.event.title != '') {
        console.log("receive", model.event);
  
        for (var i = 0; i < this.calendarEvents.length; i++) {
          if (this.calendarEvents[i].title === model.event.title) {
            this.selectedIndex = i
            break
          }
        }
  
        this.editSchedule = true
        this.addSchedule = false
        this.channelName = false
  
        this.scheduleDetailsService.setScheduleEdit(model.event.groupId)
        this.sidenavright.open();
      }
    }
    
  }
}
