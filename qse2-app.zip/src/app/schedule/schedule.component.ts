import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../layout/layout.service';
import { ScheduleDetailsService } from './schedule-details/schedule-details.service';
import { DeviceListService } from '../monitoring/device-list/device-list.service';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {

  monitoring  = false

  totalSchedule = 0

  constructor(
    private layoutService: LayoutService,
    private scheduleDetailsService: ScheduleDetailsService,
    private deviceListService:DeviceListService,
  ) {

    scheduleDetailsService.totalSchedule.subscribe(Total => {
      this.totalSchedule = Total
    })
   }

  ngOnInit(): void {
    this.monitoring = this.deviceListService.getMonitoringStatus()
    
    this.layoutService.toggleLeft(true);
  }

  togglerightNav() {
    this.layoutService.toggleRight();
  }

  channelName(){
    this.scheduleDetailsService.setChannelNameList(true)
  }

  addSchedule(){
    this.scheduleDetailsService.setAddScheduleNow()
  }
}
