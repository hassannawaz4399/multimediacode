import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleContentVideoComponent } from './schedule-content-video.component';

describe('ScheduleContentVideoComponent', () => {
  let component: ScheduleContentVideoComponent;
  let fixture: ComponentFixture<ScheduleContentVideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleContentVideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleContentVideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
