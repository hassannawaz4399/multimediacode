import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleContentImageComponent } from './schedule-content-image.component';

describe('ScheduleContentImageComponent', () => {
  let component: ScheduleContentImageComponent;
  let fixture: ComponentFixture<ScheduleContentImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleContentImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleContentImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
