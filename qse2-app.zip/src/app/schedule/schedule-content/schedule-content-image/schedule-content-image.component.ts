import { Component, OnInit } from '@angular/core';
import { ModalUploadFileComponent } from 'src/app/modals/content/modal-upload-file/modal-upload-file.component';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';
import { MatDialog } from '@angular/material/dialog';
import { ScheduleDetailsService } from '../../schedule-details/schedule-details.service';

declare var require: any
const bytes = require('bytes');
const prettyMilliseconds = require('pretty-ms');

export interface ContentManager {
  is_folder: boolean;
  title: string;
  filename: string;
  parent: string;
  path: string;
  format: string;
  format_type: string;
  resolution: string;
  duration: number;
  size: number;
  description: string;
  is_used: boolean;
  uploaded_by: string;
  inserted_at: string;
  updated_at: string;
  is_selected: boolean;
}

@Component({
  selector: 'app-schedule-content-image',
  templateUrl: './schedule-content-image.component.html',
  styleUrls: ['./schedule-content-image.component.css']
})
export class ScheduleContentImageComponent implements OnInit {

  isLoading = true;

  currentPath: ContentManager;
  pathList = '';
  currentPathList: Array<ContentManager> = [];

  contentList = [];
  fileList = [];
  folderList = [];

  size = []
  duration = []

  filelength = 0;
  folderlength = 0;
  search = ""

  order: boolean = false;

  constructor(
    private contentManagerService: ContentManagerService,
    private scheduleDetailsService: ScheduleDetailsService,
    
    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.init_root();
    
    this.contentList = [];
    this.fileList = [];
    this.folderList = [];

    this.tableData(this.currentPath.filename);
  }

  init_root() {
    this.currentPath = {
      is_folder: true,
      title: "",
      filename: "root",
      parent: "root",
      path: "/",
      format: "folder",
      format_type: "",
      resolution: "",
      duration: null,
      size: null,
      is_used: false,
      description: "Root directory",
      uploaded_by: "qubit",
      inserted_at: "",
      updated_at: "",
      is_selected: false,
    };
  }

  set_current_path(item) {
    this.currentPath = item;
  }

  tableData(key) {
    this.isLoading = true;

    this.filelength = 0;
    this.folderlength = 0;

    this.contentList = [];
    this.contentManagerService
      .getContentManagerListParentData(key)
      .subscribe((contentManagerList) => {
        if (contentManagerList.result === "success") {
          this.isLoading = false;
          const dataList = contentManagerList.data;
          for (const item of dataList) {
            item.is_selected = false;
          }
          this.contentList = dataList;

          this.fullData();

          console.log("this.contentList : ", this.contentList);
        } else {
          console.log("Error getContentManagerListData()");
        }
      });
  }

  openFolder(type, folder) {
    switch (type) {
      case "open":
        if (folder.is_folder) {
          this.set_current_path(folder);
          this.currentPathList.push(folder);
          this.makeCurrentPathList();
          this.tableData(folder.filename);
        }
        break;
      case "back":
        if (folder.is_folder) {
          this.set_current_path(folder);
          this.makeCurrentPathList();
          this.tableData(folder.filename);
        }
        break;

      default:
        break;
    }
  }

  popFolder() {
    this.currentPathList.pop();
    if (this.currentPathList.length > 0) {
      this.makeCurrentPathList();
      const pathNow = this.currentPathList[this.currentPathList.length - 1];
      this.openFolder("back", pathNow);
    } else {
      // Main
      this.pathList = "";
      this.init_root();
      this.tableData(this.currentPath.filename);
    }
  }

  makeCurrentPathList() {
    this.pathList = "";
    for (const x of this.currentPathList) {
      this.pathList = this.pathList + "/" + x.title;
    }
  }

  Sort(change) {
    console.log('order', change)
    this.order = change;
    
    this.folderList.sort((n1, n2) => {
      return (this.order) ? n1.title.localeCompare(n2.title) : n2.title.localeCompare(n1.title);
    });

    this.fileList.sort((n1, n2) => {
      return (this.order) ? n1.title.localeCompare(n2.title) : n2.title.localeCompare(n1.title);
    });
  }

  calculateLength() {

    for (var i = 0; i < this.fileList.length; i++){
      this.size[i] = bytes(this.fileList[i].size)
      if (this.fileList[i].duration > 0){
        this.duration[i] = prettyMilliseconds(this.fileList[i].duration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: true })
      }
      else{
        this.duration[i] = "00:00:00"
      }
    }
    
  }

  openFileUploadModal() {

    const  dialogRef = this.dialog.open(ModalUploadFileComponent, {
      width: "70%",
      height: "auto",
      data: this.currentPath,
    });
    
  }

  fullData(){
    
    this.fileList = [];
    this.folderList = [];

    for(const item of this.contentList )
    {
      if(item.format == 'folder'){
        this.folderList.push(item)
      }

      else if(item.format == 'image'){
        this.fileList.push(item)
      }
    }

    this.Sort(true);
    this.calculateLength()
  }

  selectedContent(data){
    this.scheduleDetailsService.setSelectedContentStatus(false)
    this.scheduleDetailsService.setSelectedContent({title:data.title, type:data.format, duration:data.duration, filename:data.filename})
  }
}
