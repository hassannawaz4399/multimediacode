import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleContentChannelNameComponent } from './schedule-content-channel-name.component';

describe('ScheduleContentChannelNameComponent', () => {
  let component: ScheduleContentChannelNameComponent;
  let fixture: ComponentFixture<ScheduleContentChannelNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleContentChannelNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleContentChannelNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
