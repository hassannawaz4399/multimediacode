import { Component, OnInit } from '@angular/core';
import { ChannelListService } from 'src/app/channel/channel-list/channel-list.service';
import { ScheduleDetailsService } from '../../schedule-details/schedule-details.service';

@Component({
  selector: 'app-schedule-content-channel-name',
  templateUrl: './schedule-content-channel-name.component.html',
  styleUrls: ['./schedule-content-channel-name.component.css']
})
export class ScheduleContentChannelNameComponent implements OnInit {

  channelList

  constructor(
    private channelListService: ChannelListService,
    private scheduleDetailsService: ScheduleDetailsService,
  ) {   }

  ngOnInit(): void {
    this.channelListService.getChannelListData().subscribe((ChannelList) => {
      this.channelList = ChannelList
      console.log(this.channelList)
    })
  }

  cancel(){
    this.scheduleDetailsService.setChannelNameList(false)
  }
}
