import { Component, OnInit } from '@angular/core';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { ScheduleDetailsService } from '../../schedule-details/schedule-details.service';

declare var require: any
const bytes = require('bytes');
const prettyMilliseconds = require('pretty-ms');

@Component({
  selector: 'app-schedule-content-playlist',
  templateUrl: './schedule-content-playlist.component.html',
  styleUrls: ['./schedule-content-playlist.component.css']
})
export class ScheduleContentPlaylistComponent implements OnInit {

  search = ""
  duration = []
  size = []

  order: boolean = false;

  playlistList = []

  constructor(
    private playlistService: PlaylistService,
    private scheduleDetailsService: ScheduleDetailsService,
  ) { }

  ngOnInit(): void {
    this.playlistService.getAllPlaylistListData().subscribe((PlaylistList) => {
      console.log("getAllPlaylistListData()", PlaylistList)
      if (PlaylistList.data.result == "success") {

        const tempData = PlaylistList.data.data

        for (const item of tempData) {
          for (const zone of item.zone_info) {
            zone.duration = 0
            zone.size = 0

            for (const playlist of zone.playlist_info) {
              zone.duration += playlist.duration
              zone.size += playlist.size
            }
          }
        }
        this.playlistList = tempData

        console.log("playlist", this.playlistList)

        this.Sort(true)
        this.calculateDurationSize()

      }
    })
  }

  Sort(change) {
    console.log('order', change)
    this.order = change;
    this.playlistList.sort((n1, n2) => {
      return (this.order) ? n1.playlist_name.localeCompare(n2.playlist_name) : n2.playlist_name.localeCompare(n1.playlist_name);
    });
  }

  calculateDurationSize() {
    for (var i = 0; i < this.playlistList.length; i++) {
      // console.log(i, this.playlistList[i])
      this.size[i] = bytes(this.playlistList[i].size)
      this.duration[i] = prettyMilliseconds(this.playlistList[i].duration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: true })
    }
  }

  selectedContent(data){
    this.scheduleDetailsService.setSelectedContentStatus(false)
    this.scheduleDetailsService.setSelectedContent({title:data.playlist_name, type:"playlist", duration:data.duration, filename:data.playlist_name})
  }
}
