import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleContentAppComponent } from './schedule-content-app.component';

describe('ScheduleContentAppComponent', () => {
  let component: ScheduleContentAppComponent;
  let fixture: ComponentFixture<ScheduleContentAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleContentAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleContentAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
