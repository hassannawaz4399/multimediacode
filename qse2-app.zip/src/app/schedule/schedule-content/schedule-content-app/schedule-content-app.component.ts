import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-content-app',
  templateUrl: './schedule-content-app.component.html',
  styleUrls: ['./schedule-content-app.component.css']
})
export class ScheduleContentAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
