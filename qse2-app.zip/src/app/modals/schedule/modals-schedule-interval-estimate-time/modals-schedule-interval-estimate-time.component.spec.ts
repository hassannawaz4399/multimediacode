import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsScheduleIntervalEstimateTimeComponent } from './modals-schedule-interval-estimate-time.component';

describe('ModalsScheduleIntervalEstimateTimeComponent', () => {
  let component: ModalsScheduleIntervalEstimateTimeComponent;
  let fixture: ComponentFixture<ModalsScheduleIntervalEstimateTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsScheduleIntervalEstimateTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsScheduleIntervalEstimateTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
