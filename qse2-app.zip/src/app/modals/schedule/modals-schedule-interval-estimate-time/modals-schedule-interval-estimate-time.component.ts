import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';

export interface EstimateSchedule{
  daily_duration:string;
  schedule_duration:string;
  schedulelist:ScheduleList[];
}
export interface ScheduleList{
  start_date:string;
  start_time:string;
  end_date:string;
  end_time:string;
}
@Component({
  selector: 'app-modals-schedule-interval-estimate-time',
  templateUrl: './modals-schedule-interval-estimate-time.component.html',
  styleUrls: ['./modals-schedule-interval-estimate-time.component.css']
})
export class ModalsScheduleIntervalEstimateTimeComponent implements OnInit {

  localData: any;
  action: string;

  scheduleListDisplayColumn: string[] = ['no', 'start_date', 'start_time', 'end_date', 'end_time']

  schedule_list: MatTableDataSource<ScheduleList>;

  constructor(
    public dialogRef: MatDialogRef<ModalsScheduleIntervalEstimateTimeComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.localData = { ...data };
    this.action = this.localData.action;
    this.localData.data = JSON.parse(this.localData.data)
    this.schedule_list = new MatTableDataSource<ScheduleList>(this.localData.data.schedulelist) 
    console.log(this.localData , this.schedule_list);
   }

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
