import { Component, OnInit, Inject, Optional } from '@angular/core';
import { ScheduleService } from 'src/app/services/schedule/schedule.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ScheduleDetailsService } from 'src/app/schedule/schedule-details/schedule-details.service';
import { EditScheduleService } from 'src/app/schedule/edit-schedule/edit-schedule.service';

@Component({
  selector: 'app-modals-schedule-delete',
  templateUrl: './modals-schedule-delete.component.html',
  styleUrls: ['./modals-schedule-delete.component.css']
})
export class ModalsScheduleDeleteComponent implements OnInit {

  localData: any;
  action: string;

  playlistList;

  errorLog = '';

  constructor(
    private editScheduleService:EditScheduleService,
    private scheduleService: ScheduleService,
    private scheduleDetailsService:ScheduleDetailsService,

    public dialogRef: MatDialogRef<ModalsScheduleDeleteComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data
  ) { 
    this.localData = { ...data };
    this.action = this.localData.action;

    console.log(this.localData);
  }

  ngOnInit(): void {
  }

  DeleteSchedule(){
    const sendThis = {schedule_id:this.localData.data.schedule_id}
    this.scheduleService.deleteSchedule(sendThis).subscribe(resp => {
      console.log("deleteschedule", resp)

      if (resp.data.result === "success"){
        this.scheduleDetailsService.setEditSchedule({})
        
        this.editScheduleService.setLockStatus(true)
        this.onNoClick()
      }
      else{
        console.log("error:deleteschedule()")
      }
    })
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
