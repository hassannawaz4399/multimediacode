import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsScheduleDeleteComponent } from './modals-schedule-delete.component';

describe('ModalsScheduleDeleteComponent', () => {
  let component: ModalsScheduleDeleteComponent;
  let fixture: ComponentFixture<ModalsScheduleDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsScheduleDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsScheduleDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
