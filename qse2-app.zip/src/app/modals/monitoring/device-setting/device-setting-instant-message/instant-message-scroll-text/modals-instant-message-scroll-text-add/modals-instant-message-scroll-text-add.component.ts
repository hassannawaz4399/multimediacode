import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

export interface ScrollText{
    text:string,
    font_size:number,
    text_speed:number,
    font_type:string,
    font_colour:string,
    background_colour:string,
    transparency:number,
    text_scroll:string,
    top:number;
    left:number;
    is_selected:boolean,
}

@Component({
  selector: 'app-modals-instant-message-scroll-text-add',
  templateUrl: './modals-instant-message-scroll-text-add.component.html',
  styleUrls: ['./modals-instant-message-scroll-text-add.component.css']
})
export class ModalsInstantMessageScrollTextAddComponent implements OnInit {

  font_type = ['arial', 'roboto']
  text_scroll = ['keyboard_arrow_right','keyboard_arrow_left','keyboard_arrow_up','keyboard_arrow_down']

  localData: any;
  action: string;

  constructor(
    public dialogRef: MatDialogRef<ModalsInstantMessageScrollTextAddComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: ScrollText
  ) {
    this.localData = {...data};
    this.action = this.localData.action;
    console.log(this.localData);
    this.localData.source = true;
   }

  ngOnInit(): void {
    this.localData.font_type='arial'
    this.localData.text_scroll='keyboard_arrow_right'
  }

  doAction() {
    this.dialogRef.close({event: this.action, data: this.localData});
  }

  onNoClick(): void {
    this.dialogRef.close({event: 'Cancel'});
  }
}
