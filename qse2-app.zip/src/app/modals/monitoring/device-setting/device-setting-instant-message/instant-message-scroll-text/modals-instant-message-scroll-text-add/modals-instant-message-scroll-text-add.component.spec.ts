import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsInstantMessageScrollTextAddComponent } from './modals-instant-message-scroll-text-add.component';

describe('ModalsInstantMessageScrollTextAddComponent', () => {
  let component: ModalsInstantMessageScrollTextAddComponent;
  let fixture: ComponentFixture<ModalsInstantMessageScrollTextAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsInstantMessageScrollTextAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsInstantMessageScrollTextAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
