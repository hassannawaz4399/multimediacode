import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsInstantMessageAnnouncementAddImageComponent } from './modals-instant-message-announcement-add-image.component';

describe('ModalsInstantMessageAnnouncementAddImageComponent', () => {
  let component: ModalsInstantMessageAnnouncementAddImageComponent;
  let fixture: ComponentFixture<ModalsInstantMessageAnnouncementAddImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsInstantMessageAnnouncementAddImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsInstantMessageAnnouncementAddImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
