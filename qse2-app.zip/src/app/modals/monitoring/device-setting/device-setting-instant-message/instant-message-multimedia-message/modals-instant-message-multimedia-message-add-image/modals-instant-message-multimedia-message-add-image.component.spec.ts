import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsInstantMessageMultimediaMessageAddImageComponent } from './modals-instant-message-multimedia-message-add-image.component';

describe('ModalsInstantMessageMultimediaMessageAddImageComponent', () => {
  let component: ModalsInstantMessageMultimediaMessageAddImageComponent;
  let fixture: ComponentFixture<ModalsInstantMessageMultimediaMessageAddImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsInstantMessageMultimediaMessageAddImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsInstantMessageMultimediaMessageAddImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
