import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsInstantMessageEmergencyAddImageComponent } from './modals-instant-message-emergency-add-image.component';

describe('ModalsInstantMessageEmergencyAddImageComponent', () => {
  let component: ModalsInstantMessageEmergencyAddImageComponent;
  let fixture: ComponentFixture<ModalsInstantMessageEmergencyAddImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsInstantMessageEmergencyAddImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsInstantMessageEmergencyAddImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
