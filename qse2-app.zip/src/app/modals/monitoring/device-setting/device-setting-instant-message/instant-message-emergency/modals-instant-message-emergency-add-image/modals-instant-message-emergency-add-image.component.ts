import { Component, OnInit, Inject, Optional, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';
import { Subscription } from 'rxjs';

declare var require: any
const bytes = require('bytes');
const prettyMilliseconds = require('pretty-ms');

export interface ContentManager {
  is_folder: boolean;
  title: string;
  filename: string;
  parent: string;
  path: string;
  format: string;
  format_type: string;
  resolution: string;
  duration: number;
  size: number;
  description: string;
  is_used: boolean;
  uploaded_by: string;
  inserted_at: string;
  updated_at: string;
  is_selected: boolean;
}

export interface image{
  content: {},
  top: number,
  left: number,
  duration: number,
  is_selected:boolean,
}

@Component({
  selector: 'app-modals-instant-message-emergency-add-image',
  templateUrl: './modals-instant-message-emergency-add-image.component.html',
  styleUrls: ['./modals-instant-message-emergency-add-image.component.css']
})
export class ModalsInstantMessageEmergencyAddImageComponent implements OnInit, OnDestroy {

  
  localData: any;
  action: string;
  openContent: boolean = false;

  isLoading = true;

  currentPath: ContentManager;
  pathList = '';
  currentPathList: Array<ContentManager> = [];

  subscription : Subscription[] = []

  contentList = [];
  fileList = [];
  folderList = [];

  size = []
  duration = []

  filelength = 0;
  folderlength = 0;
  search = ""

  order: boolean = false;

  constructor(
    private contentManagerService: ContentManagerService,

    public dialogRef: MatDialogRef<ModalsInstantMessageEmergencyAddImageComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data:image
  ) {
    this.localData = {...data};
    this.action = this.localData.action;
    console.log(this.localData);
    this.localData.source = true;
   }

   ngOnInit(): void {
    this.search = ""
    this.init_root();

    this.contentList = [];
    this.fileList = [];
    this.folderList = [];

    this.tableData(this.currentPath.filename);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at modals-instant-message-emergency-add-image")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  doAction() {
    this.dialogRef.close({event: this.action, data: this.localData});
  }

  onNoClick(): void {
    this.dialogRef.close({event: 'Cancel'});
  }

  choosecontent(status){
    this.openContent=status
  }

  init_root() {
    this.currentPath = {
      is_folder: true,
      title: "",
      filename: "root",
      parent: "root",
      path: "/",
      format: "folder",
      format_type: "",
      resolution: "",
      duration: null,
      size: null,
      is_used: false,
      description: "Root directory",
      uploaded_by: "qubit",
      inserted_at: "",
      updated_at: "",
      is_selected: false,
    };
  }

  set_current_path(item) {
    this.currentPath = item;
  }

  tableData(key) {
    this.isLoading = true;

    this.filelength = 0;
    this.folderlength = 0;

    this.contentList = [];
    this.subscription.push( this.contentManagerService
      .getContentManagerListParentData(key)
      .subscribe((contentManagerList) => {
        if (contentManagerList.result === "success") {
          this.isLoading = false;
          const dataList = contentManagerList.data;
          for (const item of dataList) {
            item.is_selected = false;
          }
          this.contentList = dataList;

          this.fullData();

          console.log("this.contentList : ", this.contentList);
        } else {
          console.log("Error getContentManagerListData()");
        }
      }))
  }

  openFolder(type, folder) {
    switch (type) {
      case "open":
        if (folder.is_folder) {
          this.set_current_path(folder);
          this.currentPathList.push(folder);
          this.makeCurrentPathList();
          this.tableData(folder.filename);
        }
        break;
      case "back":
        if (folder.is_folder) {
          this.set_current_path(folder);
          this.makeCurrentPathList();
          this.tableData(folder.filename);
        }
        break;

      default:
        break;
    }
  }

  popFolder() {
    this.currentPathList.pop();
    if (this.currentPathList.length > 0) {
      this.makeCurrentPathList();
      const pathNow = this.currentPathList[this.currentPathList.length - 1];
      this.openFolder("back", pathNow);
    } else {
      // Main
      this.pathList = "";
      this.init_root();
      this.tableData(this.currentPath.filename);
    }
  }

  makeCurrentPathList() {
    this.pathList = "";
    for (const x of this.currentPathList) {
      this.pathList = this.pathList + "/" + x.title;
    }
  }

  Sort(change) {
    console.log('order', change)
    this.order = change;

    this.folderList.sort((n1, n2) => {
      return (this.order) ? n1.title.localeCompare(n2.title) : n2.title.localeCompare(n1.title);
    });

    this.fileList.sort((n1, n2) => {
      return (this.order) ? n1.title.localeCompare(n2.title) : n2.title.localeCompare(n1.title);
    });
  }

  calculateLength() {

    for (var i = 0; i < this.fileList.length; i++) {
      this.size[i] = bytes(this.fileList[i].size)
      if (this.fileList[i].duration > 0) {
        this.duration[i] = prettyMilliseconds(this.fileList[i].duration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: true })
      }
      else {
        this.duration[i] = "00:00:00"
      }
    }

  }

  openFileUploadModal() {

    // const dialogRef = this.dialog.open(ModalUploadFileComponent, {
    //   width: "70%",
    //   height: "auto",
    //   data: this.currentPath,
    // });

  }

  fullData() {

    this.fileList = [];
    this.folderList = [];

    for (const item of this.contentList) {
      if (item.format == 'folder') {
        this.folderList.push(item)
      }

      else if (item.format != 'folder') {
        this.fileList.push(item)
      }
    }

    this.Sort(true);
    this.calculateLength()
  }

  selectedContent(data){
    this.localData.content = data
    this.localData.duration = data.duration
    this.choosecontent(false)
  }

}
