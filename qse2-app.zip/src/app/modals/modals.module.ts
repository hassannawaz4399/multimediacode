import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { MaterialsModule } from 'src/app/materials/materials.module';
import { ModalUploadFileComponent } from './content/modal-upload-file/modal-upload-file.component';
import { PlaylistContentVideoComponent } from 'src/app/playlist/playlist-content/playlist-content-video/playlist-content-video.component';
import { PlaylistContentImageComponent } from 'src/app/playlist/playlist-content/playlist-content-image/playlist-content-image.component';
import { PlaylistContentAudioComponent } from 'src/app/playlist/playlist-content/playlist-content-audio/playlist-content-audio.component';
import { ModalsChannelAddComponent } from './channel/modals-channel-add/modals-channel-add.component';
import { ChannelListComponent } from 'src/app/channel/channel-list/channel-list.component';
import { ModalsInstantMessageScrollTextAddComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-scroll-text/modals-instant-message-scroll-text-add/modals-instant-message-scroll-text-add.component';
import { InstantMessageScrollTextComponent } from 'src/app/monitoring/device-setting/device-setting-instant-message/instant-message-scroll-text/instant-message-scroll-text.component';
import { ModalsInstantMessageAnnouncementAddTextComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-announcement/modals-instant-message-announcement-add-text/modals-instant-message-announcement-add-text.component';
import { InstantMessageAnnouncementComponent } from 'src/app/monitoring/device-setting/device-setting-instant-message/instant-message-announcement/instant-message-announcement.component';
import { ModalsInstantMessageAnnouncementAddImageComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-announcement/modals-instant-message-announcement-add-image/modals-instant-message-announcement-add-image.component';
import { ModalsInstantMessageMultimediaMessageAddImageComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-multimedia-message/modals-instant-message-multimedia-message-add-image/modals-instant-message-multimedia-message-add-image.component';
import { InstantMessageMultimediaMessageComponent } from 'src/app/monitoring/device-setting/device-setting-instant-message/instant-message-multimedia-message/instant-message-multimedia-message.component';
import { ModalsInstantMessageEmergencyAddImageComponent } from './monitoring/device-setting/device-setting-instant-message/instant-message-emergency/modals-instant-message-emergency-add-image/modals-instant-message-emergency-add-image.component';
import { ModalUploadFileOldComponent } from './content/modal-upload-file-old/modal-upload-file-old.component';
import { ModalsPlaylistDeleteComponent } from './playlist/modals-playlist-delete/modals-playlist-delete.component';
import { PlaylistListComponent } from '../playlist/playlist-list/playlist-list.component';
import { ModalsPlaylistDuplicateComponent } from './playlist/modals-playlist-duplicate/modals-playlist-duplicate.component';
import { ModalsChannelDeleteComponent } from './channel/modals-channel-delete/modals-channel-delete.component';
import { ModalsChannelEditComponent } from './channel/modals-channel-edit/modals-channel-edit.component';
import { ModalsScheduleIntervalEstimateTimeComponent } from './schedule/modals-schedule-interval-estimate-time/modals-schedule-interval-estimate-time.component';
import { AddScheduleComponent } from '../schedule/add-schedule/add-schedule.component';
import { ModalsScheduleDeleteComponent } from './schedule/modals-schedule-delete/modals-schedule-delete.component';
import { EditScheduleComponent } from '../schedule/edit-schedule/edit-schedule.component';

@NgModule({
  declarations: [
    // contents
    ModalUploadFileComponent,
    ModalUploadFileOldComponent,

    //channel
    ModalsChannelAddComponent,
    ModalsChannelDeleteComponent,
    ModalsChannelEditComponent,

    //Monitroing-devicesetting-instantmessage
    ModalsInstantMessageScrollTextAddComponent,
    ModalsInstantMessageAnnouncementAddTextComponent,
    ModalsInstantMessageAnnouncementAddImageComponent,
    ModalsInstantMessageMultimediaMessageAddImageComponent,
    ModalsInstantMessageEmergencyAddImageComponent,

    //Playlist
    ModalsPlaylistDeleteComponent,
    ModalsPlaylistDuplicateComponent,

    //Schedule
    ModalsScheduleIntervalEstimateTimeComponent,
    ModalsScheduleDeleteComponent
  ],
  imports: [
    CommonModule,
    MaterialsModule
  ],
  exports: [
    // contents
    ModalUploadFileComponent,
    ModalUploadFileOldComponent,

    //channel
    ModalsChannelAddComponent,
    ModalsChannelDeleteComponent,
    ModalsChannelEditComponent,

    //Monitroing-devicesetting-instantmessage
    ModalsInstantMessageScrollTextAddComponent,
    ModalsInstantMessageAnnouncementAddTextComponent,
    ModalsInstantMessageAnnouncementAddImageComponent,
    ModalsInstantMessageMultimediaMessageAddImageComponent,
    
    //Playlist
    ModalsPlaylistDeleteComponent,
    ModalsPlaylistDuplicateComponent,

    //Schedule
    ModalsScheduleIntervalEstimateTimeComponent,
    ModalsScheduleDeleteComponent
  ],
  entryComponents: [
    // contents
    ModalUploadFileComponent,
    ModalUploadFileOldComponent,
    PlaylistContentVideoComponent,
    PlaylistContentImageComponent,
    PlaylistContentAudioComponent,

    //channel
    ModalsChannelAddComponent,
    ModalsChannelDeleteComponent,
    ModalsChannelEditComponent,
    ChannelListComponent,

    //Monitroing-devicesetting-instantmessage
    ModalsInstantMessageScrollTextAddComponent,
    InstantMessageScrollTextComponent,
    ModalsInstantMessageAnnouncementAddTextComponent,
    ModalsInstantMessageAnnouncementAddImageComponent,
    InstantMessageAnnouncementComponent,
    ModalsInstantMessageMultimediaMessageAddImageComponent,
    InstantMessageMultimediaMessageComponent,
    
    //Playlist
    ModalsPlaylistDeleteComponent,
    ModalsPlaylistDuplicateComponent,
    PlaylistListComponent,

    //Schedule
    ModalsScheduleIntervalEstimateTimeComponent,
    AddScheduleComponent,
    ModalsScheduleDeleteComponent,
    EditScheduleComponent,
  ]
})
export class ModalsModule { }
