import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsChannelDeleteComponent } from './modals-channel-delete.component';

describe('ModalsChannelDeleteComponent', () => {
  let component: ModalsChannelDeleteComponent;
  let fixture: ComponentFixture<ModalsChannelDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsChannelDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsChannelDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
