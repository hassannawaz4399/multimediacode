import { Component, OnInit, Inject, Optional, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ChannelListService } from 'src/app/channel/channel-list/channel-list.service';
import { ChannelService } from 'src/app/services/channel/channel.service';
import { Subscription } from 'rxjs';

export interface Channel{
  channel_name: string;
  total_linked_device: number;
  inserted_at: string;
  updated_at: string;
  schedule_now: string;
  schedule_next: string;
  playlist_now: string;
  playlist_next: string;
  idle: boolean;
  status: boolean;
  linked_info: LinkedInfo;
  live: [];
  is_selected: boolean;
}

export interface LinkedInfo{
  total_device: number;
  total_location: number;
  total_branch: number;
  linked_device: Branch[]
}

export interface Branch{
  branchID: string;
  total_device: number;
  total_location: number;
  locations: Location[]
}

export interface Location{
  locationID: string,
  total_device: number;
  floor: string;
  devices: Device[];
}

export interface Device{
  deviceID:string;
  online:boolean
}

@Component({
  selector: 'app-modals-channel-delete',
  templateUrl: './modals-channel-delete.component.html',
  styleUrls: ['./modals-channel-delete.component.css']
})
export class ModalsChannelDeleteComponent implements OnInit, OnDestroy {

  localData: any;
  action: string;

  channelList;

  errorLog = '';

  subscription: Subscription[] = []

  constructor(
    private channelService:ChannelService,
    private channelListService: ChannelListService,

    public dialogRef: MatDialogRef<ModalsChannelDeleteComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.localData = { ...data };
    this.action = this.localData.action;
    this.localData.data = JSON.parse(this.localData.data)
    console.log(this.localData);
    this.localData.source = true;
  }

  ngOnInit(): void {
    this.channelList = JSON.parse(this.channelListService.getSelectedDetails())
    console.log("channellist", this.channelList)
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.

    console.log("unsubscribe all subscription at modals-channel-delete")
    for (const item of this.subscription) {
      item.unsubscribe()
    }
  }

  onNoClick(): void {
    this.dialogRef.close({event: 'Cancel'});
  }

  deleteChannel(){
    let deleteStatus = true
    let temp = JSON.stringify(this.channelList)
    
    for (const item of this.channelList) {
      const sendThis = { channel_name: item.channel_name }
      this.channelService.delete_channel(sendThis).subscribe(resp => {
        console.log('this.channelService.delete_channel : ', resp);

        if (resp.data.result == "success") {
          // temp = JSON.parse(temp)
          // const index = 
          this.channelListService.setCheckedbox("allClose")
          
        }
        else {
          deleteStatus = false
          this.errorLog = item.playlist_name + " : " + resp.data.reason;
        }
      })
    }

    if(deleteStatus)
    this.dialogRef.close({event: this.action})
  }

}
