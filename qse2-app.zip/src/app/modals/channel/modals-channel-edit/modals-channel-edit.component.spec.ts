import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsChannelEditComponent } from './modals-channel-edit.component';

describe('ModalsChannelEditComponent', () => {
  let component: ModalsChannelEditComponent;
  let fixture: ComponentFixture<ModalsChannelEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsChannelEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsChannelEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
