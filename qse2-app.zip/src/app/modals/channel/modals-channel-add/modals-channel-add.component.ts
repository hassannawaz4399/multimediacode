import { Component, OnInit, Optional, Inject, ViewChild, OnDestroy, NgZone } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ModalsChannelAddService } from './modals-channel-add.service';
import { ChannelService } from 'src/app/services/channel/channel.service';
import { MatStepper } from '@angular/material/stepper';
import { Subscription } from 'rxjs';
import { BranchService } from 'src/app/services/monitoring/branch.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';

export interface Channel {
  channel_name: string;
  description: string;
  total_linked_branch: number;
  total_linked_location: number;
  total_linked_device: number;
  inserted_at: string;
  updated_at: string;
  schedule_now: string;
  schedule_next: string;
  playlist_now: string;
  playlist_next: string;
  idle: boolean;
  status: boolean;
  created_by: string;
  linked_device: Branch[]
  live: [];
  is_selected: boolean;
}

export interface Branch {
  branch_id: string;
  branch_name: string;
  branch_info: Location[]
}

export interface Location {
  location_name: string,
  floor: string;
  devices: Device[];
}

export interface Device {
  device_id: string;
  device_name: string;
  online: boolean
}

@Component({
  selector: 'app-modals-channel-add',
  templateUrl: './modals-channel-add.component.html',
  styleUrls: ['./modals-channel-add.component.css']
})
export class ModalsChannelAddComponent implements OnInit, OnDestroy {

  localData: any;
  action: string;

  addchannel = {}
  firstFormGroup: FormGroup;
  // secondFormGroup: FormGroup;

  deviceList
  linkedDevice = []

  totalBranch = 0;
  totalLocation = 0;
  totalDevice = 0;

  totalBranchLinked = 0;
  totalLocationLinked = 0;
  totalDeviceLinked = 0;

  selectedIndex = 0;

  errorLog = ''

  subscription: Subscription[] = []

  @ViewChild('stepper') stepper: MatStepper;
  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  constructor(
    private branchService: BranchService,
    private modalsChannelAddService: ModalsChannelAddService,
    private channelService: ChannelService,
    private _formBuilder: FormBuilder,
    private _ngZone: NgZone,

    public dialogRef: MatDialogRef<ModalsChannelAddComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: Channel,
  ) {
    this.localData = { ...data };
    this.action = this.localData.action;
    console.log(this.localData);
    // this.localData.source = true;

    this.getAllAvailableDevices()

  }

  ngOnInit(): void {

    this.firstFormGroup = this._formBuilder.group({
      // firstCtrlFirstForm: ['', Validators.required],
      secondCtrlFirstForm: ['', Validators.required],
      thirdCtrlFirstForm: []
    });
    // this.secondFormGroup = this._formBuilder.group({
    //   secondCtrl: ['', Validators.required]
    // });

    // triger for auto size font modify
    // this.triggerResize()
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.

    console.log("unsubscribe all subscription at modals-channel-add")
    for (const item of this.subscription) {
      item.unsubscribe()
    }
  }

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this._ngZone.onStable.pipe(take(1))
        .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  getAllAvailableDevices() {
    this.subscription.push(this.channelService.getlinkedDevice().subscribe((LinkedDevice) => {
      let notavailabledevice = LinkedDevice.data
      this.subscription.push(this.branchService.getBranchListData().subscribe((DeviceList) => {

        if (DeviceList.data.result === "success") {
          let data = DeviceList.data.data
          let availabledevice = []

          if (notavailabledevice.length != 0) {
            for (const itembranch of data) {
              let tempbranch = JSON.stringify(itembranch)
              const checkBranch = notavailabledevice.find((item) => item.branch_id === itembranch.branch_id);

              availabledevice.push(JSON.parse(tempbranch))
              availabledevice[availabledevice.length - 1].branch_info = []

              for (const itemlocation of itembranch.branch_info) {
                let templocation = JSON.stringify(itemlocation)

                availabledevice[availabledevice.length - 1].branch_info.push(JSON.parse(templocation))
                availabledevice[availabledevice.length - 1].branch_info[availabledevice[availabledevice.length - 1].branch_info.length - 1].devices = []


                for (const itemdevice of itemlocation.devices) {
                  let tempdevice = JSON.stringify(itemdevice)

                  if (checkBranch === undefined) {
                    availabledevice[availabledevice.length - 1].branch_info[availabledevice[availabledevice.length - 1].branch_info.length - 1].devices.push(JSON.parse(tempdevice))
                  }
                  else {
                    const checkDevice = checkBranch.devices.find((item) => item.device_id === itemdevice.device_id);

                    if (checkDevice === undefined) {
                      console.log(itembranch.branch_name, itemlocation.location_name, itemdevice.device_name)
                      availabledevice[availabledevice.length - 1].branch_info[availabledevice[availabledevice.length - 1].branch_info.length - 1].devices.push(JSON.parse(tempdevice))
                    }
                  }
                }
                if (availabledevice[availabledevice.length - 1].branch_info[availabledevice[availabledevice.length - 1].branch_info.length - 1].devices.length == 0) {
                  availabledevice[availabledevice.length - 1].branch_info.pop()
                }
              }
              if (availabledevice[availabledevice.length - 1].branch_info.length == 0) {
                console.log(availabledevice[availabledevice.length - 1].branch_name)
                availabledevice.pop()
              }
            }
          }
          else {
            availabledevice = DeviceList.data.data
          }

          console.log(availabledevice)

          for (const itembranch of availabledevice) {
            if(itembranch.branch_info.length == 0){
              itembranch.hide = true
            }
            else{
              let allhide = true
              for (const itemlocation of itembranch.branch_info) {
                if(itemlocation.devices.length == 0){
                  itemlocation.hide = true
                }
                else{
                  itemlocation.hide = false
                  allhide = false
                  for (const itemdevice of itemlocation.devices) {
                    itemdevice.hide = false
                  }
                }
              }

              itembranch.hide = allhide
            }
          }

          this.deviceList = availabledevice
          this.calcDeviceList()
          this.calcLinkedDevice()

          console.log(this.deviceList)
        }
      }))

    }))
  }

  addBranch(branch) {
    let included = false;
    const jsonBranch = JSON.stringify(this.deviceList[branch])

    for (var i = 0; i < this.linkedDevice.length; i++) {
      if (this.linkedDevice[i].branch_id == this.deviceList[branch].branch_id) {
        this.linkedDevice[i] = []
        this.linkedDevice[i] = JSON.parse(jsonBranch)

        included = true
      }
    }

    if (!included) {
      this.linkedDevice.push(JSON.parse(jsonBranch))
    }

    this.deviceList[branch].hide = true
    for (const itemlocation of this.deviceList[branch].branch_info) {
      itemlocation.hide = true
      for (const itemdevice of itemlocation.devices) {
        itemdevice.hide = true
      }
    }

    console.log("AddBranch", this.linkedDevice)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  addLocation(branch, location) {

    const jsonBranch = JSON.stringify(this.deviceList[branch])
    const jsonLocation = JSON.stringify(this.deviceList[branch].branch_info[location])

    const checkBranch = this.linkedDevice.find((item) => item.branch_id === this.deviceList[branch].branch_id);
    if (checkBranch === undefined) {
      this.linkedDevice.push(JSON.parse(jsonBranch))
      this.linkedDevice[this.linkedDevice.length - 1].branch_info = []
      this.linkedDevice[this.linkedDevice.length - 1].branch_info.push(JSON.parse(jsonLocation))
    }
    else {
      let included = false;
      for (var i = 0; i < checkBranch.branch_info.length; i++) {
        if (checkBranch.branch_info[i].location_name == this.deviceList[branch].branch_info[location].location_name && checkBranch.branch_info[i].floor == this.deviceList[branch].branch_info[location].floor) {
          checkBranch.branch_info[i] = []
          checkBranch.branch_info[i] = JSON.parse(jsonLocation)

          included = true
        }
      }

      if (!included) {
        checkBranch.branch_info.push(JSON.parse(jsonLocation))
      }

      // const checkLocation = checkBranch.branch_info.find((item) => item.location_name === this.deviceList[branch].branch_info[location].location_name && item.floor === this.deviceList[branch].branch_info[location].floor);
      // if (checkLocation === undefined) {
      //   checkBranch.branch_info.push(JSON.parse(jsonLocation))
      // }
      // else {
      //   checklocation 
      // }
    }

    this.deviceList[branch].branch_info[location].hide = true

    for (const itemdevice of this.deviceList[branch].branch_info[location].devices) {
      itemdevice.hide = true
    }

    console.log("AddLocation", this.linkedDevice)

    this.checkingDeviceListlocation(branch)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  addDevice(branch, location, device) {

    const jsonBranch = JSON.stringify(this.deviceList[branch])
    const jsonLocation = JSON.stringify(this.deviceList[branch].branch_info[location])
    const jsonDevice = JSON.stringify(this.deviceList[branch].branch_info[location].devices[device])

    const checkBranch = this.linkedDevice.find((item) => item.branch_id === this.deviceList[branch].branch_id);
    if (checkBranch === undefined) {
      this.linkedDevice.push(JSON.parse(jsonBranch))
      this.linkedDevice[this.linkedDevice.length - 1].branch_info = []
      this.linkedDevice[this.linkedDevice.length - 1].branch_info.push(JSON.parse(jsonLocation))
      this.linkedDevice[this.linkedDevice.length - 1].branch_info[0].devices = []
      this.linkedDevice[this.linkedDevice.length - 1].branch_info[0].devices.push(JSON.parse(jsonDevice))
    }
    else {
      const checkLocation = checkBranch.branch_info.find((item) => item.location_name === this.deviceList[branch].branch_info[location].location_name && item.floor === this.deviceList[branch].branch_info[location].floor);
      if (checkLocation === undefined) {
        checkBranch.branch_info.push(JSON.parse(jsonLocation))
        checkBranch.branch_info[checkBranch.branch_info.length - 1].devices = []
        checkBranch.branch_info[checkBranch.branch_info.length - 1].devices.push(JSON.parse(jsonDevice))
      }
      else {
        checkLocation.devices.push(JSON.parse(jsonDevice))
      }
    }

    this.deviceList[branch].branch_info[location].devices[device].hide = true
    console.log("AddDevice", this.linkedDevice)

    this.checkingDeviceListDevice(branch, location)
    this.checkingDeviceListlocation(branch)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  removeBranch(branch) {
    for (let itembranch of this.deviceList) {
      if (itembranch.branch_id == this.linkedDevice[branch].branch_id) {
        itembranch.hide = false

        for (const itemlocation of itembranch.branch_info) {
          itemlocation.hide = false

          for (const itemdevice of itemlocation.devices) {
            itemdevice.hide = false
          }
        }
      }
    }
    this.linkedDevice.splice(branch, 1)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  removeLocation(branch, location) {
    for (let itembranch of this.deviceList) {
      if (itembranch.branch_id == this.linkedDevice[branch].branch_id) {
        itembranch.hide = false

        for (const itemlocation of itembranch.branch_info) {
          if (itemlocation.location_name == this.linkedDevice[branch].branch_info[location].location_name && itemlocation.floor == this.linkedDevice[branch].branch_info[location].floor) {
            itemlocation.hide = false

            for (const itemdevice of itemlocation.devices) {
              itemdevice.hide = false
            }
          }
        }
      }
    }

    this.linkedDevice[branch].branch_info.splice(location, 1)

    this.checkingLinkedDevicelocation(branch)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  removeDevice(branch, location, device) {
    for (let itembranch of this.deviceList) {
      if (itembranch.branch_id == this.linkedDevice[branch].branch_id) {
        itembranch.hide = false

        for (const itemlocation of itembranch.branch_info) {
          if (itemlocation.location_name == this.linkedDevice[branch].branch_info[location].location_name && itemlocation.floor == this.linkedDevice[branch].branch_info[location].floor) {
            itemlocation.hide = false

            for (const itemdevice of itemlocation.devices) {
              if (itemdevice.device_id == this.linkedDevice[branch].branch_info[location].devices[device].device_id) {
                itemdevice.hide = false
              }
            }
          }
        }
      }
    }

    this.linkedDevice[branch].branch_info[location].devices.splice(device, 1)

    this.checkingLinkedDevicedevice(branch, location)
    this.checkingLinkedDevicelocation(branch)

    this.calcDeviceList()
    this.calcLinkedDevice()
  }

  calcDeviceList() {
    this.totalBranch = this.deviceList.length;
    this.totalLocation = 0;
    this.totalDevice = 0;

    for (const itembranch of this.deviceList) {
      if (!itembranch.hide) {
        this.totalLocation += itembranch.branch_info.length
        for (const itemlocation of itembranch.branch_info) {
          if (!itemlocation.hide) {
            this.totalDevice += itemlocation.devices.length
            for (const itemdevice of itemlocation.devices) {
              if (itemdevice.hide)
                this.totalDevice--
            }
          }
          else {
            this.totalLocation--
          }
        }

      }
      else {
        this.totalBranch--
      }
    }
  }

  calcLinkedDevice() {
    this.totalBranchLinked = this.linkedDevice.length;
    this.totalLocationLinked = 0;
    this.totalDeviceLinked = 0;

    for (const itembranch of this.linkedDevice) {
      this.totalLocationLinked += itembranch.branch_info.length
      for (const itemlocation of itembranch.branch_info) {
        this.totalDeviceLinked += itemlocation.devices.length
      }
    }
  }

  checkingDeviceListlocation(branch) {
    const checkLocation = this.deviceList[branch].branch_info.find((item) => item.hide === false);
    if (checkLocation === undefined) {
      this.deviceList[branch].hide = true
    }
  }

  checkingDeviceListDevice(branch, location) {
    const checkDevice = this.deviceList[branch].branch_info[location].devices.find((item) => item.hide === false);
    if (checkDevice === undefined) {
      this.deviceList[branch].branch_info[location].hide = true
    }
  }

  checkingLinkedDevicelocation(branch) {
    if (this.linkedDevice[branch].branch_info.length == 0) {
      this.linkedDevice.splice(branch, 1)
    }
  }

  checkingLinkedDevicedevice(branch, location) {
    if (this.linkedDevice[branch].branch_info[location].devices.length == 0) {
      this.linkedDevice[branch].branch_info.splice(location, 1)
    }
  }

  setIndex(event) {
    if (this.selectedIndex == 0) {
      this.checkChannelName(event)
    }
    else {
      this.selectedIndex = event.selectedIndex;
    }

  }

  triggerClick() {
    if (this.selectedIndex === 2) {
      this.getAllData();
    }
  }

  checkChannelName(event) {

    if (this.firstFormGroup.value.secondCtrlFirstForm) {
      const sendThis = { channel_name: this.firstFormGroup.value.secondCtrlFirstForm };
      console.log("sendThis", sendThis)
      this.subscription.push(this.channelService.checkChannelName(sendThis).subscribe(resp => {
        console.log('this.channelService.checkChannelName : ', resp);

        if (resp.data.allow) {
          this.selectedIndex = event.selectedIndex;
          this.errorLog = '';
        }
        else {
          this.errorLog = resp.data.reason;
          this.selectedIndex = 0;

          this.stepper.selectedIndex = 0;
        }
      }))
    }
    else {
      this.errorLog = 'Playlist name cannot empty';
    }
  }

  getAllData() {
    let templinkeddevice = JSON.stringify(this.linkedDevice)
    let cleanlinkeddevice = JSON.parse(templinkeddevice)
    cleanlinkeddevice.forEach(branch => {
      delete branch.hide;
      delete branch.show;

      branch.branch_info.forEach(location => {
        delete location.hide;
        delete location.show;

        location.devices.forEach(device => {
          delete device.hide;
          delete device.show;
          delete device.online;
        });
      });
    });

    this.addchannel = {}
    this.addchannel = {
      channel_name: this.firstFormGroup.value.secondCtrlFirstForm,
      description: this.firstFormGroup.value.thirdCtrlFirstForm,
      created_by: 'Qubit',
      total_linked_device: this.totalDeviceLinked,
      total_linked_branch: this.totalBranchLinked,
      total_linked_location: this.totalLocationLinked,
      linked_device: cleanlinkeddevice,
    }

    this.localData.channel_name = this.firstFormGroup.value.secondCtrlFirstForm;
    this.localData.description = this.firstFormGroup.value.thirdCtrlFirstForm;
    this.localData.total_linked_device = this.totalDeviceLinked;
    this.localData.total_linked_branch = this.totalBranchLinked;
    this.localData.total_linked_location = this.totalLocationLinked;
    this.localData.linked_device = this.linkedDevice;
  }

  doAction() {
    console.log("Channel_Data", JSON.stringify(this.addchannel))

    this.subscription.push(this.channelService.add_channel(this.addchannel).subscribe(resp => {
      console.log('this.playlistService.add_channel : ', resp);
      if (resp.data.result === 'success') {
        console.log("complete add_channel")
        this.dialogRef.close({ event: this.action, data: this.localData });
      }
      else {
        console.log("error: playlistService.add_playlist");
      }
    }))


  }

  onNoClick(): void {
    this.dialogRef.close({ event: 'Cancel' });
  }
}
