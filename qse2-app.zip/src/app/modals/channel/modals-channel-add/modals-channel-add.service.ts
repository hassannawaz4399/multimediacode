import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ModalsChannelAddService {

  constructor(
    private http: HttpClient,
  ) { }

  getDeviceListData(): any {
    return this.http.get('assets/json/device-list-add-channel-list-data.json');
  }
}
