import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsChannelAddComponent } from './modals-channel-add.component';

describe('ModalsChannelAddComponent', () => {
  let component: ModalsChannelAddComponent;
  let fixture: ComponentFixture<ModalsChannelAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsChannelAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsChannelAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
