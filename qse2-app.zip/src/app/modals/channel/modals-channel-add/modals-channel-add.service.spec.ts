import { TestBed } from '@angular/core/testing';

import { ModalsChannelAddService } from './modals-channel-add.service';

describe('ModalsChannelAddService', () => {
  let service: ModalsChannelAddService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModalsChannelAddService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
