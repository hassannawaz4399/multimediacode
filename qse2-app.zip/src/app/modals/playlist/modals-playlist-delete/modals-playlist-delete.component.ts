import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { PlaylistListService } from 'src/app/playlist/playlist-list/playlist-list.service';

export interface Playlist {
  playlist_name: string;
  status: boolean;
  size: number;
  duration: number;
  created_by: string;
  template: string;
  zone_info: ZoneInfo[];
  updated_at: Date;
  inserted_at: Date;
  is_selected: boolean;
}

export interface ZoneInfo {
  zone: string;
  playlist_info: PlaylistInfo[]
}

export interface PlaylistInfo {
  title: string;
  type: string;
  zone: string;
  from_zone: string;
  copy_ver: number;
  priority: number;
  size: number;
  duration: number;
  total_media: number;
  content: Content[];
}

export interface Content {
  priority: number;
  title: string;
  filename: string;
  duration: number;
  type: string;
  copy_ver: number;
}

@Component({
  selector: 'app-modals-playlist-delete',
  templateUrl: './modals-playlist-delete.component.html',
  styleUrls: ['./modals-playlist-delete.component.css']
})
export class ModalsPlaylistDeleteComponent implements OnInit {

  localData: any;
  action: string;

  playlistList;

  errorLog = '';

  constructor(
    private playlistService: PlaylistService,
    private playlistListService: PlaylistListService,

    public dialogRef: MatDialogRef<ModalsPlaylistDeleteComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.localData = { ...data };
    this.action = this.localData.action;
    this.localData.data = JSON.parse(this.localData.data)
    console.log(this.localData);
    // this.localData.source = true;
  }

  ngOnInit(): void {
    this.playlistList = JSON.parse(this.playlistListService.getSelectedDetails())
    console.log("playlist", this.playlistList)
  }

  onNoClick(): void {
    this.dialogRef.close({event: 'Cancel'});
  }

  deletePlaylist() {
    let deleteStatus = true
    let temp = JSON.stringify(this.playlistList)
    
    for (const item of this.playlistList) {
      const sendThis = { playlist_name: item.playlist_name }
      this.playlistService.delete_playlist(sendThis).subscribe(resp => {
        console.log('this.playlistService.delete_playlist : ', resp);

        if (resp.data.result === "success") {
          // temp = JSON.parse(temp)
          // const index = 
          this.playlistListService.setCheckedbox("allClose")
          
        }
        else {
          deleteStatus = false
          this.errorLog = item.playlist_name + " : " + resp.data.reason;
        }
      })
    }

    if(deleteStatus)
    this.dialogRef.close({event: this.action})
  }

}
