import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsPlaylistDeleteComponent } from './modals-playlist-delete.component';

describe('ModalsPlaylistDeleteComponent', () => {
  let component: ModalsPlaylistDeleteComponent;
  let fixture: ComponentFixture<ModalsPlaylistDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsPlaylistDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsPlaylistDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
