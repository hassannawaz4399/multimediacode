import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { PlaylistListService } from 'src/app/playlist/playlist-list/playlist-list.service';

export interface Playlist {
  playlist_name: string;
  status: boolean;
  size: number;
  duration: number;
  created_by: string;
  template: string;
  zone_info: ZoneInfo[];
  updated_at: Date;
  inserted_at: Date;
  is_selected: boolean;
}

export interface ZoneInfo {
  zone: string;
  playlist_info: PlaylistInfo[]
}

export interface PlaylistInfo {
  title: string;
  type: string;
  zone: string;
  from_zone: string;
  copy_ver: number;
  priority: number;
  size: number;
  duration: number;
  total_media: number;
  content: Content[];
}

export interface Content {
  priority: number;
  title: string;
  filename: string;
  duration: number;
  type: string;
  copy_ver: number;
}

@Component({
  selector: 'app-modals-playlist-duplicate',
  templateUrl: './modals-playlist-duplicate.component.html',
  styleUrls: ['./modals-playlist-duplicate.component.css']
})
export class ModalsPlaylistDuplicateComponent implements OnInit {

  localData: any;
  action: string;

  playlistList;
  playlistname

  errorLog = '';

  constructor(
    private playlistService: PlaylistService,
    private playlistListService: PlaylistListService,

    public dialogRef: MatDialogRef<ModalsPlaylistDuplicateComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.localData = { ...data };
    this.action = this.localData.action;
    this.localData.data = JSON.parse(this.localData.data)
    console.log(this.localData);
    this.localData.source = true;
  }

  ngOnInit(): void {
    this.playlistList = JSON.parse(this.playlistListService.getSelectedDetails())
    console.log("playlist", this.playlistList)
  }

  onNoClick(): void {
    this.dialogRef.close({event: 'Cancel'});
  }

  duplicatePlaylist() {
    const sendThis = {
      new_playlist_name:this.playlistname, 
      playlist_name:this.playlistList[0].playlist_name,
      created_by:'qubit'
    }
    this.playlistService.duplicate(sendThis).subscribe(resp => {
      console.log('this.playlistService.duplicate : ', resp);

      if (resp.data.result == "success") {
        // temp = JSON.parse(temp)
        // const index = 
        this.playlistListService.setCheckedbox("allClose")
        this.dialogRef.close({event: this.action})
        
      }
      else {
        this.errorLog = this.playlistname + " : " + resp.data.reason;
      }
    })
  }

}
