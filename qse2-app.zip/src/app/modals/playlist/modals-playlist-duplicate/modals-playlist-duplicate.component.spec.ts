import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalsPlaylistDuplicateComponent } from './modals-playlist-duplicate.component';

describe('ModalsPlaylistDuplicateComponent', () => {
  let component: ModalsPlaylistDuplicateComponent;
  let fixture: ComponentFixture<ModalsPlaylistDuplicateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalsPlaylistDuplicateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalsPlaylistDuplicateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
