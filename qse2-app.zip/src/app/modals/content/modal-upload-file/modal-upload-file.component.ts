import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpEventType } from '@angular/common/http';
import { Subscription } from 'rxjs';

export interface ContentManager {
  is_folder: boolean;
  title: string;
  filename: string;
  parent: string;
  path: string;
  format: string;
  format_type: string;
  resolution: string;
  duration: number;
  size: number;
  description: string;
  is_used: boolean;
  uploaded_by: string;
  inserted_at: string;
  updated_at: string;
  is_selected: boolean;
}

@Component({
  selector: 'app-modal-upload-file',
  templateUrl: './modal-upload-file.component.html',
  styleUrls: ['./modal-upload-file.component.css']
})
export class ModalUploadFileComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  fileData: string[] = [];
  uploadId = 0;
  valueUploaded: any[] = [];
  isSuccess: any[] = [];

  successUpload: Array<ContentManager> = [];
  filenameList = [];

  selectedfiles = 0;

  selectedPath: any;
  constructor(
    private contentManagerService:ContentManagerService,
    public dialogRef: MatDialogRef<ModalUploadFileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.selectedPath = data;
    console.log('Upload File to : ', this.selectedPath);
  }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at modal-upload-file")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  fileProgress(fileInput: any) {
    this.selectedfiles = fileInput.target.files.length
    for (let i = 0; i < fileInput.target.files.length; i++) {
      if (i < 10) {
        this.fileData.push(fileInput.target.files[i]);
        this.filenameList.push(fileInput.target.files[i].name);
        console.log(this.fileData[i]);
      }
    }
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.fileData[this.uploadId]);
    formData.append('path', "/");
    formData.append('parent', this.selectedPath.filename);
    formData.append('uploaded_by', this.selectedPath.uploaded_by);
    
    const toSend = {
      title : this.filenameList[this.uploadId],
      parent: this.selectedPath.filename
    };

    this.subscription.push( this.contentManagerService.check_dir(toSend).subscribe((resp) => {
      if (resp.result === 'success') {
        this.subscription.push( this.contentManagerService.upload_file(formData).subscribe((events) => {
         if (events.type === HttpEventType.UploadProgress) {
           console.log("uploadId: ", this.uploadId);
           console.log(
             "Upload progress: ",
             Math.round((events.loaded / events.total) * 100) + "%"
           );
           this.valueUploaded[this.uploadId] = Math.round(
             (events.loaded / events.total) * 100
           );
         } else if (events.type === HttpEventType.Response) {
           // console.log(events);
           if (events.status === 201) {
             // Upload success
             const resp: any = events.body;
             if (resp.result === "success") {
               this.isSuccess[this.uploadId] = true;
               console.log('Success upload : ', resp.data);
               this.successUpload.push(resp.data);
               this.repeatUpload();
             } else {
               console.log("events.body.result === 'error'");
               this.isSuccess[this.uploadId] = false;
               this.repeatUpload();
             }
           } else {
             // Error upload
           }
         }
       }))
      } else if (resp.result === 'error') {
       this.isSuccess[this.uploadId] = false;
       this.repeatUpload();
      }
   }))

    // this.contentManagerService.upload_file(formData).subscribe(events => {
    //   if (events.type === HttpEventType.UploadProgress) {
    //     console.log('uploadId: ', this.uploadId);
    //     console.log(
    //       'Upload progress: ',
    //       Math.round((events.loaded / events.total) * 100) + '%'
    //     );
    //     this.valueUploaded[this.uploadId] = Math.round((events.loaded / events.total) * 100);
    //   } else if (events.type === HttpEventType.Response) {
    //     // console.log(events);
    //     if (events.status === 201) {
    //       // Upload success
    //       const check: any = events.body;
    //       if (check.result === 'success') {
    //         this.isSuccess[this.uploadId] = true;
    //         console.log(check.data);
    //         // push events.body.data to row list
    //         this.contentManagerService.add_update(check.data);
    //         // do next upload
    //         this.uploadId++;
    //         if (this.uploadId < this.fileData.length) {
    //           this.onSubmit();
    //         } else {
    //           // Finish upload all files // Do something
    //           console.log('Finish upload all files');
    //         }
    //       } else {
    //         console.log('events.body.result === \'error\'');
    //         this.isSuccess[this.uploadId] = false;
    //       }
    //     } else {
    //       // Error upload
    //     }
    //   }
    // });
  }

  repeatUpload() {
    this.uploadId++;
    if (this.uploadId < this.fileData.length) {
      this.onSubmit();
    } else {
      // Finish upload all files // Do something
      console.log("Finish upload all files");
    }
  }

  close() {
    this.dialogRef.close({ event: 'Complete', data: this.successUpload});
  }
}
