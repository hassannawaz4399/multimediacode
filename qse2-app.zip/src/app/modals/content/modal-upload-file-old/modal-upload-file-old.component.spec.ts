import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalUploadFileOldComponent } from './modal-upload-file-old.component';

describe('ModalUploadFileOldComponent', () => {
  let component: ModalUploadFileOldComponent;
  let fixture: ComponentFixture<ModalUploadFileOldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalUploadFileOldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalUploadFileOldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
