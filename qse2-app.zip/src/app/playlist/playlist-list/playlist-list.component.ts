import { Component, OnInit, ViewChild, OnDestroy, ViewEncapsulation } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from "@angular/router";
import { MatSort } from '@angular/material/sort';
import { SignageInterface } from './signage-interface';
import { ELEMENT_DATA } from './sihnageDummyData';

declare var require: any
const prettyMilliseconds = require('pretty-ms');


@Component({
  selector: 'app-playlist-list',
  templateUrl: './playlist-list.component.html',
  styleUrls: ['./playlist-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PlaylistListComponent implements OnInit {
  selectedRowIndex: number = 1;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  selectedValue: any;
  FloorDropDown: any = [];
  LocationDropDown: any = [];
  DeviceNameDropDown: any = [];
  IPAddressDropDown: any = [];
  ModelDropDown: any = [];
  NowPlayingDropDown: any = [];
  MediaStatusDropDown: any = [];
  SoftwareVersionDropDown: any = [];
  RemortControlDropDown: any = [];
  MicomFirmwareDropDown: any = [];
  VolumDropDown: any = [];
  TileModeDropDown: any = [];
  BootingImageDropDown: any = [];
  PowerProfileDropDown: any = [];
  ConfigrationProfileDropDown: any = [];
  displayedColumnsNames: any;
  columnListing: any;
  filterData: any;
  dataSource = new MatTableDataSource<SignageInterface>(ELEMENT_DATA);
  displayedColumnsHeader: any[] = [
    "Floor",
    "Location",
    "DeviceName",
    "IPAddress",
    "Model",
    "NowPlaying",
    "MediaStatus",
    "SoftwareVersion",
    "MicomFirmware",
    "RemortControl",
    "Volum",
    "TileMode",
    "TileID",
    "BootingImage",
    "PowerProfile",
    "ConfigrationProfile",
  ];
  displayedColumnsHeaderForDropDown: any = [
    { name: "Floor", value: "Floor", checked: true },
    { name: "Location", value: "Location", checked: true },
    { name: "DeviceName", value: "DeviceName", checked: true },
    { name: "IPAddress", value: "IPAddress", checked: true },
    { name: "Model", value: "Model", checked: true },
    { name: "NowPlaying", value: "NowPlaying", checked: true },
    { name: "MediaStatus", value: "MediaStatus", checked: true },
    { name: "SoftwareVersion", value: "SoftwareVersion", checked: true },
    { name: "MicomFirmware", value: "MicomFirmware", checked: true },
    { name: "RemortControl", value: "RemortControl", checked: true },
    { name: "Volum", value: "Volum", checked: true },
    { name: "TileMode", value: "TileMode", checked: true },
    { name: "TileID", value: "TileID", checked: true },
    { name: "BootingImage", value: "BootingImage", checked: true },
    { name: "PowerProfile", value: "PowerProfile", checked: true },
    { name: "ConfigrationProfile", value: "ConfigrationProfile", checked: true },
  ];

  footerInputOptions: any = [
    { name: "App" },
    { name: "HDMI" },
    { name: "HDMI2" },
    { name: "DP" }
  ]
  constructor(public router: Router) { }
  ngOnInit() {
    this.displayedColumnsNames = this.displayedColumnsHeader;
    this.columnListing = this.displayedColumnsHeaderForDropDown;
    this.filterData = ELEMENT_DATA;
    this.assignValues(ELEMENT_DATA);
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  rowSelect(item) {
    this.selectedRowIndex = item.id;
  }
  getAllResult() {
    this.filterData.filter((m) => (m.selected = false));
    this.dataSource = new MatTableDataSource<SignageInterface>(this.filterData);
    this.selectedValue = [];
  }
  showBoolValues(arr, key): Array<any> {
    if (key && typeof key === "string") {
      return arr.filter(function (obj, index, arr) {
        return (
          arr
            .map(function (mapObj) {
              return mapObj[key];
            })
            .indexOf(obj[key]) === index
        );
      });
    } else {
      return arr.filter(function (item, index, arr) {
        return arr.indexOf(item) == index;
      });
    }
  }
  assignValues(data) {
    this.FloorDropDown = this.setValue('Floor', data)
    this.LocationDropDown = this.setValue('Location', data)
    this.SoftwareVersionDropDown = this.setValue('SoftwareVersion', data)
    this.RemortControlDropDown = this.setValue('RemortControl', data)
    this.MicomFirmwareDropDown = this.setValue('MicomFirmware', data)
    this.BootingImageDropDown = this.setValue('BootingImage', data)
    this.PowerProfileDropDown = this.setValue('PowerProfile', data)
    this.ConfigrationProfileDropDown = this.setValue('ConfigrationProfile', data)
    this.IPAddressDropDown = data.filter((x) => x.IPAddress != "");
    this.ModelDropDown = data.filter((x) => x.Model != "");
    this.MediaStatusDropDown = this.showBoolValues(data, "MediaStatus");
    this.TileModeDropDown = this.showBoolValues(data, "TileMode");
    this.VolumDropDown = data
  }
  checkAll(list, value) {
    list.forEach(element => {
      element.isSelected = true
    });
    list = [...list]
    this.dataSource = new MatTableDataSource<SignageInterface>(list);
    // return list.filter(
    //   (x) => x[value] ? x.isSelected = true : ""
    // );
  }
  setValue(value, data) {
    return data.filter(
      (x) => x[value] != ""
    );
  }
  filterValuesOnSelection(dropdowValue?: any[], selectedValue?: string, check?: boolean, key?: string) {
    this.filterData.filter((m) => {
      m[key] == selectedValue ? (m.selected = check) : "";
    });
    let filters = dropdowValue
      .filter((m) => m.selected == true)
      .map((x) => x[key]);
    let array = this.filterData.filter((m) => filters.includes(m[key]));
    this.dataSource = new MatTableDataSource<SignageInterface>(array);
  }
  totalChecked: number = 0
  totalCheckedCount() {
    this.totalChecked = 0
    ELEMENT_DATA.filter(m => {
      m.checked ? this.totalChecked = this.totalChecked + 1 : ''
    })
  }
  handleMouseOver(row) {
    const id = row.id
    ELEMENT_DATA.map((data: any) => {
      if (data.id === id) {
        data.show = true;
      }
    });
  }

  handleMouseLeave(row) {
    if (row.checked == true)
      return;
    else {
      const id = row.id;
      ELEMENT_DATA.map((data: any) => {
        if (data.id === id) {
          data.show = false;
        }
      });
    }

  }
  navigateToDevice(deviceName) {
    this.router.navigate(["device", { deviceName: deviceName }]);
  }
}