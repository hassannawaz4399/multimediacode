export interface SignageInterface {
  id: number;
  Floor: string;
  Location: string;
  IPAddress: string;
  Model: string;
  DeviceName: string;
  NowPlaying: string;
  MediaStatus: boolean
  SoftwareVersion: string;
  MicomFirmware: string;
  RemortControl: string;
  Volum: number;
  TileMode: string;
  TileID: string;
  BootingImage: string;
  PowerProfile: string;
  ConfigrationProfile: string;
  show: boolean;
  checked: boolean;
}