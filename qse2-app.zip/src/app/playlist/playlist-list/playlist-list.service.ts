import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlaylistListService {

  SelectedDetails = JSON.stringify([])
  AddPlaylist
  EditPlaylist
  @Output() refreshTable: EventEmitter<any> = new EventEmitter();
  @Output() addPlaylist: EventEmitter<any> = new EventEmitter();
  @Output() selectedDetails: EventEmitter<any> = new EventEmitter();
  @Output() unchecked: EventEmitter<any> = new EventEmitter();
  @Output() duplicateSelected: EventEmitter<any> = new EventEmitter();
  @Output() deleteSelected: EventEmitter<any> = new EventEmitter();
  @Output() editSelected: EventEmitter<any> = new EventEmitter();
  @Output() editPlaylist: EventEmitter<any> = new EventEmitter();
  constructor(
    private http: HttpClient,
  ) { }

  getPlaylistListData(): any {
    return this.http.get('assets/json/playlist-list-data.json');
  }

  refreshPlaylist() {
    this.refreshTable.emit('refreh')
  }

  setAddPlaylist(status) {
    this.AddPlaylist = status
    this.addPlaylist.emit(status)
  }

  getAddPlaylist(){
    return this.AddPlaylist
  }

  setSelectedDetails(selected) {
    this.SelectedDetails = selected
    this.selectedDetails.emit(selected)
  }

  getSelectedDetails() {
    return this.SelectedDetails
  }

  setCheckedbox(checked) {
    this.unchecked.emit(checked)
  }

  setDeleteSelected() {
    this.deleteSelected.emit('delete')
  }

  setEditSelected() {
    this.editSelected.emit('edit')
  }

  setDuplicateSelected() {
    this.duplicateSelected.emit('duplicate')
  }

  setEditPlaylist(status) {
    this.EditPlaylist = status
    this.editPlaylist.emit(status)
  }

  getEditPlaylist(){
    return this.EditPlaylist
  }
}
