import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { LayoutService } from 'src/app/layout/layout.service';
import { PlaylistListService } from '../playlist-list/playlist-list.service';
import { PlaylistAddEditService } from './playlist-add-edit.service';
import { PlaylistConfigurationAddService } from '../playlist-configuration-add/playlist-configuration-add.service';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { ActivatedRoute, Router } from "@angular/router";
import { PlaylistTemplateService } from 'src/app/services/playlist/playlist-template.service';
import { Subscription } from 'rxjs';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';

declare var require: any
const bytes = require('bytes');
const prettyMilliseconds = require('pretty-ms');

@Component({
  selector: 'app-playlist-add-edit',
  templateUrl: './playlist-add-edit.component.html',
  styleUrls: ['./playlist-add-edit.component.css']
})
export class PlaylistAddEditComponent implements OnInit, OnDestroy {

  // cmsUrl = 'http://id.qubit.asia:8081/'
  // cmsUrl='http://localhost:8081/'

  cmsUrl = ''

  rightSideNavWidth;
  sideNavMode
  // once = false
  addstatus = false;
  status: boolean = false;

  index = 0
  contents = []
  size = []
  duration = []
  displayduration;
  displaysize;
  playlistName = "Playlist Name"
  zonecontent = []

  subscription : Subscription[] = []

  layoutselected = {
    background: "color",
    bg_color: "white",
    bg_image: null,
    height: 1080,
    inserted_at: "2020-04-20T11:03:22",
    name: "Template 1",
    type: "portrait",
    updated_at: "2020-04-20T11:03:22",
    width: 1920,
    zones: [
      {
        background: "color",
        bg_color: "white",
        bg_image: null,
        height: 1080,
        inserted_at: "2020-04-27T15:11:05",
        left: 0,
        name: "Main",
        top: 0,
        updated_at: "2020-04-27T15:11:05",
        width: 1920
      }
    ]
  }

  @ViewChild('sidenavright') sidenavright;
  @ViewChild('sidenavleft') sidenavleft;

  constructor(
    private contentManagerService: ContentManagerService,
    private layoutService: LayoutService,
    private playlistListService: PlaylistListService,
    private playlistAddEditService: PlaylistAddEditService,
    private playlistConfigurationAddService: PlaylistConfigurationAddService,
    private playlistService: PlaylistService,
    private playlistTemplateService: PlaylistTemplateService,

    private readonly route: ActivatedRoute,
    private readonly router: Router,
  ) {
    this.subscription.push( layoutService.rightWidth.subscribe(data => {
      this.rightSideNavWidth = data;
    }))

    this.subscription.push( playlistAddEditService.sideNavMode.subscribe(Mode => {
      this.sideNavMode = Mode
    }))

    this.subscription.push( playlistAddEditService.playlistName.subscribe(Name => {
      this.playlistName = Name
    }))

    this.subscription.push( playlistAddEditService.savePlaylist.subscribe(Save => {
      console.log("setsaveplylistats")
      // if (!this.once)
        this.savePlaylist()
    }))

    this.subscription.push( playlistAddEditService.saveUpdatePlaylist.subscribe(Save => {
      console.log("setsaveupdateplaylistats")
      // if (!this.once)
        this.saveUpdatePlaylist()
    }))

    this.subscription.push( playlistConfigurationAddService.layoutSelected.subscribe(layout => {
      this.layoutselected = layout
      console.log(this.layoutselected)

      this.zoneContent()
    }))
  }

  ngOnInit(): void {
    this.cmsUrl = this.contentManagerService.getCmsUrl()
    
    this.layoutService.toggleLeft(false);

    this.addstatus = this.playlistListService.getAddPlaylist()

    if (this.addstatus) {
      this.sideNavMode = "over"
      this.zoneContent()
    }
    else {
      this.sideNavMode = "side"
      this.editData()

    }

  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at playlist-add-edit")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  zoneContent() {
    this.zonecontent = []

    for (var i = 0; i < this.layoutselected.zones.length; i++) {
      this.zonecontent.push({ zone: this.layoutselected.zones[i], content: [], totalDuration: 0, totalSize: 0, totalMedia: 0 })
    }

    this.calculateDurationSize()
    // this.playlistAddEditService.setZoneContent(JSON.stringify(this.zonecontent))
  }

  editData() {
    const editplaylist = JSON.parse(this.playlistListService.getSelectedDetails())
    this.playlistName = editplaylist[0].playlist_name

    this.subscription.push( this.playlistTemplateService.getOneTemplate(editplaylist[0].template).subscribe((TemplatelistList) => {
      console.log(".playlistTemplateService.getOneTemplate", TemplatelistList)
      if (TemplatelistList.result == 'success') {
        this.layoutselected = TemplatelistList.data
        console.log(this.layoutselected)

        this.subscription.push( this.playlistService.getOnePlaylist(this.playlistName).subscribe((PlaylistList) => {
          console.log("getOnePlaylist", PlaylistList)
          if (PlaylistList.data.result == 'success') {
            let playlist = PlaylistList.data.playlist

            this.zonecontent = []
            for (const item of playlist.zone_info) {
              let totalMedia = 0
              let totalSize = 0
              let totalDuration = 0
              for (const info of item.playlist_info) {
                totalMedia += info.total_media
                totalSize += info.size
                totalDuration += info.duration
              }

              for (var i = 0; i < this.layoutselected.zones.length; i++) {
                if (item.zone == this.layoutselected.zones[i].name)
                  this.zonecontent.push({ zone: this.layoutselected.zones[i], content: item.playlist_info, totalDuration: totalDuration, totalSize: totalSize, totalMedia: totalMedia })
              }
              console.log("zone content", this.zonecontent)
            }

            this.calculateDurationSize()

            // this.playlistAddEditService.setZoneContent(JSON.stringify(this.zonecontent))
          }
        }))
      }
    }))


  }

  duplicateitem(item) {
    const temp = Object.assign({}, item);

    console.log("duplicate", item)
    if (!this.status) {

      this.zonecontent[this.index].totalSize += temp.size
      this.zonecontent[this.index].totalDuration += temp.duration
      this.zonecontent[this.index].totalMedia += temp.total_media

      this.zonecontent[this.index].content.push(temp);

      this.calculateDurationSize()
      this.setnewpriority()

      this.checkingDuplicate(this.zonecontent[this.index].content.length - 1, item.title, item.from_zone)

      // this.playlistAddEditService.setZoneContent(JSON.stringify(this.zonecontent))
    }
  }

  calculateDurationSize() {

    for (var i = 0; i < this.zonecontent[this.index].content.length; i++) {
      if (this.zonecontent[this.index].content[i].duration > 0) {
        this.duration[i] = this.getTimeCalculation(this.zonecontent[this.index].content[i].duration)
        // this.duration[i] = prettyMilliseconds(this.zonecontent[this.index].content[i].duration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: false })
      }
      else if(this.zonecontent[this.index].content[i].type == 'playlist'){
        this.duration[i] = this.getTimeCalculation(this.zonecontent[this.index].content[i].duration)
      }
      this.size[i] = bytes(this.zonecontent[this.index].content[i].size)
    }

    this.displayduration = prettyMilliseconds(this.zonecontent[this.index].totalDuration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: false })
    this.displaysize = bytes(this.zonecontent[this.index].totalSize)
  }

  getTimeCalculation(timestampDifference) {
    timestampDifference = timestampDifference / 1000
    var hours = ~~(timestampDifference / 3600);
    var minuts = ~~((timestampDifference - hours * 3600) / 60);
    var seconds = timestampDifference - hours * 3600 - minuts * 60;
    console.log("seconds", this.truncate(seconds))
    return { hour: hours, minute: minuts, second: this.truncate(seconds) };

    // check if the hour is greater then 1 than return time with hour else return minutes.
  }

  truncate(value) {
    if (value < 0) {
      return Math.ceil(value);
    }

    return Math.floor(value);
  }

  changeMillisecond(durationIndex){
    console.log("duration", this.duration[durationIndex])

    let currentduration = this.getMillisecond(this.duration[durationIndex])

    let differentduration = currentduration - this.zonecontent[this.index].content[durationIndex].duration

    this.zonecontent[this.index].totalDuration += differentduration

    this.displayduration = prettyMilliseconds(this.zonecontent[this.index].totalDuration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: false })
    this.zonecontent[this.index].content[durationIndex].duration = currentduration

    this.zonecontent[this.index].content[durationIndex].content[0].duration = currentduration
  }

  getMillisecond(timeduaration){
    return ((timeduaration.hour * 60 * 60) + (timeduaration.minute * 60) + (timeduaration.second)) * 1000
  }

  displaydurationplaylist(milliduration){
    if(milliduration > 0)
      return prettyMilliseconds(milliduration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: false })

    return '00:00:00'
  }

  delete(index) {
    if (!this.status) {
      console.log('index => ', index);

      this.zonecontent[this.index].totalSize -= this.zonecontent[this.index].content[index].size
      this.zonecontent[this.index].totalDuration -= this.zonecontent[this.index].content[index].duration
      this.zonecontent[this.index].totalMedia -= this.zonecontent[this.index].content[index].total_media

      this.zonecontent[this.index].content.splice(index, 1)

      this.calculateDurationSize()
      this.setnewpriority()

      // this.playlistAddEditService.setZoneContent(JSON.stringify(this.zonecontent))
    }
  }

  drop(event: CdkDragDrop<string[]>, data) {

    if (!this.status) {
      console.log("event drag ", data.previousContainer.data[event.previousIndex])

      this.playlistAddEditService.Drop(event);

      if (data.previousContainer.id != 'list-1') {

        if (data.previousContainer.data[event.previousIndex].format != null) {
          let dropduration = 10000
          if(data.previousContainer.data[event.previousIndex].duration > 0){
            dropduration = data.previousContainer.data[event.previousIndex].duration
          }
          this.zonecontent[this.index].totalMedia++
          this.zonecontent[this.index].totalSize += data.previousContainer.data[event.previousIndex].size
          this.zonecontent[this.index].totalDuration += dropduration

          this.zonecontent[this.index].content[event.currentIndex] = {}
          this.zonecontent[this.index].content[event.currentIndex].title = data.previousContainer.data[event.previousIndex].title
          this.zonecontent[this.index].content[event.currentIndex].type = data.previousContainer.data[event.previousIndex].format
          this.zonecontent[this.index].content[event.currentIndex].zone = this.zonecontent[this.index].zone.name
          this.zonecontent[this.index].content[event.currentIndex].from_zone = null
          this.zonecontent[this.index].content[event.currentIndex].copy_ver = 0
          this.zonecontent[this.index].content[event.currentIndex].priority = event.currentIndex
          this.zonecontent[this.index].content[event.currentIndex].duration = dropduration
          this.zonecontent[this.index].content[event.currentIndex].size = data.previousContainer.data[event.previousIndex].size
          this.zonecontent[this.index].content[event.currentIndex].total_media = 1
          this.zonecontent[this.index].content[event.currentIndex].content = [
            {
              priority: 0,
              title: data.previousContainer.data[event.previousIndex].title,
              filename: data.previousContainer.data[event.previousIndex].filename,
              duration: dropduration,
              type: data.previousContainer.data[event.previousIndex].format,
              resolution: data.previousContainer.data[event.previousIndex].resolution,
              copy_ver: 0
            }
          ]
        }
        else if (data.previousContainer.data[event.previousIndex].zone != null) {
          let playlistContent = JSON.parse(this.playlistAddEditService.getPlaylistContent())
          console.log("playlistcontent", playlistContent)

          this.zonecontent[this.index].totalMedia += data.previousContainer.data[event.previousIndex].playlist_info.length
          this.zonecontent[this.index].totalSize += data.previousContainer.data[event.previousIndex].size
          this.zonecontent[this.index].totalDuration += data.previousContainer.data[event.previousIndex].duration

          this.zonecontent[this.index].content[event.currentIndex] = {}
          this.zonecontent[this.index].content[event.currentIndex].title = playlistContent.playlist_name
          this.zonecontent[this.index].content[event.currentIndex].type = "playlist"
          this.zonecontent[this.index].content[event.currentIndex].zone = this.zonecontent[this.index].zone.name
          this.zonecontent[this.index].content[event.currentIndex].from_zone = data.previousContainer.data[event.previousIndex].zone
          this.zonecontent[this.index].content[event.currentIndex].copy_ver = 0
          this.zonecontent[this.index].content[event.currentIndex].priority = event.currentIndex
          this.zonecontent[this.index].content[event.currentIndex].duration = data.previousContainer.data[event.previousIndex].duration
          this.zonecontent[this.index].content[event.currentIndex].size = data.previousContainer.data[event.previousIndex].size
          this.zonecontent[this.index].content[event.currentIndex].total_media = data.previousContainer.data[event.previousIndex].playlist_info.length
          this.zonecontent[this.index].content[event.currentIndex].content = []

          for (const temp of data.previousContainer.data[event.previousIndex].playlist_info) {
            this.zonecontent[this.index].content[event.currentIndex].content.push({
              priority: temp.priority,
              title: temp.content[0].title,
              filename: temp.content[0].filename,
              duration: temp.content[0].duration,
              type: temp.content[0].type,
              resolution: temp.content[0].resolution,
              copy_ver: 0
            })
          }
        }
      }

      this.checkingDuplicate(event.currentIndex, this.zonecontent[this.index].content[event.currentIndex].title, this.zonecontent[this.index].content[event.currentIndex].from_zone)

      this.calculateDurationSize()
    }
    this.setnewpriority()

    console.log("Contents name", this.zonecontent[this.index].content[event.currentIndex].name)
    console.log("Contents", this.zonecontent[this.index].content)

    // this.playlistAddEditService.setZoneContent(JSON.stringify(this.zonecontent))
  }

  optionStatus() {
    this.playlistAddEditService.setOptionStatus(true)
  }

  previewStatus() {
    this.playlistAddEditService.setPreviewStatus(true)
    const allinfo = { template: this.layoutselected, content: this.zonecontent }

    let allContents = JSON.stringify(allinfo);

    this.playlistAddEditService.setPreviewContents(allContents)

    console.log(this.contents)
  }

  getcurrentzone(currentindex) {
    this.index = currentindex

    this.calculateDurationSize()
  }

  savePlaylist() {
    // this.once = true

    let totalsize = 0
    let selectduration = 0
    let playlist_info = []
    let zoneList = []

    // let getzonecontent = JSON.parse(this.playlistAddEditService.getZoneContent())

    for (const item of this.zonecontent) {
      totalsize += item.totalSize

      if (selectduration < item.totalDuration) {
        selectduration = item.totalDuration
      }
      zoneList.push({ zone: item.zone.name, playlist_info: item.content })
      // for (const info of item.content) {
      //   playlist_info.push(info)
      // }
    }

    // for (const zone of this.zonecontent) {
    //   zoneList.push(zone.zone.name)
    // }

    const addPlaylist = {
      playlist_name: this.playlistName,
      status: this.status,
      size: totalsize,
      duration: selectduration,
      created_by: 'qubit',
      template: this.layoutselected.name,
      template_info:this.layoutselected,
      zone_info: zoneList,
      // playlist_info: playlist_info,
    }

    
    console.log("setsaveplylistbwh", this.zonecontent[this.index].content)

    this.subscription.push( this.playlistService.add_playlist(addPlaylist).subscribe(resp => {
      console.log('this.playlistService.add_playlist : ', resp);
      if (resp.data.result === 'success') {
        console.log("complete add_playlist")
        this.playlistListService.setAddPlaylist(false)
      }
      else {
        console.log("error: playlistService.add_playlist");
      }
    }))

    console.log("addplaylist", JSON.stringify(addPlaylist))
    // this.playlistListService.setAddPlaylist(false)

  }

  saveUpdatePlaylist() {
    // this.once = true

    console.log("setsaveupdateplylistbwh")
    let totalsize = 0
    let selectduration = 0
    let playlist_info = []
    let zoneList = []
    // let getzonecontent = JSON.parse(this.playlistAddEditService.getZoneContent())

    for (const item of this.zonecontent) {
      totalsize += item.totalSize

      if (selectduration < item.totalDuration) {
        selectduration = item.totalDuration
      }
      zoneList.push({ zone: item.zone.name, playlist_info: item.content })
      // for (const info of item.content) {
      //   playlist_info.push(info)
      // }
    }

    // for (const zone of this.zonecontent) {
    //   zoneList.push(zone.zone.name)
    // }

    const updatePlaylist = {
      playlist_name: this.playlistName,
      status: this.status,
      size: totalsize,
      duration: selectduration,
      edit_by: 'qubit',
      template: this.layoutselected.name,
      template_info:this.layoutselected,
      zone_info: zoneList,
      // playlist_info: playlist_info,
    }

    this.subscription.push( this.playlistService.update_playlist(updatePlaylist).subscribe(resp => {
      console.log('this.playlistService.update_playlist : ', resp);
      if (resp.data.result === 'success') {
        console.log("complete update_playlist")

        this.router.navigate(['/playlist']);
        this.playlistListService.setEditPlaylist(false)
      }
      else {
        console.log("error: playlistService.update_playlist");
      }
    }))

    console.log("updatePlaylist", JSON.stringify(updatePlaylist))

  }

  setnewpriority() {
    for (var i = 0; i < this.zonecontent[this.index].content.length; i++) {
      this.zonecontent[this.index].content[i].priority = i
    }
  }

  checkingDuplicate(titleIndex, title, zone) {
    let high_ver = this.zonecontent[this.index].content[titleIndex].copy_ver
    let copy = false

    for (var i = 0; i < this.zonecontent[this.index].content.length; i++) {
      if (titleIndex != i) {

        if (this.zonecontent[this.index].content[i].title == title) {
          if (zone == '' || zone == this.zonecontent[this.index].content[i].from_zone) {
            if (high_ver <= this.zonecontent[this.index].content[i].copy_ver) {
              high_ver = this.zonecontent[this.index].content[i].copy_ver
              copy = true
            }
          }
        }
      }
    }

    high_ver++

    if (copy) {
      console.log("masuk", this.zonecontent[this.index].content[titleIndex].priority)
      this.zonecontent[this.index].content[titleIndex].copy_ver = high_ver
      let temp = JSON.stringify(this.zonecontent[this.index].content[titleIndex].content)
      let convert = JSON.parse(temp)
      for (const copy of convert) {
        copy.copy_ver = high_ver
      }
      this.zonecontent[this.index].content[titleIndex].content = convert
    }
  }
}
