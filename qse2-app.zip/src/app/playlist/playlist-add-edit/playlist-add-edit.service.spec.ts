import { TestBed } from '@angular/core/testing';

import { PlaylistAddEditService } from './playlist-add-edit.service';

describe('PlaylistAddEditService', () => {
  let service: PlaylistAddEditService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlaylistAddEditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
