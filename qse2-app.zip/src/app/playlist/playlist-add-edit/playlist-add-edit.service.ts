import { Injectable, Output, EventEmitter } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem } from '@angular/cdk/drag-drop';

@Injectable({
  providedIn: 'root'
})
export class PlaylistAddEditService {

  PreviewContents
  PlaylistContent
  PlaylistName = ''
  ZoneContent
  
  @Output() sideNavMode: EventEmitter<any> = new EventEmitter();
  @Output() optionStatus: EventEmitter<any> = new EventEmitter();
  @Output() previewStatus: EventEmitter<any> = new EventEmitter();
  @Output() previewContents: EventEmitter<any> = new EventEmitter();
  @Output() playlistName: EventEmitter<any> = new EventEmitter();
  @Output() savePlaylist: EventEmitter<any> = new EventEmitter();
  @Output() saveUpdatePlaylist: EventEmitter<any> = new EventEmitter();

  constructor() { }

  setSideNavMode(mode){
    this.sideNavMode.emit(mode)
  }

  setOptionStatus(status){
    this.optionStatus.emit(status)
  }

  setPreviewStatus(status){
    this.previewStatus.emit(status)
  }

  setPreviewContents(content){
    this.PreviewContents = content
    this.previewContents.emit(content)
  }

  getPreviewContents(){
    return this.PreviewContents
  }

  setPlaylistName(name){
    this.PlaylistName = name
    this.playlistName.emit(name)
  }

  getPlaylistName(){
    return this.PlaylistName
  }

  setPlaylistContent(content){
    this.PlaylistContent = content
  }

  getPlaylistContent(){
    return this.PlaylistContent
  }

  setSavePlaylist(){
    this.savePlaylist.emit("save")
  }

  setSaveUpdatePlaylist(){
    this.saveUpdatePlaylist.emit("save")
  }

  // setZoneContent(zonecontent){
  //   this.ZoneContent = zonecontent
  // }

  // getZoneContent(){
  //   return this.ZoneContent
  // }

  Drop(event: CdkDragDrop<string[]>) {
    if (event.container === event.previousContainer) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      console.log(event.container.id);
    } else {
      if (event.container.id == 'list-1') {
        copyArrayItem(event.previousContainer.data,
          event.container.data,
          event.previousIndex,
          event.currentIndex);
      }

    }
  }

}
