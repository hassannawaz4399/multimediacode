import { Component, OnInit } from '@angular/core';
import { PlaylistListService } from '../../playlist-list/playlist-list.service';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { PlaylistAddEditService } from '../../playlist-add-edit/playlist-add-edit.service';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';

declare var require: any
const bytes = require('bytes');
const prettyMilliseconds = require('pretty-ms');

@Component({
  selector: 'app-playlist-content-playlist',
  templateUrl: './playlist-content-playlist.component.html',
  styleUrls: ['./playlist-content-playlist.component.css']
})
export class PlaylistContentPlaylistComponent implements OnInit {

  selectedIndex = -1

  search = ""
  duration = []
  size = []

  order: boolean = false;

  playlistList = []
  // templateList

  constructor(
    private playlistAddEditService: PlaylistAddEditService,
    private playlistListService: PlaylistListService,
    private playlistService: PlaylistService,
  ) { }

  ngOnInit(): void {
    
    let editplaylist = JSON.parse(this.playlistListService.getSelectedDetails())
    // if (editplaylist == null){
    //   editplaylist = []
    // }
    this.playlistService.getAllPlaylistListData().subscribe((PlaylistList) => {
      console.log("getAllPlaylistListData()", PlaylistList)
      if(PlaylistList.data.result == "success"){

        const temp = PlaylistList.data.data
        const tempData = []
        let playlistchecking = false

        for (const item of temp){
          let notplaylist = true
          for(const zone of item.zone_info){
            for(const playlist of zone.playlist_info){
              if(playlist.type == "playlist"){
                notplaylist = false
              }
            }
            // zone.playlist_info = zone.playlist_info.filter(playlist => playlist.type !== 'playlist')
          }
          if(editplaylist.length != 0){
            if(notplaylist && item.playlist_name != editplaylist[0].playlist_name){
              tempData.push(item)
            }
          }
          else{
            if(notplaylist){
              tempData.push(item)
            }
          }
          
        }
        console.log("list", tempData)
        // while(!playlistchecking){
        //   playlistchecking = true
        //   for (var i=0;i<tempData.length;i++){
        //     for(const zone of tempData[i].zone_info){
        //       for(const playlist of zone.playlist_info){
        //         if(playlist.type == "playlist"){
        //           console.log(tempData[i])
        //           tempData.splice(i,1)
        //           playlistchecking = false
        //           break
        //         }
        //       }
        //       if(!playlistchecking){
        //         break
        //       }
        //     }
        //     if(!playlistchecking){
        //       break
        //     }
        //   }
        // }

        for (const item of tempData){
          for(const zone of item.zone_info){
            zone.duration = 0
            zone.size = 0

            for(const playlist of zone.playlist_info){
              zone.duration += playlist.duration
              zone.size += playlist.size
            }
          }
        }
        this.playlistList = tempData

        console.log("playlist",this.playlistList)

        this.Sort(true)
        this.calculateDurationSize()

      }
    })

    // this.playlistListService.getPlaylistListData().subscribe((PlaylistList) => {
    //   this.playlistList = PlaylistList

    //   this.Sort(true)
    //   this.calculateDurationSize()
    // })
  }

  drop(event: CdkDragDrop<string[]>) {
    console.log("before drop", event)
    this.playlistAddEditService.Drop(event);
  }

  Sort(change) {
    console.log('order', change)
    this.order = change;
    this.playlistList.sort((n1, n2) => {
      return (this.order) ? n1.playlist_name.localeCompare(n2.playlist_name) : n2.playlist_name.localeCompare(n1.playlist_name);
    });
  }

  calculateDurationSize() {
    for (var i = 0; i < this.playlistList.length; i++) {
      console.log(i,this.playlistList[i])
      this.size[i] = bytes(this.playlistList[i].size)
      this.duration[i] = prettyMilliseconds(this.playlistList[i].duration, { colonNotation: true }, { keepDecimalsOnWholeSeconds: true })
    }
  }

  selectcurrent(selectedItem, index) {
    this.selectedIndex = index

    this.playlistAddEditService.setPlaylistContent(JSON.stringify(selectedItem))
  }
}
