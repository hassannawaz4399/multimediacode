import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistContentPlaylistComponent } from './playlist-content-playlist.component';

describe('PlaylistContentPlaylistComponent', () => {
  let component: PlaylistContentPlaylistComponent;
  let fixture: ComponentFixture<PlaylistContentPlaylistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistContentPlaylistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistContentPlaylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
