import { PlaylistFilterListPipe } from './playlist-filter-list.pipe';

describe('PlaylistFilterListPipe', () => {
  it('create an instance', () => {
    const pipe = new PlaylistFilterListPipe();
    expect(pipe).toBeTruthy();
  });
});
