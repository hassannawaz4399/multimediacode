import { VideoFilterListPipe } from './video-filter-list.pipe';

describe('VideoFilterListPipe', () => {
  it('create an instance', () => {
    const pipe = new VideoFilterListPipe();
    expect(pipe).toBeTruthy();
  });
});
