import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistContentVideoComponent } from './playlist-content-video.component';

describe('PlaylistContentVideoComponent', () => {
  let component: PlaylistContentVideoComponent;
  let fixture: ComponentFixture<PlaylistContentVideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistContentVideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistContentVideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
