import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistContentAudioComponent } from './playlist-content-audio.component';

describe('PlaylistContentAudioComponent', () => {
  let component: PlaylistContentAudioComponent;
  let fixture: ComponentFixture<PlaylistContentAudioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistContentAudioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistContentAudioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
