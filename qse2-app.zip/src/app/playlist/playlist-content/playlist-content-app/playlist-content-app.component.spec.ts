import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistContentAppComponent } from './playlist-content-app.component';

describe('PlaylistContentAppComponent', () => {
  let component: PlaylistContentAppComponent;
  let fixture: ComponentFixture<PlaylistContentAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistContentAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistContentAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
