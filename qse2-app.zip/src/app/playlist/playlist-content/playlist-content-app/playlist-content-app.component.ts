import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlist-content-app',
  templateUrl: './playlist-content-app.component.html',
  styleUrls: ['./playlist-content-app.component.css']
})
export class PlaylistContentAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
