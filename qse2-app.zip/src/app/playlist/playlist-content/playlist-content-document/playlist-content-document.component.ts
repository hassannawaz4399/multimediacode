import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlist-content-document',
  templateUrl: './playlist-content-document.component.html',
  styleUrls: ['./playlist-content-document.component.css']
})
export class PlaylistContentDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
