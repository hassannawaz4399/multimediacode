import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistContentDocumentComponent } from './playlist-content-document.component';

describe('PlaylistContentDocumentComponent', () => {
  let component: PlaylistContentDocumentComponent;
  let fixture: ComponentFixture<PlaylistContentDocumentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistContentDocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistContentDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
