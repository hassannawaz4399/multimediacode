import { Component, OnInit } from '@angular/core';
import { PlaylistListService } from '../playlist-list/playlist-list.service';

@Component({
  selector: 'app-playlist-schedule',
  templateUrl: './playlist-schedule.component.html',
  styleUrls: ['./playlist-schedule.component.css']
})
export class PlaylistScheduleComponent implements OnInit {

  schedule = []

  constructor(
    private playlistListService: PlaylistListService
  ) {
    // playlistListService.selectedDetails.subscribe(details => {
    //   let jsonData = JSON.parse(details);
    //   if(jsonData.length != 0)
    //   this.schedule = jsonData[0].schedule

    //   console.log(this.schedule)
    // })
   }

  ngOnInit(): void {
    let jsonData = JSON.parse(this.playlistListService.getSelectedDetails())
    // if(jsonData.length != 0)
    // this.schedule = jsonData[0].schedule
  }

}
