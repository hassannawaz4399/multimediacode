import { Component, OnInit } from '@angular/core';
import { PlaylistAddEditService } from '../playlist-add-edit/playlist-add-edit.service';

@Component({
  selector: 'app-playlist-option',
  templateUrl: './playlist-option.component.html',
  styleUrls: ['./playlist-option.component.css']
})
export class PlaylistOptionComponent implements OnInit {

  transition = ['none', 'fade', 'slide']
  fitting = ['none', 'fill', 'contain', 'scale-down']

  selectedTransition = 'none'
  selectedFitting = 'none'

  constructor(
    private playlistAddEditService:PlaylistAddEditService,
  ) { }

  ngOnInit(): void {
  }

  cancel(){
    this.playlistAddEditService.setOptionStatus(false)
  }
}
