import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistOptionComponent } from './playlist-option.component';

describe('PlaylistOptionComponent', () => {
  let component: PlaylistOptionComponent;
  let fixture: ComponentFixture<PlaylistOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistOptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
