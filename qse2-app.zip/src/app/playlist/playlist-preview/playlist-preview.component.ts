import { Component, OnInit } from '@angular/core';
import { PlaylistAddEditService } from '../playlist-add-edit/playlist-add-edit.service';
import { ContentManagerService } from 'src/app/services/content/content-manager.service';

@Component({
  selector: 'app-playlist-preview',
  templateUrl: './playlist-preview.component.html',
  styleUrls: ['./playlist-preview.component.css']
})
export class PlaylistPreviewComponent implements OnInit {

  // cmsUrl='http://id.qubit.asia:8081/'
  // cmsUrl='http://localhost:8081/'
  // cmsUrl = 'http://' + window.location.hostname
  cmsUrl=''

  contents = []
  preview = []
  index = 0;
  playlistName = ""

  constructor(
    private contentManagerService:ContentManagerService,
    private playlisAddEditService:PlaylistAddEditService
  ) {
    playlisAddEditService.previewContents.subscribe(PreviewContents => {
        this.contents = JSON.parse(PreviewContents)

        console.log(this.contents[0])
      })
   }

  ngOnInit(): void {
    this.cmsUrl = this.contentManagerService.getCmsUrl()
    
    this.playlistName = this.playlisAddEditService.getPlaylistName()
    this.contents = JSON.parse(this.playlisAddEditService.getPreviewContents())
    this.preview=[]
    for(var i = 0; i < this.contents.length; i++)
    {
      for(var j = 0; j < this.contents[i].content.length;j++){
        this.preview.push({type:this.contents[i].content[j].type, src:this.cmsUrl+'/'+this.contents[i].content[j].filename})
      }      
    }

    console.log(this.contents)
  }

  next(){
    if(this.index != this.preview.length - 1)
    {
      this.index++
    }
  }

  back(){
    if(this.index != 0)
    {
      this.index--
    }
  }

  close(){
    this.playlisAddEditService.setPreviewStatus(false)
  }
}
