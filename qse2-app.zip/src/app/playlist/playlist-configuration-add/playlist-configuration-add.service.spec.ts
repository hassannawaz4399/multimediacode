import { TestBed } from '@angular/core/testing';

import { PlaylistConfigurationAddService } from './playlist-configuration-add.service';

describe('PlaylistConfigurationAddService', () => {
  let service: PlaylistConfigurationAddService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlaylistConfigurationAddService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
