import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlaylistConfigurationAddService {

  @Output() layoutSelected: EventEmitter<any> = new EventEmitter();

  constructor(
    private http: HttpClient,
  ) { }

  getLandscapeListData(): any {
    return this.http.get('assets/json/playlist-landscape-layout-list-data.json');
  }

  getPotraitListData(): any {
    return this.http.get('assets/json/playlist-potrait-layout-list-data.json');
  }

  setLayoutSelected(layout){
    this.layoutSelected.emit(layout)
  }
}
