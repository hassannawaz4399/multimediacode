import { Component, OnInit } from '@angular/core';
import { PlaylistAddEditService } from '../playlist-add-edit/playlist-add-edit.service';
import { PlaylistListService } from '../playlist-list/playlist-list.service';
import { PlaylistConfigurationAddService } from './playlist-configuration-add.service';
import { PlaylistTemplateService } from 'src/app/services/playlist/playlist-template.service';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';

export interface PlaylistLayout{
  layoutName: string;
  layoutList:LayoutList[]
}
export interface LayoutList{
  type:string;
  name:string
}

@Component({
  selector: 'app-playlist-configuration-add',
  templateUrl: './playlist-configuration-add.component.html',
  styleUrls: ['./playlist-configuration-add.component.css']
})
export class PlaylistConfigurationAddComponent implements OnInit {

  
  firststep:boolean = true;
  secondstep:boolean = false;
  thirdstep:boolean = false;

  landscape = [];
  portrait = [];
  canvas = ['portrait','landscape'];
  
  selectedlayout
  selectedindexlayout
  selectedtemplate = 'portrait'

  playlistname=""
  playlistList;
  templateList
  duplicateStatus:boolean = false;

  errorLog = '';

  constructor(
    private playlistAddEditService:PlaylistAddEditService,
    private playlistListService:PlaylistListService,
    private playlistConfigurationAddService:PlaylistConfigurationAddService,
    private playlistTemplateService:PlaylistTemplateService,
    private playlistService:PlaylistService,
  ) { }

  ngOnInit(): void {
    this.setfirststep()

    this.playlistTemplateService.getTemplatesInfoListData().subscribe((TemplateList) => {
      this.templateList = TemplateList.data
      console.log(this.templateList)
      for(const item of this.templateList){
        if(item.type == 'landscape')
        this.landscape.push(item)
        else
        this.portrait.push(item)
      }
      this.selectlayout(0)
    })

    this.playlistListService.getPlaylistListData().subscribe((PlaylistList) => {
      this.playlistList = PlaylistList
    })

  }

  setfirststep(){
    this.duplicateStatus = false

    this.firststep = true;
    this.secondstep = false;
    this.thirdstep = false;
    this.errorLog = "";
    this.playlistAddEditService.setSideNavMode("over")
  }

  checkingName(){
    console.log("name", this.playlistname)
    
    // const duplicate = this.playlistList.find(
    //   (item) => item.name === this.playlistname)

    // if(duplicate != null)
    //   this.duplicateStatus = true
    // else
    // {
    //   this.playlistAddEditService.setPlaylistName(this.playlistname)
    //   this.setsecondstep()
    // }

    if(this.playlistname){
      const sendThis = { playlist_name: this.playlistname };
      this.playlistService.checkPlaylistName(sendThis).subscribe(resp => {
        console.log('this.playlistService.checkPlaylistName : ', resp);

        if (resp.data.allow) {
          console.log("complete")
          this.playlistAddEditService.setPlaylistName(this.playlistname)
          this.setsecondstep()
        } 
        else {
          this.errorLog = resp.data.reason;
        }
      })
    }
    else{
      this.errorLog = 'Playlist name cannot empty';
    }

    console.log("playlist", this.playlistList)
  }

  setsecondstep(){

    this.firststep = false;
    this.secondstep = true;
    this.thirdstep = false;

    this.playlistAddEditService.setSideNavMode("over")
  }

  setthirdstep(){
    console.log(this.selectedlayout)
    if(this.selectedlayout != undefined){
      this.playlistConfigurationAddService.setLayoutSelected(this.selectedlayout)
    
      this.firststep = false;
      this.secondstep = false;
      this.thirdstep = true;

      this.playlistAddEditService.setSideNavMode("side")
    }
  }

  cancel(){
    this.playlistListService.setAddPlaylist(false)
  }

  save(){
    console.log("configurationadd")
    this.playlistAddEditService.setSavePlaylist()
  }

  statusChange(event){
    if(this.selectedtemplate != event){
      this.selectedtemplate = event
      this.selectlayout(0)
    }
  }

  selectlayout(index){
    if(this.selectedtemplate == 'portrait'){
      this.selectedlayout = this.portrait[index]
      this.selectedindexlayout = index
    }
    else{
      this.selectedlayout = this.landscape[index]
      this.selectedindexlayout = index
    }
  }
}
