import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlist-activity',
  templateUrl: './playlist-activity.component.html',
  styleUrls: ['./playlist-activity.component.css']
})
export class PlaylistActivityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
