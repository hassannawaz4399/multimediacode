import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistActivityComponent } from './playlist-activity.component';

describe('PlaylistActivityComponent', () => {
  let component: PlaylistActivityComponent;
  let fixture: ComponentFixture<PlaylistActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistActivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
