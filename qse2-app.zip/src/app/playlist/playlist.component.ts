import { Component, OnInit, OnDestroy } from '@angular/core';
import { PlaylistListService } from './playlist-list/playlist-list.service';
import { LayoutService } from '../layout/layout.service';
import { PlaylistAddEditService } from './playlist-add-edit/playlist-add-edit.service';
import { Subscription } from 'rxjs';
import { DeviceListService } from '../monitoring/device-list/device-list.service';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css']
})
export class PlaylistComponent implements OnInit, OnDestroy {

  subscription : Subscription[] = []

  playlistTotal = 0
  newPlaylist: boolean = false;
  playlistOption: boolean = false;
  playlistPreview: boolean = false;
  editPlaylist: boolean = false;

  lengthSelected = 0

  constructor(
    private layoutService: LayoutService,
    private playlistListService: PlaylistListService,
    private playlistAddEditService: PlaylistAddEditService,
    deviceListService:DeviceListService,
  ) {

    deviceListService.setSelectedBranch(null)

    this.subscription.push( playlistListService.addPlaylist.subscribe(data => {
      this.newPlaylist = data

      if (!this.newPlaylist) {
        this.layoutService.toggleLeft(true);
      }
    }))

    this.subscription.push( playlistAddEditService.optionStatus.subscribe(status => {
      this.playlistOption = status
    }))

    this.subscription.push( playlistAddEditService.previewStatus.subscribe(status => {
      this.playlistPreview = status
    }))

    this.subscription.push( playlistListService.selectedDetails.subscribe(details => {
      let jsonData = JSON.parse(details);
      this.lengthSelected = jsonData.length
    }))

    this.subscription.push( playlistListService.editPlaylist.subscribe(status => {
      this.editPlaylist = status

      if (!this.newPlaylist) {
        this.layoutService.toggleLeft(true);
      }
    }))
  }

  ngOnInit(): void {
    this.editPlaylist = this.playlistListService.getEditPlaylist()
    this.layoutService.toggleLeft(true);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    
    console.log("unsubscribe all subscription at playlist")
    for(const item of this.subscription){
      item.unsubscribe()
    }
  }

  togglerightNav() {
    this.layoutService.toggleRight();
  }

  addPlaylist() {
    this.playlistListService.setAddPlaylist(true);
  }

  closerightNav(){
    this.playlistListService.setCheckedbox("allClose")
  }

  duplicateplaylist(){
    this.playlistListService.setDuplicateSelected()
  }
  
  deleteplaylist(){
    this.playlistListService.setDeleteSelected()
  }

  edit(){
    this.playlistListService.setEditSelected()
  }

  refreshPlaylistTable(){
    this.playlistListService.refreshPlaylist()
  }
}
