import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaylistConfigurationEditComponent } from './playlist-configuration-edit.component';

describe('PlaylistConfigurationEditComponent', () => {
  let component: PlaylistConfigurationEditComponent;
  let fixture: ComponentFixture<PlaylistConfigurationEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaylistConfigurationEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaylistConfigurationEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
