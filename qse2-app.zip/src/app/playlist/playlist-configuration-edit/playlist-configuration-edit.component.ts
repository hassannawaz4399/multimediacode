import { Component, OnInit } from '@angular/core';
import { PlaylistAddEditService } from '../playlist-add-edit/playlist-add-edit.service';
import { PlaylistListService } from '../playlist-list/playlist-list.service';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-playlist-configuration-edit',
  templateUrl: './playlist-configuration-edit.component.html',
  styleUrls: ['./playlist-configuration-edit.component.css']
})
export class PlaylistConfigurationEditComponent implements OnInit {

  constructor(
    private playlistAddEditService:PlaylistAddEditService,
    private playlistListService:PlaylistListService,
    
    private readonly route: ActivatedRoute,
    private readonly router: Router,
  ) { }

  ngOnInit(): void {
    this.playlistAddEditService.setSideNavMode("side")
  }

  cancel(){
    this.router.navigate(['/playlist']);
    this.playlistListService.setEditPlaylist(false)
  }

  save(){
    this.playlistAddEditService.setSaveUpdatePlaylist()
  }
}
