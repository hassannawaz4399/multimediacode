import { Component, OnInit } from '@angular/core';
import { PlaylistListService } from '../playlist-list/playlist-list.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { PlaylistService } from 'src/app/services/playlist/playlist.service';
import { formatDate } from '@angular/common';

declare var require: any
const bytes = require('bytes');

export interface Playlist {
  playlist_name: string;
  status: boolean;
  size: number;
  duration: number;
  created_by: string;
  template: string;
  zone_info: ZoneInfo[];
  updated_at: Date;
  inserted_at: Date;
  is_selected: boolean;
}

export interface ZoneInfo {
  zone: string;
  size: number;
  playlist_info: PlaylistInfo[]
}

export interface PlaylistInfo {
  title: string;
  type: string;
  zone: string;
  from_zone: string;
  copy_ver: number;
  priority: number;
  size: number;
  duration: number;
  total_media: number;
  show:boolean;
  content: Content[];
}

export interface Content {
  priority: number;
  title: string;
  filename: string;
  duration: number;
  type: string;
  copy_ver: number;
}

@Component({
  selector: 'app-playlist-info',
  templateUrl: './playlist-info.component.html',
  styleUrls: ['./playlist-info.component.css']
})
export class PlaylistInfoComponent implements OnInit {

  playlistList: Playlist

  currentZone
  size = []
  updated:Date

  constructor(
    private playlistListService: PlaylistListService,
    private playlistService: PlaylistService,
  ) {
    playlistListService.selectedDetails.subscribe(details => {
      let jsonData = JSON.parse(details);

      //   if(jsonData.length != 0)
      //   this.info = jsonData[0].content[0].content

      //   console.log(this.info)

      
    })
  }

  ngOnInit(): void {
    let jsonData = JSON.parse(this.playlistListService.getSelectedDetails())
    // if(jsonData.length != 0){
    //   this.info = jsonData[0].content[0].content

    //   this.contentsList.data = this.info
    //   this.owner = jsonData[0].created_by
    // }

    this.playlistService.getOnePlaylist(jsonData[0].playlist_name).subscribe((PlaylistList) => {
      if(PlaylistList.data.result == 'success'){
        this.playlistList = PlaylistList.data.playlist

        for(const item of this.playlistList.zone_info){
          item.size = 0
          for(const list of item.playlist_info){
            list.show = false
            item.size +=list.size
          }
          item.size =  bytes(item.size)
        
        }
        this.updated = new Date(formatDate(this.playlistList.updated_at, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC')

        console.log(this.playlistList)
        this.currentZone = this.playlistList.zone_info[0]
      }
    })
  }

}
