import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
// import { ExportToCsv } from 'export-to-csv';

@Component({
  selector: 'app-signage-device',
  templateUrl: './signage-device.component.html',
  styleUrls: ['./signage-device.component.css']
})
export class SignageDeviceComponent implements OnInit {
  SelectedImage: File[] = []
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Input() deviceName: any;
  switchListing: any[] = []
  selectedRowIndex: number = 1;
  displayedColumnsHeader: any[] = [
    "startDate",
    "schedule",
    "playList",
    "duration",
    "status",
  ];
  // public options = {
  //   fieldSeparator: ',',
  //   quoteStrings: '"',
  //   decimalSeparator: '.',
  //   showLabels: true,
  //   showTitle: true,
  //   title: 'My Awesome CSV',
  //   useTextFile: false,
  //   useBom: true,
  //   useKeysAsHeaders: true,
  //   // headers: ['Column 1', 'Column 2', etc...] <-- Won't work with useKeysAsHeaders present!
  // };
  constructor(private route: ActivatedRoute) { }
  templateNme: string = 'Template Name'
  channelName: string = 'channel Name'
  schedulerName: string = 'scheduler Name'
  playListname: string = 'Play Listname'
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.deviceName = params['deviceName']
    });
    this.switchListing = [{
      name: "Schedule"
    }, { name: "Live" }]
  }
  onUploadSelect(event) {
    this.SelectedImage = []
    this.SelectedImage.push(...event.addedFiles);
  }
  onupload(event) {
    this.SelectedImage = []
    this.SelectedImage.push(...event.addedFiles);
  }
  onselectedFile(event?) {
    this.SelectedImage = []
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  rowSelect(item) {
    this.selectedRowIndex = item.id;
  }
  isSwitchMode: boolean = false
  switchedValue: string = "Schedule"
  switchMode() {
    console.log(this.switchedValue)
    this.isSwitchMode = !this.isSwitchMode
  }
  sv(item) {
    console.log(this.switchedValue)
    console.log(item)
    this.switchedValue = item.name
  }

}
export interface PeriodicElement {
  id: number;
  startDate: string;
  schedule: string;
  playList: string;
  duration: string;
  starus: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    id: 111,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 2,
    startDate: "hh:mm AM/PM",
    schedule: "5Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 3,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 4,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 5,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 6,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 7,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 8,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 9,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
  {
    id: 10,
    startDate: "hh:mm AM/PM",
    schedule: "Schedule Name",
    playList: "Content Name",
    starus: "Enabled",
    duration: "hh:mm:ss",
  },
];
