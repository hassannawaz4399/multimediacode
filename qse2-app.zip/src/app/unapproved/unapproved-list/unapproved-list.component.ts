import { Component, OnInit, ViewChild } from '@angular/core';
import { UnapprovedListService } from './unapproved-list.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { LayoutService } from 'src/app/layout/layout.service';
import { BranchService } from 'src/app/services/monitoring/branch.service';

export interface Unapproved {
  branch_id: string
  branch_name: string
  device_id: string
  device_name: string
  serial:string
  floor:string
  location:string
  connection_type: string
  model:string
  ip: string
  mac: string
  registered: string
  is_selected:boolean
}
@Component({
  selector: 'app-unapproved-list',
  templateUrl: './unapproved-list.component.html',
  styleUrls: ['./unapproved-list.component.css']
})
export class UnapprovedListComponent implements OnInit {

  unapproveListDisplayColumn: string[] = ['action', 'branch_name', 'model', 'device_name', 'ip']

  unapproveList: MatTableDataSource<Unapproved>;

  rightSideNavWidth;

  masterSelected: boolean;
  checkedRow: any;
  lengthSelected = 0;

  @ViewChild('sidenavright') sidenavright;
  @ViewChild(MatPaginator) paginator: MatPaginator
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  constructor(
    private branchService: BranchService,
    private unapprovedListService: UnapprovedListService,
    private layoutService: LayoutService,
  ) {
    layoutService.rightToggle.subscribe(data => {
      this.toggleRightNav();
    });

    layoutService.rightWidth.subscribe(data => {
      this.rightSideNavWidth = data;
    });

    unapprovedListService.unchecked.subscribe(data => {
      console.log(data);
      if (data === 'allClose') {
        this.masterSelected = false;
        for (let i = 0; i < this.unapproveList.data.length; i++)
          this.unapproveList.data[i].is_selected = false;

        this.getCheckedItemList();
      }
    });

    unapprovedListService.saveSelected.subscribe(Data =>{
      this.getUnapproveTable()
    })
  }

  ngOnInit(): void {
    this.getUnapproveTable()

  }

  getUnapproveTable(){
    this.branchService.getUnapproveDevice().subscribe((UnapproveList) => {
      console.log("getUnapproveDevice()", UnapproveList)
      if(UnapproveList.data.result === 'success'){
        const dataList = UnapproveList.data.data

        for (const item of dataList) {
          item.is_selected = false
        }
        
        this.unapprovedListService.setTotalUnapproved(dataList.length)

        this.unapproveList = new MatTableDataSource<Unapproved>(dataList)
        this.unapproveList.paginator = this.paginator

        this.masterSelected = false
        this.checkUncheckAll()
      }
      else{
        console.log("ERROR: getUnapproveDevice()")
      }
      
    })
  }

  toggleRightNav() {
    this.sidenavright.toggle();
  }

  sidenavMode() {
    return this.layoutService.getSidenavMode();
  }

  rightNavStatus(status) {
    if (status === 1) {
      this.sidenavright.open();
    } else {
      this.sidenavright.close();
    }
  }

  checkUncheckAll() {
    for (let i = 0; i < this.unapproveList.data.length; i++) {
      this.unapproveList.data[i].is_selected = this.masterSelected;
    }
    this.getCheckedItemList();
  }

  isAllSelected() {
    console.log(this.unapproveList.data);
    this.masterSelected = this.unapproveList.data.every((item: any) => {
      return item.is_selected === true;
    });
    this.getCheckedItemList();
  }

  getCheckedItemList() {
    this.checkedRow = [];
    for (let i = 0; i < this.unapproveList.data.length; i++) {
      if (this.unapproveList.data[i].is_selected) {
        this.checkedRow.push(this.unapproveList.data[i]);
      }
    }
    console.log('checked row : ', this.checkedRow.length);

    this.lengthSelected = this.checkedRow.length;
    this.checkedRow = JSON.stringify(this.checkedRow);
    this.unapprovedListService.setSelectedDetails(this.checkedRow);

    this.rightNavStatus(this.lengthSelected);
  }

}
