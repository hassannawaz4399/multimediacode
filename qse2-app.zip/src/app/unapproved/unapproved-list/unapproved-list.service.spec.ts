import { TestBed } from '@angular/core/testing';

import { UnapprovedListService } from './unapproved-list.service';

describe('UnapprovedListService', () => {
  let service: UnapprovedListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UnapprovedListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
