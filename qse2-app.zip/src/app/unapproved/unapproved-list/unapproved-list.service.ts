import { Injectable, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UnapprovedListService {

  SelectedDetails
  TotalUnapproved

  @Output() selectedDetails: EventEmitter<any> = new EventEmitter();
  @Output() unchecked: EventEmitter<any> = new EventEmitter();
  @Output() saveSelected: EventEmitter<any> = new EventEmitter();
  @Output() totalUnapproved: EventEmitter<any> = new EventEmitter();

  constructor(
    private http: HttpClient,
  ) { }

  getUnapplrovedListData(): any {
    return this.http.get('assets/json/unapproved-list-data.json');
  }

  setSelectedDetails(selected) {
    this.SelectedDetails = selected
    this.selectedDetails.emit(selected)
  }

  getSelectedDetails() {
    return this.SelectedDetails
  }

  setCheckedbox(checked) {
    this.unchecked.emit(checked)
  }

  setSaveSelected() {
    this.saveSelected.emit('data')
  }

  setTotalUnapproved(unapproved){
    this.TotalUnapproved = unapproved
    this.totalUnapproved.emit(unapproved)
  }

  getTotalUnapproved(){
    return this.TotalUnapproved
  }

}
