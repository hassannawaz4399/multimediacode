import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../layout/layout.service';
import { UnapprovedListService } from './unapproved-list/unapproved-list.service';
import { DeviceListService } from '../monitoring/device-list/device-list.service';

@Component({
  selector: 'app-unapproved',
  templateUrl: './unapproved.component.html',
  styleUrls: ['./unapproved.component.css']
})
export class UnapprovedComponent implements OnInit {

  unapprovedTotal = 0
  selectedTotal = 0

  constructor(
    private layoutService: LayoutService,
    private unapprovedListService: UnapprovedListService,
    deviceListService: DeviceListService,
  ) { 

    deviceListService.setSelectedBranch(null)

    unapprovedListService.selectedDetails.subscribe(SelectedDetail => {
      let data = JSON.parse(SelectedDetail)

      this.selectedTotal = data.length
    })
  }

  ngOnInit(): void {
    this.layoutService.toggleLeft(true);
  }

  togglerightNav() {
    this.layoutService.toggleRight();
  }

  closerightNav(){
    this.unapprovedListService.setCheckedbox("allClose")
  }
  
  refreshUnapprovedTable(){

  }
}
