import { Component, OnInit } from '@angular/core';
import { UnapprovedListService } from '../unapproved-list/unapproved-list.service';
import { BranchService } from 'src/app/services/monitoring/branch.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-unapproved-device-setting',
  templateUrl: './unapproved-device-setting.component.html',
  styleUrls: ['./unapproved-device-setting.component.css']
})
export class UnapprovedDeviceSettingComponent implements OnInit {

  selectedDetails = []
  selectedDate:Date

  constructor(
    private unapprovedListService: UnapprovedListService,
    private branchService: BranchService,
  ) { 
    // unapprovedListService.selectedDetails.subscribe(selected => {
    //   this.selectedDetails
    // })
   }

  ngOnInit(): void {
    this.selectedDetails = JSON.parse(this.unapprovedListService.getSelectedDetails())

    // let tempdate = new Date(this.selectedDetails[0].registered)
    this.selectedDate = new Date(formatDate(this.selectedDetails[0].registered, 'yyyy-MM-dd hh:mm:ss aa', 'en-US') + ' UTC')
  }

  save(){
    let approveDevice = {
      branch_id:this.selectedDetails[0].branch_id,
      device_id:this.selectedDetails[0].device_id
    }
    this.unapprovedListService.setSaveSelected()

    this.branchService.approveDevice(approveDevice).subscribe(resp => {
      console.log('this.branchService.approveDevice : ', resp);
      if (resp.data.result === 'success') {
        console.log("complete add_playlist")
        this.unapprovedListService.setSaveSelected()
      }
      else {
        console.log("error: playlistService.add_playlist");
      }
    })
  }
}
