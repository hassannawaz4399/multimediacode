import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnapprovedDeviceSettingComponent } from './unapproved-device-setting.component';

describe('UnapprovedDeviceSettingComponent', () => {
  let component: UnapprovedDeviceSettingComponent;
  let fixture: ComponentFixture<UnapprovedDeviceSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnapprovedDeviceSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnapprovedDeviceSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
